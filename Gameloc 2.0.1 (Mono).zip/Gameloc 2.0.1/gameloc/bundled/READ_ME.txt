여기에 무엇이 들어가나
======================

[마지막 수단 넣기] 가 쓰는 압축 두 개입니다. 여기 있으면 Gameloc 이
그것을 쓰고, 사용자에게 받아 오라는 말을 하지 않습니다.

이 게임에 맞는 짝이 없으면 예전처럼 받아둔 폴더를 묻습니다. 그러니
비어 있어도 Gameloc 은 그대로 돕니다.

  IL2CPP · 64비트  (요즘 게임 대부분)
    BepInEx-Unity.IL2CPP-win-x64-*.zip
      https://builds.bepinex.dev/projects/bepinex_be
    XUnity.AutoTranslator-BepInEx-IL2CPP-*.zip
      https://github.com/bbepis/XUnity.AutoTranslator/releases

  Mono · 64비트  (조금 오래된 게임)
    BepInEx_win_x64_*.zip
      https://github.com/BepInEx/BepInEx/releases
    XUnity.AutoTranslator-BepInEx-*.zip   (이름에 IL2CPP 가 없는 것)

  Mono · 32비트  (아주 오래된 게임)
    BepInEx_win_x86_*.zip

Mono 짝은 2.0.1 부터 들어 있습니다. 그 전에는 IL2CPP 짝만 있어서, Mono
게임에서 [마지막 수단] 을 누르면 "직접 받아 오세요" 로 빠졌습니다.

받은 파일을 **이름 그대로** 이 폴더에 넣으면 됩니다. 압축을 풀지
마세요. Gameloc 이 이름을 보고 짝을 고릅니다.

라이선스 고지는 THIRD-PARTY-NOTICES.txt 를 보세요.
