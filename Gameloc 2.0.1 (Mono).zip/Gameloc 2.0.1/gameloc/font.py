# Gameloc — 게임 폴더를 넣으면 번역해 주는 도구
# Copyright (C) 2026  하진
#
# 이 프로그램은 자유 소프트웨어입니다. 자유 소프트웨어 재단이 펴낸 GNU 일반
# 공중 사용 허가서 3판 또는 그 이후 판의 조건에 따라 재배포하거나 고칠 수
# 있습니다.
#
# 이 프로그램은 쓸모가 있기를 바라며 배포하지만 어떠한 보증도 하지 않습니다.
# 자세한 내용은 GNU 일반 공중 사용 허가서를 보세요.
# 함께 받은 LICENSE 파일에 전문이 있습니다. <https://www.gnu.org/licenses/>

"""한글이 □□□ 로 나오는 것을 고칩니다.

## 무엇이 문제인가

번역은 이미 게임 안에 들어가 있습니다. 그런데 게임이 쓰는 폰트에 한글 **모양**이
없으면 그리지 못하고 네모를 찍습니다.

    · [TMP] timemachine-wa SDF   글자 7124자 · 한글 0자 · 아틀라스 8192x8192 · Static

Static(고정) 폰트는 글자 그림이 통째로 구워져 있어서, 없는 글자를 만들어낼
방법이 없습니다. 그림판을 새로 구워야 하는데 그건 유니티 에디터가 필요합니다.

## 그런데 빠져나갈 구멍이 있습니다

TextMeshPro 에는 두 가지 장치가 있습니다.

1. **Dynamic(실행 중 생성) 폰트** — 글자 그림을 미리 굽지 않고, 게임이 돌 때
   원본 폰트 파일에서 그때그때 만들어냅니다. 원본만 바꿔치면 어떤 글자든 나옵니다.
2. **대체 폰트(fallback)** — 어떤 글자를 못 그리면 다음 폰트에게 넘깁니다.

이 게임에는 마침 Dynamic 폰트가 들어 있습니다. 그래서:

    ① Dynamic 폰트가 쓰는 **원본 글꼴 파일**을 한글 글꼴로 바꾸고
    ② 한글이 없는 폰트들의 **대체 폰트 목록**에 그 Dynamic 폰트를 넣는다

이러면 일본어·영어는 원래 폰트가 그대로 그리고, 한글만 대체 폰트가 그립니다.
원본 그림판은 손대지 않습니다.

## 글꼴 파일은 어디서

**사용자 컴퓨터에 이미 깔려 있는 한글 글꼴을 씁니다.** 맑은 고딕 같은 것들요.
글꼴을 프로그램에 넣어 배포하면 저작권 문제가 생기지만, 각자 컴퓨터에 있는
것을 쓰는 건 그런 문제가 없습니다.
"""

from __future__ import annotations

import platform
from dataclasses import dataclass, field
from pathlib import Path

HANGUL = (0xAC00, 0xD7A3)

# 사람들 컴퓨터에 대체로 깔려 있는 한글 글꼴. 위에 있는 것부터 찾습니다.
CANDIDATES = {
    "Windows": [
        r"C:\Windows\Fonts\malgun.ttf",          # 맑은 고딕
        r"C:\Windows\Fonts\malgunsl.ttf",
        r"C:\Windows\Fonts\NanumGothic.ttf",
        r"C:\Windows\Fonts\gulim.ttc",
        r"C:\Windows\Fonts\batang.ttc",
    ],
    "Darwin": [
        "/System/Library/Fonts/AppleSDGothicNeo.ttc",
        "/Library/Fonts/NanumGothic.ttf",
    ],
    "Linux": [
        "/usr/share/fonts/truetype/nanum/NanumGothic.ttf",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ],
}


def find_system_font() -> Path | None:
    """이 컴퓨터에 깔려 있는 한글 글꼴 하나."""
    for p in CANDIDATES.get(platform.system(), []):
        path = Path(p)
        if path.is_file():
            return path
    # 못 찾으면 폰트 폴더를 통째로 뒤집니다
    roots = [Path(r"C:\Windows\Fonts"), Path("/usr/share/fonts"),
             Path("/Library/Fonts"), Path.home() / ".fonts"]
    for root in roots:
        if not root.is_dir():
            continue
        for pat in ("*malgun*", "*Nanum*", "*NotoSansCJK*", "*NotoSansKR*",
                    "*Gothic*"):
            hit = next(iter(sorted(root.rglob(pat))), None)
            if hit and hit.suffix.lower() in (".ttf", ".otf", ".ttc"):
                return hit
    return None


# ---------------------------------------------------------------- 폰트 찾기

def is_font_asset(class_name: str) -> bool:
    return "FontAsset" in class_name or "TMP_Font" in class_name


def unicodes_of(tree: dict) -> set[int]:
    out: set[int] = set()
    for row in tree.get("m_CharacterTable") or []:
        if isinstance(row, dict):
            u = row.get("m_Unicode")
            if isinstance(u, int):
                out.add(u)
    return out


def has_hangul(tree: dict) -> bool:
    return any(HANGUL[0] <= u <= HANGUL[1] for u in unicodes_of(tree))


def is_dynamic(tree: dict) -> bool:
    return tree.get("m_AtlasPopulationMode") in (1, 2)


@dataclass
class FontPlan:
    """무엇을 어떻게 고칠지."""

    donor_path_id: int | None = None      # 대체 폰트로 쓸 Dynamic 폰트
    donor_name: str = ""
    source_font_id: int | None = None     # 그 폰트가 읽는 원본 글꼴 파일
    source_font_name: str = ""
    targets: list[tuple[int, str]] = field(default_factory=list)  # 고칠 폰트들
    font_like: int = 0                    # 폰트로 보이지만 못 읽은 것 수
    font_real: int = 0                    # 그 중 앞머리가 진짜 폰트 모양인 것
    # 옛날식 Font 오브젝트. TextMeshPro 구조를 못 읽을 때의 우회로입니다.
    legacy: list[tuple[int, str]] = field(default_factory=list)
    tmp_readable: bool = False            # TextMeshPro 구조를 하나라도 읽었나
    notes: list[str] = field(default_factory=list)

    def ok(self) -> bool:
        return (self.donor_path_id is not None
                and self.source_font_id is not None
                and bool(self.targets))

    def legacy_only(self) -> bool:
        """제대로 된 길이 **막혔고**, 옛날식 Font 로 시도해 볼 수 있는가.

        '읽었는데 고칠 게 없다' 와 '아예 못 읽었다' 는 다릅니다. 앞쪽은
        할 일이 없는 것이니 우회로를 쓰면 안 됩니다.
        """
        return not self.tmp_readable and bool(self.legacy)


def _pptr_id(value) -> int | None:
    if isinstance(value, dict):
        pid = value.get("m_PathID")
        if isinstance(pid, int) and pid != 0:
            return pid
    return None


def plan(objs) -> FontPlan:
    """열려 있는 오브젝트들을 보고 계획을 세웁니다. 아무것도 안 고칩니다."""
    from .peek import script_class

    from . import tmpraw

    p = FontPlan()
    assets: list[tuple[int, str, dict]] = []
    for o in objs:
        # 옛날식 Font 는 유니티 **기본 클래스**라 IL2CPP 게임에서도 읽힙니다.
        # TextMeshPro 구조를 못 읽을 때 기댈 곳이 여기뿐입니다.
        if o.type.name == "Font":
            try:
                name = str(o.read_typetree().get("m_Name") or "?")
            except Exception:                          # noqa: BLE001
                name = "?"
            p.legacy.append((o.path_id, name))
            continue
        if o.type.name != "MonoBehaviour":
            continue
        # 이름만 보고 폰트라 우기면 없는 폰트를 있다고 말하게 됩니다.
        # 바이트 앞머리가 실제 TextMeshPro 폰트 모양일 때만 인정합니다.
        try:
            head = tmpraw.read_head(o.get_raw_data())
        except Exception:                              # noqa: BLE001
            head = None
        if head is None and not is_font_asset(script_class(o)):
            continue
        if head is not None:
            p.font_real += 1
        p.font_like += 1
        try:
            tree = o.read_typetree()
        except Exception:                              # noqa: BLE001
            continue
        if isinstance(tree, dict):
            assets.append((o.path_id, str(tree.get("m_Name") or "?"), tree))

    p.tmp_readable = bool(assets)
    if not assets:
        if p.font_real:
            p.notes.append(
                f"TextMeshPro 폰트 {p.font_real}개가 보이는데 구조를 읽지 못했습니다. "
                "게임 DLL 에서 타입 정보를 되살리지 못한 경우입니다.")
        elif p.font_like:
            p.notes.append(
                f"폰트 비슷한 것 {p.font_like}개가 있지만 TextMeshPro 폰트는 "
                "아닙니다. 건드리지 않습니다.")
        else:
            p.notes.append("이 파일에는 TextMeshPro 폰트가 없습니다.")
        if p.legacy:
            names = ", ".join(n for _i, n in p.legacy[:3])
            p.notes.append(
                f"대신 유니티 기본 글꼴 {len(p.legacy)}개({names})가 있습니다. "
                "여기에 한글 글꼴을 넣어 보겠습니다.")
        return p

    # ① 대체 폰트로 쓸 Dynamic 폰트. 글자가 적은 쪽이 아틀라스에 여유가 많습니다.
    dynamics = [(pid, name, t) for pid, name, t in assets if is_dynamic(t)]
    dynamics.sort(key=lambda x: len(unicodes_of(x[2])))
    for pid, name, tree in dynamics:
        src = _pptr_id(tree.get("m_SourceFontFile"))
        if src is not None:
            p.donor_path_id, p.donor_name = pid, name
            p.source_font_id = src
            break
    if p.donor_path_id is None:
        p.notes.append("실행 중에 글자를 만들어내는(Dynamic) 폰트가 없습니다. "
                       "이 방법으로는 고칠 수 없습니다.")
        return p

    # ② 한글이 없는 폰트 전부가 대상. 대체 폰트 자신은 뺍니다.
    for pid, name, tree in assets:
        if pid == p.donor_path_id or has_hangul(tree):
            continue
        p.targets.append((pid, name))
    if not p.targets:
        p.notes.append("이미 한글이 있는 폰트뿐입니다. 고칠 게 없습니다.")
    return p


# ---------------------------------------------------------------- 고치기

@dataclass
class FontReport:
    changed_files: list[str] = field(default_factory=list)
    donor: str = ""
    ttf: str = ""
    patched: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    retargeted: list[str] = field(default_factory=list)   # 굳어 있어서 풀어 준 폰트
    legacy_route: bool = False           # 유니티 기본 글꼴로 우회했나
    source_font_name: str = ""
    engine: str = "unity"

    def summary(self) -> str:
        if self.engine == "renpy":
            if not self.changed_files:
                return "폰트를 고치지 못했습니다. " + (self.notes[0] if self.notes else "")
            return (f"한글 글꼴({Path(self.ttf).name})을 game 폴더에 넣고, "
                    f"게임이 쓰던 글꼴 {len(self.patched)}개를 그것으로 바꿔치도록 "
                    "했습니다. 원본 글꼴 파일은 그대로 있습니다.")
        if not self.patched:
            return "폰트를 고치지 못했습니다. " + (self.notes[0] if self.notes else "")
        if self.legacy_route:
            head = (f"유니티 기본 글꼴 {len(self.patched)}개를 "
                    f"한글 글꼴({Path(self.ttf).name})로 바꿨습니다.")
            if self.retargeted:
                head += f" 굳어 있던 폰트 {len(self.retargeted)}개도 풀었습니다."
            return head
        return (f"'{self.donor}' 를 한글 글꼴({Path(self.ttf).name})로 바꾸고, "
                f"폰트 {len(self.patched)}개에 대체 폰트로 걸었습니다.")


def _set_font_data(tree: dict, data: bytes, name: str) -> bool:
    """유니티 Font 오브젝트 안의 글꼴 파일 자체를 갈아끼웁니다."""
    if "m_FontData" not in tree:
        return False
    tree["m_FontData"] = data
    if isinstance(tree.get("m_FontNames"), list):
        tree["m_FontNames"] = [name]
    return True


# 이모지·아이콘 모음은 글자 폰트가 아닙니다. 한글 원본을 물려도 얻을 게 없고
# 그림판 형식이 달라 오히려 어긋날 수 있어 건드리지 않습니다.
def _donor_font_id(objs, patched_ids: set[int]) -> int:
    """한글을 넣어 줄 원본 글꼴을 고릅니다.

    ``patched_ids`` 는 **방금 한글 글꼴로 갈아친** 글꼴들입니다. 그 중 어느
    것을 가리켜도 안에 든 것은 똑같은 한글 글꼴이라, 아무거나 써도 됩니다.
    TextMeshPro 는 가리키는 대로 불러올 뿐이고, 게임이 그것을 다른 데서
    쓰고 있는지와는 상관이 없습니다.

    그래도 **이미 Dynamic 폰트가 물고 있는** 것이 있으면 그것을 먼저 씁니다.
    유니티가 실제로 그 글꼴을 불러낸 적이 있다는 뜻이라 조금 더 안전합니다.
    """
    from . import tmpraw

    for o in objs:
        if o.type.name != "MonoBehaviour":
            continue
        try:
            head = tmpraw.read_head(o.get_raw_data())
        except Exception:                               # noqa: BLE001
            continue
        if head is None or head.mode != tmpraw.DYNAMIC:
            continue
        if head.src_file == 0 and head.src_path in patched_ids:
            return head.src_path
    return min(patched_ids) if patched_ids else 0


_NOT_TEXT = ("emoji", "icon", "symbol", "sprite", "dropcap")
# 반대로 **이것처럼 보여야만** 손댑니다. TextMeshPro 폰트는 거의 예외 없이
# 이름에 ``SDF`` 나 ``Font`` 가 들어갑니다. 이 관문이 없으면 스프라이트
# 모음(``DropCap Numbers`` 같은 것)까지 폰트로 알고 고쳐 버립니다 —
# 실제로 그렇게 해서 게임이 글자를 하나도 안 그리고 꺼졌습니다.
_LOOKS_TEXT = ("sdf", "font")


def dynamic_ready(objs) -> int:
    """이미 '실행 중에 그리기' 로 되어 있고 원본 글꼴을 물고 있는 폰트 수.

    이런 폰트가 하나라도 있으면, 그 원본 글꼴 안을 한글 글꼴로 갈아치우는
    것만으로 한글이 나옵니다. **굳은 폰트를 억지로 풀 이유가 없습니다.**
    """
    from . import tmpraw

    n = 0
    for o in objs:
        if o.type.name != "MonoBehaviour":
            continue
        try:
            head = tmpraw.read_head(o.get_raw_data())
        except Exception:                               # noqa: BLE001
            continue
        if head is not None and head.mode == tmpraw.DYNAMIC and head.src_path:
            n += 1
    return n


def _retarget_static(objs, rep, donor_id: int, progress) -> int:
    """원본 글꼴이 없는 Static 폰트를 Dynamic 으로 돌리고 한글 원본을 물립니다.

    IL2CPP 게임은 폰트 구조를 못 읽습니다. 그래도 TextMeshPro 폰트의 **앞머리**
    순서는 정해져 있어서, 거기 있는 두 값만 바이트로 직접 고칠 수 있습니다.
    자세한 것은 :mod:`gameloc.tmpraw` 를 보세요. 길이가 안 변하는 수정이라
    뒤쪽 자료를 밀어내지 않습니다.
    """
    from . import tmpraw

    n = 0
    for o in objs:
        if o.type.name != "MonoBehaviour":
            continue
        try:
            raw = o.get_raw_data()
        except Exception:                               # noqa: BLE001
            continue
        head = tmpraw.read_head(raw)
        if head is None or not head.needs_help():
            continue
        low = head.name.lower()
        if any(w in low for w in _NOT_TEXT) or \
                not any(w in low for w in _LOOKS_TEXT):
            progress(f"  · 건너뜀(글자 폰트가 아님): {head.name}")
            continue
        try:
            o.set_raw_data(tmpraw.retarget(raw, head, donor_id))
        except Exception as exc:                        # noqa: BLE001
            rep.notes.append(f"{head.name} 을 못 고쳤습니다: {exc}")
            continue
        rep.retargeted.append(head.name)
        n += 1
        progress(f"  · 굳은 폰트를 풀었습니다: {head.name} → 한글 원본 물림")
    return n


def _make_readable(objs, names: list[str], progress) -> int:
    """푼 폰트의 그림판을 '읽고 쓸 수 있음' 으로 바꿉니다.

    TextMeshPro 가 실행 중에 글자를 그려 넣으려면 그림판을 읽을 수 있어야
    합니다. 빌드된 게임은 대체로 잠겨 있습니다. 잘 안 되면 그냥 넘어갑니다.
    """
    want = {f"{n} Atlas" for n in names}
    n = 0
    for o in objs:
        if o.type.name != "Texture2D":
            continue
        try:
            tree = o.read_typetree()
        except Exception:                               # noqa: BLE001
            continue
        if str(tree.get("m_Name") or "") not in want:
            continue
        if tree.get("m_IsReadable"):
            continue
        tree["m_IsReadable"] = 1
        try:
            o.save_typetree(tree)
        except Exception:                               # noqa: BLE001
            continue
        n += 1
        progress(f"  · 그림판을 열었습니다: {tree.get('m_Name')}")
    return n


def _fix_legacy(env, objs, p, ttf: Path, rep, *, dry_run: bool,
                unfreeze: bool = False, progress):
    """TextMeshPro 구조를 못 읽을 때의 우회로.

    IL2CPP 게임에서는 TextMeshPro 폰트가 MonoBehaviour 라 구조를 못 읽습니다.
    그러면 대체 폰트를 걸 방법이 없습니다. 그런데 유니티 **기본 클래스**인
    옛날식 ``Font`` 는 언제나 읽힙니다.

    TextMeshPro 의 기본 대체 폰트(``LiberationSans SDF - Fallback``)는
    Dynamic 이고 이 ``LiberationSans`` 를 원본으로 씁니다. 그래서 그 안의
    글꼴 파일만 한글 글꼴로 바꿔 두면, 없는 글자를 실행 중에 만들어냅니다.

    **장담은 못 합니다.** 그 대체 폰트가 실제로 걸려 있는지 확인할 방법이
    없기 때문입니다(구조를 못 읽으니까요). 기본 설정이면 되고, 개발자가
    대체 폰트 목록을 비웠으면 안 됩니다. 안 되면 되돌리기로 원상복구됩니다.
    """
    by_id = {o.path_id: o for o in objs}
    data = ttf.read_bytes()
    patched_ids: set[int] = set()
    for pid, name in p.legacy:
        obj = by_id.get(pid)
        if obj is None:
            continue
        try:
            tree = obj.read_typetree()
        except Exception:                               # noqa: BLE001
            continue
        if not _set_font_data(tree, data, ttf.stem):
            continue
        obj.save_typetree(tree)
        patched_ids.add(pid)
        rep.patched.append(name)
        progress(f"  · 유니티 기본 글꼴 교체: {name} ← {ttf.name}")

    if not rep.patched:
        rep.notes.append("유니티 기본 글꼴에도 글꼴 데이터가 없었습니다.")
        return rep, None
    rep.legacy_route = True

    # 굳어 있는(Static) 폰트를 풀어 줍니다. 기증자는 **이미 게임이 쓰고 있는**
    # 것을 고릅니다. 실제로 물려 있는 게 확인된 글꼴이라야 믿을 만합니다.
    # 굳은 폰트 풀기는 **위험합니다.** 실제 게임(Liar's Bar)에서 두 번
    # 확인했습니다: 풀면 게임이 켜지다 꺼지고, 안 풀면 멀쩡히 돕니다.
    # 이름 관문으로 폰트 아닌 것을 걸러도 결과는 같았습니다 — 진짜 폰트인
    # LiberationSans SDF · variex_regular SDF 만 풀어도 꺼졌습니다.
    #
    # 그래서 **이미 되는 폰트가 있으면 손대지 않습니다.** 그 경우 굳은
    # 폰트를 쓰는 화면만 □□□ 로 남지만, 게임이 아예 안 켜지는 것보다
    # 낫습니다. 되는 게 하나도 없을 때만 마지막 수로 풉니다.
    ready = dynamic_ready(objs)
    donor = _donor_font_id(objs, patched_ids) if (unfreeze or not ready) else 0
    if ready and unfreeze:
        rep.notes.append(
            "굳은 폰트도 풀라고 하셔서 풉니다. 게임이 안 켜지면 "
            "[원래대로] 를 누르고 이 설정을 끄세요.")
    elif ready:
        rep.notes.append(
            f"이 파일의 폰트 {ready}개는 이미 '실행 중에 그리기' 라, 방금 갈아친 "
            "글꼴을 그대로 씁니다. 굳어 있는 폰트는 그대로 두었습니다 — 그것까지 "
            "풀면 게임이 안 켜집니다. 그 폰트를 쓰는 화면이 있으면 거기만 "
            "□□□ 로 남습니다.")
    if donor:
        if _retarget_static(objs, rep, donor, progress):
            _make_readable(objs, rep.retargeted, progress)
            rep.notes.append(
                f"글자 그림이 통째로 구워져 있던 폰트 {len(rep.retargeted)}개를 "
                "'실행 중에 만들기' 로 돌리고 한글 글꼴을 물렸습니다. "
                "원래 있던 글자는 그대로 나오고, 없던 한글만 새로 그려집니다.")
    else:
        rep.notes.append(
            "한글을 넣어 줄 원본 글꼴이 없어, 굳은 폰트는 그대로 두었습니다.")

    rep.notes.append(
        "안 나오면 [원래대로 되돌리기] 를 누르세요. 파일은 그대로 있습니다.")
    if dry_run:
        return rep, None
    from .apply import _serialize
    return rep, _serialize(env)


def apply_to_file(target: Path, base_dir: Path, ttf: Path, *,
                  game_root: Path | None = None, unity_version: str = "",
                  dry_run: bool = False, unfreeze: bool = False,
                  progress=lambda m: None):
    """파일 하나를 고칩니다. ``(FontReport, 새 바이트 또는 None)``."""
    import UnityPy

    from . import typetree

    rep = FontReport(ttf=str(ttf))
    env = UnityPy.load(str(target), path=str(base_dir))
    # 폰트도 MonoBehaviour 입니다. 배포 빌드에는 그 구조가 안 들어 있어서
    # 게임 DLL 에서 되살리지 않으면 **폰트가 아예 안 보입니다.**
    typetree.attach(env, game_root or base_dir, unity_version)
    objs = list(env.objects)
    p = plan(objs)
    rep.notes = list(p.notes)

    if p.legacy_only():
        return _fix_legacy(env, objs, p, ttf, rep, dry_run=dry_run,
                           unfreeze=unfreeze, progress=progress)
    if not p.ok():
        return rep, None

    by_id = {o.path_id: o for o in objs}
    rep.donor = p.donor_name

    # ① 원본 글꼴 파일을 한글 글꼴로
    src = by_id.get(p.source_font_id)
    if src is None:
        rep.notes.append(f"원본 글꼴 오브젝트({p.source_font_id})를 못 찾았습니다.")
        return rep, None
    try:
        stree = src.read_typetree()
    except Exception as exc:                            # noqa: BLE001
        rep.notes.append(f"원본 글꼴을 읽지 못했습니다: {exc}")
        return rep, None
    if not _set_font_data(stree, ttf.read_bytes(), ttf.stem):
        rep.notes.append("이 글꼴 오브젝트에는 글꼴 데이터가 들어 있지 않습니다.")
        return rep, None
    src.save_typetree(stree)
    rep.source_font_name = str(stree.get("m_Name") or "")
    progress(f"  · 원본 글꼴 교체: {stree.get('m_Name')} ← {ttf.name}")

    # ② 한글 없는 폰트들에 대체 폰트로 걸기
    ptr = {"m_FileID": 0, "m_PathID": p.donor_path_id}
    for pid, name in p.targets:
        obj = by_id.get(pid)
        if obj is None:
            continue
        try:
            tree = obj.read_typetree()
        except Exception:                               # noqa: BLE001
            continue
        table = tree.get("m_FallbackFontAssetTable")
        if not isinstance(table, list):
            continue
        if any(_pptr_id(x) == p.donor_path_id for x in table):
            continue
        table.append(dict(ptr))
        tree["m_FallbackFontAssetTable"] = table
        obj.save_typetree(tree)
        rep.patched.append(name)
        progress(f"  · 대체 폰트 연결: {name} → {p.donor_name}")

    if not rep.patched or dry_run:
        return rep, None
    from .apply import _serialize
    return rep, _serialize(env)




def fix(root: Path, *, ttf: Path | None = None, dry_run: bool = False,
        unfreeze: bool = False, progress=lambda m: None) -> FontReport:
    """게임 폴더의 폰트를 고칩니다. 원본은 백업합니다.

    ``unfreeze`` 는 **위험한 마지막 수**입니다. 글자 그림이 통째로 구워진
    폰트를 '실행 중에 그리기' 로 돌립니다. 그 폰트를 쓰는 화면의 □□□ 가
    풀릴 수도 있지만, 실제 게임에서 두 번 다 게임이 안 켜졌습니다.
    그래서 기본은 꺼 두고, 사람이 알고 켤 때만 합니다.
    """
    from .apply import _backup
    from .detect import detect

    info = detect(root)
    if info.engine not in ("unity", "renpy"):
        rep = FontReport()
        rep.notes.append("유니티와 Ren'Py 게임에서만 됩니다.")
        return rep

    font = Path(ttf) if ttf else find_system_font()
    if font is None or not Path(font).is_file():
        rep = FontReport(engine=info.engine)
        rep.notes.append("이 컴퓨터에서 한글 글꼴을 찾지 못했습니다. "
                         "글꼴 파일(.ttf/.otf)을 직접 골라주세요.")
        return rep
    font = Path(font)
    progress(f"쓸 글꼴: {font}")

    if info.engine == "renpy":
        return _fix_renpy(info, font, auto=ttf is None,
                          dry_run=dry_run, progress=progress)

    merged = FontReport(ttf=str(font))
    for path in info.asset_files:
        try:
            rep, data = apply_to_file(path, path.parent, font,
                                      game_root=info.root,
                                      unity_version=info.unity_version,
                                      dry_run=dry_run, unfreeze=unfreeze,
                                      progress=progress)
        except Exception as exc:                        # noqa: BLE001
            merged.notes.append(f"{path.name}: {type(exc).__name__}: {exc}")
            continue
        if rep.patched:
            if rep.donor:
                merged.donor = rep.donor
            merged.legacy_route = merged.legacy_route or rep.legacy_route
            merged.retargeted += rep.retargeted
            merged.patched += rep.patched
            if data is not None:
                _backup(path, info.root)
                path.write_bytes(data)
                merged.changed_files.append(str(path.relative_to(info.root)))
                progress(f"  ✓ {path.relative_to(info.root)}")
        merged.notes += rep.notes

    # 파일마다 같은 말이 반복되면 읽기만 어렵습니다.
    seen: set[str] = set()
    merged.notes = [n for n in merged.notes
                    if not (n in seen or seen.add(n))]
    return merged


# ---------------------------------------------------------------- Ren'Py

def _fix_renpy(info, font: Path, *, auto: bool = False, dry_run: bool = False,
               progress=lambda m: None) -> FontReport:
    """Ren'Py 는 유니티와 딴판이라 방법도 다릅니다.

    유니티는 글꼴이 게임 파일 **안에** 구워져 있어서 파일을 뜯어고쳐야 했지만,
    Ren'Py 는 ``game/`` 안의 글꼴 **파일**을 이름으로 불러다 씁니다. 그래서
    한글 글꼴을 하나 넣어 두고 "이 이름으로 부르면 저걸 줘라" 하고 일러두면
    끝입니다. ``config.font_replacement_map`` 이 바로 그 자리입니다.

    원본은 하나도 안 건드립니다. 파일 두 개가 새로 생길 뿐이고, 되돌리기는
    그 둘을 지우는 것으로 끝납니다.
    """
    from .apply import _remember_added
    from .engines import renpy

    rep = FontReport(ttf=str(font), engine="renpy")
    game = info.rp_game
    if game is None:
        rep.notes.append("Ren'Py 의 game 폴더를 찾지 못했습니다.")
        return rep

    # 글꼴 모음(.ttc)은 첫 번째 글꼴만 쓰이므로, 우리가 알아서 고른 경우라면
    # 낱개 글꼴이 있는지 한 번 더 봅니다. 사용자가 직접 고른 건 존중합니다.
    if auto and font.suffix.lower() == ".ttc":
        from .fontlist import scan
        try:
            alt = next((Path(f.path) for f in scan()
                        if Path(f.path).suffix.lower() in (".ttf", ".otf")), None)
        except Exception:                               # noqa: BLE001
            alt = None
        if alt is not None:
            progress(f"글꼴 모음 대신 낱개 글꼴을 씁니다: {alt.name}")
            font = alt
            rep.ttf = str(font)

    suffix = font.suffix.lower()
    if suffix not in renpy.FONT_SUFFIXES:
        rep.notes.append(f"{suffix} 는 Ren'Py 가 읽지 못하는 형식입니다. "
                         ".ttf 나 .otf 를 골라주세요.")
        return rep
    if suffix == ".ttc":
        rep.notes.append("글꼴 모음(.ttc)은 Ren'Py 가 첫 번째 글꼴만 씁니다. "
                         "원하는 모양이 아니면 .ttf 를 골라보세요.")

    names = renpy.font_names(game)
    rep.patched = names
    rep.donor = font.stem
    have = renpy.font_files(game)
    progress(f"게임이 부르는 글꼴 {len(names)}개 "
             f"(game 폴더 안 글꼴 파일 {len(have)}개)")

    if dry_run:
        return rep

    dest = game / (renpy.FONT_BASE + suffix)
    hook = game / renpy.FONT_RPY
    try:
        dest.write_bytes(font.read_bytes())
        hook.write_text(renpy.font_hook_source(dest.name, names), "utf-8")
    except OSError as exc:
        rep.notes.append(f"파일을 넣지 못했습니다: {exc}")
        return rep

    # 전에 넣은 후크의 컴파일본이 남아 있으면 옛 설정이 되살아납니다.
    stale = game / (renpy.FONT_RPY + "c")
    if stale.is_file():
        try:
            stale.unlink()
        except OSError:
            pass

    root = Path(info.root)
    try:
        _remember_added(root, [dest, hook])
    except Exception as exc:                            # noqa: BLE001
        rep.notes.append(f"되돌리기 목록에 적지 못했습니다: {exc}")

    for p in (dest, hook):
        rep.changed_files.append(str(p.relative_to(root)))
        progress(f"  ✓ {p.relative_to(root)}")
    return rep
