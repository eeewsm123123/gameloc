# Gameloc — 게임 폴더를 넣으면 번역해 주는 도구
# Copyright (C) 2026  하진
#
# 이 프로그램은 자유 소프트웨어입니다. 자유 소프트웨어 재단이 펴낸 GNU 일반
# 공중 사용 허가서 3판 또는 그 이후 판의 조건에 따라 재배포하거나 고칠 수
# 있습니다.
#
# 이 프로그램은 쓸모가 있기를 바라며 배포하지만 어떠한 보증도 하지 않습니다.
# 자세한 내용은 GNU 일반 공중 사용 허가서를 보세요.
# 함께 받은 LICENSE 파일에 전문이 있습니다. <https://www.gnu.org/licenses/>

"""번역할 만한 문자열인지 점수를 매깁니다 (유니티 쪽에서 주로 씁니다).

게임 빌드에는 사람이 읽을 텍스트가 아닌 문자열이 훨씬 많습니다 — 셰이더 키워드,
에셋 경로, GUID, 열거형 이름. 전부 쏟아내면 진짜 대사 300줄이 4만 줄에 묻힙니다.
"""

from __future__ import annotations

import re

LEVELS = {"loose": 0.20, "normal": 0.45, "strict": 0.70}

# 타입트리 안에서 사람이 읽을 텍스트가 절대 아닌 필드 이름
KEY_DENYLIST = {
    "m_Name", "m_Guid", "m_Tag", "m_TagString", "m_Layer", "m_LayerName",
    "m_SortingLayerName", "m_ShaderKeywords", "m_AssetBundleName",
    "m_AssetBundleVariant", "m_PathName", "m_ClassName", "m_Namespace",
    "m_AssemblyName", "assetPath", "path", "guid", "fileID", "typeName",

    # --- 유니티 입력 시스템 ------------------------------------------------
    # 여기 값들은 화면 문구처럼 생겼지만("Button", "Hold", "Move", "Attack")
    # 사실은 **입력을 이어주는 이름**입니다. 번역하면 클릭·키 입력이 어디로도
    # 연결되지 않아 **버튼이 안 눌립니다.** 게임은 멀쩡히 켜지고 화면도 정상이라
    # 원인을 찾기가 아주 어렵습니다.
    "m_ExpectedControlType", "m_Interactions", "m_Processors",
    "m_Path", "m_Groups", "m_Action", "m_BindingGroup", "m_ControlPath",
    "m_DevicePath", "m_Type", "m_Id", "m_Flags", "m_SingletonAction",
    "m_ActionMaps", "m_ControlSchemes", "m_DeviceRequirements",
    "m_BindingMask", "m_ProcessorsString", "m_InteractionsString",

    # .NET 타입 이름. 어느 게임에서든 화면에 안 나옵니다.
    "m_TypeString", "m_TypeName", "m_ObjectType",
}

_CJK = re.compile(r"[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uac00-\ud7af\uf900-\ufaff]")
_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_CAMEL = re.compile(r"^[a-z]+(?:[A-Z][a-z0-9]*)+$")
_PASCAL_TOKEN = re.compile(r"^(?:[A-Z][a-z0-9]*){2,}$")
_HEXISH = re.compile(r"^[0-9a-fA-F\-]{8,}$")
_ID_CODE = re.compile(r"^[A-Za-z_]{1,6}[-_]?\d{1,6}$")
# 밑줄로 이어붙인 이름은 문장이 아니라 에셋·모델·모션 이름입니다.
# 일본어로 되어 있어도 마찬가지입니다:  海の家_波_木の揺れ
# 밑줄만 봅니다. 하이픈은 진짜 문구에도 흔합니다("Auto-Save", "Re-try").
_SNAKEY = re.compile(r"^\S*_\S*$")
_SENTENCE_MARK = re.compile(r"[\u3002\u3001\uff01\uff1f\u2026.!?,]")
_NUMERIC = re.compile(r"^[\d\s.,:;+\-*/%()\[\]#]+$")
_URL = re.compile(r"^\w+://|^www\.", re.I)
_PATHY = re.compile(r"[/\\]")
_EXT = re.compile(r"\.(png|jpg|jpeg|tga|wav|ogg|mp3|mp4|asset|prefab|unity|mat|"
                  r"anim|controller|fbx|shader|dll|txt|json|csv|bytes|ttf|otf)$", re.I)
_FORMAT_ONLY = re.compile(r"^[\s{}\[\]<>%$#@|_+=~^&*\\/,.:;!?'\"`-]*$")
_TAG_ONLY = re.compile(r"^\s*<[^>]+>\s*$")

# 구조가 통째로 딸려온 줄. 줄 단위로 쪼갠 설정 파일에서 나옵니다:
#     "バージョン": {          "items": [          },
# 이걸 번역하면 게임이 값을 못 찾습니다. 대사에는 이런 모양이 없습니다.
_STRUCTURE = re.compile(
    r"""^\s*(?:
          [\]\}\[\{,;]+                       # 괄호·쉼표만
        | ["'][^"']*["']\s*:\s*[\[\{]?\s*,?   # "키": 또는 "키": {
        | ["'][^"']*["']\s*:\s*.*[\[\{]\s*,?  # "키": ... {
        | ["'][^"']*["']\s*:\s*["'][^"']*["']\s*,?   # "키": "값",
        | ["'][^"']*["']\s*:\s*[\d.eE+-]+\s*,?       # "키": 12,
        | ["'][^"']*["']\s*:\s*(?:true|false|null)\s*,?
        | <[/!?][^>]*>                        # </닫는태그>
    )\s*$""",
    re.X,
)


def looks_like_identifier(text: str) -> bool:
    """대사가 아니라 '무언가를 가리키는 이름' 으로 보이는가.

    번역하면 안 되는 것들입니다 — 모델 이름, 모션 이름, 스위치 이름, 파일 키.
    판단 근거는 언어가 아니라 **모양**입니다:
      · 밑줄로 토막이 이어져 있고
      · 공백이 없고
      · 문장 부호가 없다
    """
    s = (text or "").strip()
    if not s or len(s) > 80:
        return False
    if " " in s or "\n" in s or "\t" in s:
        return False
    if _SENTENCE_MARK.search(s):
        return False
    return bool(_SNAKEY.match(s))


def score(text: str) -> float:
    """``text`` 가 사람이 읽을, 화면에 나오는 문구일 확신도."""
    if text is None:
        return 0.0
    s = text.strip()
    if not s:
        return 0.0

    if _FORMAT_ONLY.match(s) or _TAG_ONLY.match(s):
        return 0.0
    # 언어와 무관하게, 파일 구조가 딸려온 줄은 대사가 아닙니다.
    # CJK 검사보다 **먼저** 와야 합니다 — 키 이름이 일본어인 경우가 많습니다.
    if _STRUCTURE.match(s):
        return 0.0
    if _URL.search(s) or _EXT.search(s):
        return 0.0
    if _HEXISH.match(s) and not _CJK.search(s):
        return 0.0
    if _NUMERIC.match(s):
        return 0.0
    if _PATHY.search(s) and " " not in s and not _CJK.search(s):
        return 0.0

    # 식별자 모양이면 언어와 무관하게 거부.
    # 이 검사는 CJK 검사보다 **먼저** 와야 합니다. 게임의 에셋·모델 이름은
    # 일본어인 경우가 많고(예: 海の家_波_木の揺れ), 그걸 번역하면 플러그인이
    # 대상을 못 찾아 게임이 죽습니다. 대사가 밑줄로 이어진 경우는 없습니다.
    if looks_like_identifier(s):
        return 0.15

    cjk = len(_CJK.findall(s))
    if cjk:
        return min(1.0, 0.75 + 0.05 * min(cjk, 5))

    if len(s) < 2:
        return 0.0

    words = s.split()
    if sum(c.isalpha() for c in s) == 0:
        return 0.0

    if len(words) == 1:
        w = s
        if _ID_CODE.match(w):
            return 0.05            # d001, npc12 — 행 키
        if _CAMEL.match(w) or _PASCAL_TOKEN.match(w):
            return 0.10
        if "_" in w and _IDENT.match(w):
            return 0.05
        if _IDENT.match(w):
            if w.islower():
                # name, desc, speaker — 대개 열 이름. loose 에서만 잡힙니다.
                return 0.35
            return 0.50 if 3 <= len(w) <= 20 else 0.25
        return 0.30

    val = 0.55
    if len(words) >= 3:
        val += 0.15
    if re.search(r"[.!?\u2026]", s):
        val += 0.10
    if s[:1].isupper() and any(c.islower() for c in s):
        val += 0.10
    if len(s) > 40:
        val += 0.05
    if all(_IDENT.match(w) and w.isupper() for w in words):
        val -= 0.35
    return max(0.0, min(1.0, val))


# ── 유니티 Localization 전용 ──────────────────────────────────────────────
#
# 여기 규칙은 **그 표를 알아본 오브젝트에만** 적용합니다. 전역 목록에 섞으면
# 안 됩니다. 한 게임 때문에 만든 규칙이 다른 게임의 멀쩡한 대사를 조용히
# 걸러내기 시작하고, 그렇게 쌓인 규칙 서른 개는 아무도 못 풉니다.
#
# 이 시스템은 이름표(키)와 번역문을 따로 들고 다닙니다.
#
#     SharedTableData.m_Entries[i].m_Key      "MainMenu_EnterBar"  <- 이름표
#     StringTable.m_TableData[i].m_Localized  "ENTER THE BAR"      <- 번역문
#
# 게임은 이름표로 번역문을 찾습니다. 이름표를 번역하면 짝이 끊겨 표 전체가
# 안 나옵니다 —  No translation found for 'Velvet Room' in Menu
LOCALIZATION_FIELDS = {
    "m_Key", "m_KeyId", "m_TableCollectionName",
    "m_TableCollectionNameGuidString", "m_LocaleId", "m_Code",
    "m_LocaleName", "m_CustomFormatterName", "m_SharedTableDataGuid",
    "m_KeyGenerator",
}

# 이 필드들이 함께 보이면 유니티 Localization 표입니다.
_LOCALIZATION_MARKS = (
    {"m_TableData", "m_SharedData"},        # StringTable
    {"m_Entries", "m_TableCollectionName"},  # SharedTableData
)


def is_localization_table(tree) -> bool:
    """이 오브젝트가 유니티 Localization 의 표인가."""
    if not isinstance(tree, dict):
        return False
    keys = set(tree)
    return any(mark <= keys for mark in _LOCALIZATION_MARKS)


def denies_in_localization(path: str) -> bool:
    """Localization 표 **안에서만** 막을 필드인가."""
    for part in path.split("."):
        if part.split("[")[0] in LOCALIZATION_FIELDS:
            return True
    return False


# 이 필드에 든 값은 **틀림없이 화면에 나오는 글자**입니다. 게임이 그렇게
# 설계했다고 스스로 밝히고 있는 자리라, 짐작으로 거를 이유가 없습니다.
#
#   StringTable.m_TableData[i].m_Localized   유니티 Localization 의 번역문
#
# 여기를 짐작에 맡기면 'EXIT', 'SETTINGS' 같은 대문자 라벨이 "이건 라벨이지
# 문장이 아니다" 로 걸러져 메뉴가 절반만 번역됩니다.
KEY_ALLOWLIST = {
    "m_Localized", "m_LocalizedString", "m_Text", "m_TranslatedValue",
}


def is_display_key(path: str) -> bool:
    """짐작 없이 그대로 가져와도 되는, 확실한 화면 문구 필드인가."""
    tail = path.rsplit(".", 1)[-1].split("[")[0]
    return tail in KEY_ALLOWLIST


def is_denied_key(path: str) -> bool:
    """경로 **어느 마디라도** 알려진 비-텍스트 필드인가.

    마지막 마디만 보면 ``m_KeyGenerator.m_Something`` 처럼 한 겹 안쪽에 숨은
    값을 놓칩니다. 살림살이 밑에 딸린 것은 통째로 살림살이입니다.
    """
    for part in path.split("."):
        if part.split("[")[0] in KEY_DENYLIST:
            return True
    return False
