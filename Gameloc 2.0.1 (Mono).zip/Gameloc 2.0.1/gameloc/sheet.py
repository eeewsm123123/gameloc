# Gameloc — 게임 폴더를 넣으면 번역해 주는 도구
# Copyright (C) 2026  하진
#
# 이 프로그램은 자유 소프트웨어입니다. 자유 소프트웨어 재단이 펴낸 GNU 일반
# 공중 사용 허가서 3판 또는 그 이후 판의 조건에 따라 재배포하거나 고칠 수
# 있습니다.
#
# 이 프로그램은 쓸모가 있기를 바라며 배포하지만 어떠한 보증도 하지 않습니다.
# 자세한 내용은 GNU 일반 공중 사용 허가서를 보세요.
# 함께 받은 LICENSE 파일에 전문이 있습니다. <https://www.gnu.org/licenses/>

"""번역 워크북: 원문 한 줄 = 한 행, 언어 하나 = 한 열.

왕복에 중요한 규칙:

* A열의 ID 가 ``project.json`` 으로 돌아가는 유일한 열쇠입니다. 행을 정렬·필터·
  숨기는 건 자유지만 지우면 안 되고, ID 를 고쳐서도 안 됩니다.
* 언어 열은 **위치가 아니라 머리글 이름** 으로 찾습니다. 번역자가 아무 데나
  새 언어 열을 끼워 넣어도 찾아냅니다.
* 도구가 쓴 칸은 회색, 사람이 채울 칸은 노란색입니다.
"""

from __future__ import annotations

from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Protection, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.protection import SheetProtection

from . import privacy as _privacy
from .model import Entry, Project

SHEET_MAIN = "번역"
SHEET_INFO = "정보"

FIXED_HEADERS = ["ID", "횟수", "위치", "원문"]
TAIL_HEADERS = ["검토", "메모"]

FONT = "Arial"
HEAD_FILL = PatternFill("solid", fgColor="2F3B52")
LOCKED_FILL = PatternFill("solid", fgColor="F2F2F2")
INPUT_FILL = PatternFill("solid", fgColor="FFF9D6")
THIN = Side(style="thin", color="D0D0D0")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


def write_workbook(proj: Project, path: Path, *, max_rows: int | None = None) -> Path:
    wb = Workbook()
    ws = wb.active
    ws.title = SHEET_MAIN

    headers = FIXED_HEADERS + list(proj.languages) + TAIL_HEADERS
    ws.append(headers)
    for c in range(1, len(headers) + 1):
        cell = ws.cell(row=1, column=c)
        cell.font = Font(name=FONT, bold=True, color="FFFFFF", size=10)
        cell.fill = HEAD_FILL
        cell.alignment = Alignment(vertical="center", horizontal="center")
        cell.border = BORDER
    ws.row_dimensions[1].height = 22

    entries = proj.entries[:max_rows] if max_rows else proj.entries
    lang_start = len(FIXED_HEADERS) + 1

    for e in entries:
        loc = e.locations[0].label() if e.locations else ""
        if e.count > 1:
            loc += f" 외 {e.count - 1}곳"
        row = [e.id, e.count, loc, e.text]
        row += [e.translations.get(lg, "") for lg in proj.languages]
        row += ["기계" if e.machine else "", e.note]
        ws.append(row)

    last = ws.max_row
    for r in range(2, last + 1):
        for c in range(1, len(headers) + 1):
            cell = ws.cell(row=r, column=c)
            cell.font = Font(name=FONT, size=10)
            cell.border = BORDER
            is_input = (lang_start <= c < lang_start + len(proj.languages)
                        or c == len(headers))
            cell.fill = INPUT_FILL if is_input else LOCKED_FILL
            cell.alignment = Alignment(
                vertical="top",
                wrap_text=c >= len(FIXED_HEADERS),
                horizontal="center" if c == 2 else "left",
            )
            cell.protection = Protection(locked=not is_input)

    widths = {1: 12, 2: 7, 3: 46, 4: 60}
    for i in range(len(proj.languages)):
        widths[lang_start + i] = 60
    widths[len(headers)] = 24
    for col, w in widths.items():
        ws.column_dimensions[get_column_letter(col)].width = w

    ws.freeze_panes = f"{get_column_letter(lang_start)}2"
    if last >= 2:
        ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{last}"
    ws.protection = SheetProtection(
        sheet=True, password=None, formatCells=False, formatColumns=False,
        formatRows=False, sort=True, autoFilter=False,
    )

    _write_info(wb, proj, shown=len(entries))
    wb.save(path)
    return path


def _write_info(wb: Workbook, proj: Project, shown: int) -> None:
    ws = wb.create_sheet(SHEET_INFO)
    rows = [
        ("사용법", ""),
        ("", "노란색 칸에만 번역을 입력하세요. ID·원문·위치 칸은 수정하면 안 됩니다."),
        ("", "행을 지우지 마세요. 번역하지 않은 행은 비워두면 원문이 그대로 유지됩니다."),
        ("", "언어를 추가하려면 헤더에 새 열을 만들고 언어 코드(예: ja, en)를 적으세요."),
        ("", "저장한 뒤 번역기에서 [엑셀 ↑] 를 누르면 읽어옵니다."),
        ("", ""),
        ("예시", ""),
        ("원문 예", "Press any key to continue"),
        ("번역 예", "아무 키나 누르세요"),
        ("", ""),
        ("게임 폴더", _privacy.scrub(proj.game_root)),
        ("엔진", f"{proj.engine} {proj.unity_version}".strip()),
        ("추출 시각", proj.generated_at),
        ("언어 열", ", ".join(proj.languages)),
        ("표시된 행", f"{shown} / {len(proj.entries)}"),
        ("", ""),
        ("--- 스캔 통계 ---", ""),
    ]
    rows += [(k, str(v)) for k, v in sorted(proj.stats.items())]
    for r in rows:
        ws.append(list(r))
    for row in ws.iter_rows():
        for cell in row:
            cell.font = Font(name=FONT, size=10, bold=cell.column == 1)
            cell.alignment = Alignment(vertical="top", wrap_text=cell.column == 2)
    ws.column_dimensions["A"].width = 20
    ws.column_dimensions["B"].width = 90


def read_workbook(path: Path) -> tuple[dict[str, dict[str, str]], list[str]]:
    """``({entry_id: {lang: text}}, 찾은 언어들)``."""
    wb = load_workbook(path, data_only=True, read_only=True)
    if SHEET_MAIN not in wb.sheetnames:
        raise ValueError(f"'{SHEET_MAIN}' 시트를 찾을 수 없습니다: {path}")
    ws = wb[SHEET_MAIN]

    rows = ws.iter_rows(values_only=True)
    header = [str(h).strip() if h is not None else "" for h in next(rows)]
    known = set(FIXED_HEADERS) | set(TAIL_HEADERS)
    lang_cols = {h: i for i, h in enumerate(header) if h and h not in known}
    try:
        id_col = header.index("ID")
    except ValueError as e:
        raise ValueError("헤더에 'ID' 열이 없습니다. 첫 행을 지우지 마세요.") from e

    out: dict[str, dict[str, str]] = {}
    for row in rows:
        if row is None or id_col >= len(row):
            continue
        eid = row[id_col]
        if not eid:
            continue
        vals = {}
        for lang, ci in lang_cols.items():
            v = row[ci] if ci < len(row) else None
            if v is not None and str(v).strip() != "":
                vals[lang] = str(v)
        if vals:
            out[str(eid).strip()] = vals
    wb.close()
    return out, list(lang_cols.keys())


def merge_into_project(proj: Project, edits: dict[str, dict[str, str]]) -> int:
    by_id = {e.id: e for e in proj.entries}
    changed = 0
    for eid, vals in edits.items():
        e: Entry | None = by_id.get(eid)
        if e is None:
            continue
        for lang, text in vals.items():
            if e.translations.get(lang) != text:
                e.translations[lang] = text
                # 사람이 손으로 고친 것이므로 검토 대기 해제
                if lang in e.machine:
                    e.machine.remove(lang)
                changed += 1
            if lang not in proj.languages:
                proj.languages.append(lang)
    return changed
