# SPDX-License-Identifier: GPL-3.0-or-later
"""시험 전체에 걸리는 준비.

유니티 읽기는 평소 **딴 프로세스**에서 돕니다(gameloc/isolate.py). 그런데
시험은 대부분 이쪽 프로세스 안의 것을 바꿔치기해서 확인하므로, 자식이
그것을 볼 수 없습니다. 그래서 시험에서는 기본으로 끕니다.

딴 프로세스로 도는 길 자체는 tests/test_isolate.py 가 따로 지킵니다.
"""

import pytest


@pytest.fixture(autouse=True)
def _no_isolate(monkeypatch):
    monkeypatch.setenv("GAMELOC_NO_ISOLATE", "1")
