"""배치 파일 인코딩 — 한글 윈도우에서 cmd 가 읽을 수 있어야 합니다.

전에 UTF-8(BOM 포함)으로 넣었다가 실행이 통째로 깨졌습니다. cmd 는 배치
파일을 콘솔 코드페이지(한국 윈도우면 949)로 읽기 때문에, UTF-8 한글의
두 번째 바이트가 뒤따르는 영문을 삼켜서 ``python`` 이 ``hon`` 이 됩니다.
BOM 은 그 자체가 명령으로 읽힙니다.
"""

from __future__ import annotations

from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
BATS = sorted(ROOT.glob("*.bat"))


def test_there_are_batch_files():
    assert BATS, "배치 파일이 없습니다"


@pytest.mark.parametrize("path", BATS, ids=lambda p: p.name)
def test_no_bom(path: Path):
    assert not path.read_bytes().startswith(b"\xef\xbb\xbf"), \
        "BOM 이 있으면 cmd 가 그것부터 명령으로 읽습니다"


@pytest.mark.parametrize("path", BATS, ids=lambda p: p.name)
def test_readable_as_cp949(path: Path):
    data = path.read_bytes()
    text = data.decode("cp949")            # 여기서 터지면 한글 윈도우에서 깨집니다
    assert text.strip()                    # 빈 파일이면 아무 일도 안 합니다
    # UTF-8 로도 읽힌다면 순수 아스키뿐이라는 뜻 — 그것도 괜찮습니다.
    try:
        data.decode("ascii")
    except UnicodeDecodeError:
        with pytest.raises(UnicodeDecodeError):
            data.decode("utf-8")           # 한글이 들어 있다면 UTF-8 이면 안 됩니다


@pytest.mark.parametrize("path", BATS, ids=lambda p: p.name)
def test_crlf(path: Path):
    assert b"\r\n" in path.read_bytes(), "cmd 는 CRLF 를 기대합니다"


@pytest.mark.parametrize("path", BATS, ids=lambda p: p.name)
def test_first_line_is_plain_ascii(path: Path):
    first = path.read_bytes().split(b"\r\n", 1)[0]
    first.decode("ascii")


def test_every_shipped_name_is_ascii():
    """압축을 풀 때 이름이 깨지지 않도록, 배포 파일 이름은 전부 아스키."""
    skip = {".git", "__pycache__", "out", ".pytest_cache"}
    for p in ROOT.rglob("*"):
        if any(part in skip or part.endswith(".egg-info") for part in p.parts):
            continue
        p.name.encode("ascii")


def test_uninstaller_is_shipped():
    """제거기가 빠지면 사용자는 지우는 법을 모릅니다."""
    names = {p.name for p in BATS}
    assert "3_uninstall.bat" in names


def test_uninstaller_removes_the_key_file():
    """API 키가 든 설정 폴더를 반드시 지워야 합니다."""
    body = (ROOT / "3_uninstall.bat").read_bytes().decode("cp949")
    assert "pip uninstall -y gameloc" in body
    assert r"%USERPROFILE%\.gameloc" in body


def test_uninstaller_does_not_touch_game_backups():
    """게임 백업을 지우면 되돌릴 방법이 사라집니다."""
    body = (ROOT / "3_uninstall.bat").read_bytes().decode("cp949")
    assert "__gameloc_backup__" in body          # 안 지운다고 알려는 줍니다
    assert "rd /s /q" in body
    for line in body.splitlines():
        if "rd /s /q" in line or "del " in line:
            assert "__gameloc_backup__" not in line


def test_python_finder_is_shipped():
    """PATH 를 믿지 않고 파이썬을 찾는 공통 부품."""
    assert (ROOT / "_findpy.bat").exists()


def test_installer_does_not_trust_bare_python_command():
    """`python --version` 만 믿으면 스토어 껍데기에 속습니다."""
    body = (ROOT / "1_install.bat").read_bytes().decode("cp949")
    assert "_findpy.bat" in body
    for line in body.splitlines():
        stripped = line.strip()
        if stripped.startswith("rem") or stripped.startswith("echo"):
            continue
        assert not stripped.startswith("python "), line


def test_finder_skips_the_microsoft_store_stub():
    body = (ROOT / "_findpy.bat").read_bytes().decode("cp949")
    assert "WindowsApps" in body


def test_finder_searches_install_folders_directly():
    """winget 설치 직후에는 PATH 가 아직 갱신되지 않습니다."""
    body = (ROOT / "_findpy.bat").read_bytes().decode("cp949")
    assert r"%LOCALAPPDATA%\Programs\Python" in body
    assert "py -3" in body


def test_installer_retries_detection_after_installing():
    """설치 직후 다시 찾아보므로 창을 다시 열 필요가 없습니다."""
    body = (ROOT / "1_install.bat").read_bytes().decode("cp949")
    assert body.count("_findpy.bat") >= 2


def test_starter_uses_the_found_interpreter():
    body = (ROOT / "2_start.bat").read_bytes().decode("cp949")
    assert "_findpy.bat" in body
    assert "%PY% -m gameloc.webui" in body
