"""일괄 바꾸기 — 원문을 근거로 바꾸는지, 애먼 줄을 안 건드리는지.

자동번역이 ``coffee`` 를 ``호빵`` 으로 옮겨놨을 때, 번역문의 호빵만 보고
바꾸면 원문이 정말 ``あんまん``(호빵)이던 줄까지 커피가 됩니다. 이 검사들이
지키는 건 그 한 줄입니다.
"""

from __future__ import annotations

from gameloc import bulk
from gameloc.model import Entry


def make(pairs):
    out = []
    for i, (src, ko) in enumerate(pairs):
        e = Entry(id=f"e{i}", text=src)
        if ko:
            e.translations["ko"] = ko
        out.append(e)
    return out


ENTRIES = [
    ("Do you want some coffee?", "호빵 좀 드실래요?"),
    ("The coffee is cold.", "호빵이 식었어요."),
    ("あんまんを食べたい。", "호빵이 먹고 싶어."),          # 진짜 호빵
    ("I love tea.", "차를 좋아해요."),
    ("Coffee break!", "호빵 시간!"),                       # 대문자
    ("No translation yet", ""),
]


def test_only_lines_whose_source_has_the_word_are_touched():
    entries = make(ENTRIES)
    plan = bulk.plan(entries, "ko", source_has="coffee",
                     find="호빵", replace="커피")

    assert len(plan) == 3                      # 대문자 Coffee 도 포함
    changed = {c.source for c in plan.changes}
    assert "あんまんを食べたい。" not in changed, "진짜 호빵이 바뀌려 합니다"


def test_apply_changes_only_the_matched_lines():
    entries = make(ENTRIES)
    plan = bulk.plan(entries, "ko", source_has="coffee",
                     find="호빵", replace="커피")
    bulk.apply(entries, "ko", plan.changes)

    got = {e.text: e.translations.get("ko", "") for e in entries}
    assert got["Do you want some coffee?"] == "커피 좀 드실래요?"
    assert got["The coffee is cold."] == "커피가 식었어요."
    assert got["Coffee break!"] == "커피 시간!"
    assert got["あんまんを食べたい。"] == "호빵이 먹고 싶어."   # 그대로
    assert got["I love tea."] == "차를 좋아해요."


def test_plan_does_not_change_anything():
    entries = make(ENTRIES)
    before = [e.translations.get("ko") for e in entries]
    bulk.plan(entries, "ko", source_has="coffee", find="호빵", replace="커피")
    assert [e.translations.get("ko") for e in entries] == before


def test_undo_puts_everything_back():
    entries = make(ENTRIES)
    plan = bulk.plan(entries, "ko", source_has="coffee",
                     find="호빵", replace="커피")
    snap = bulk.apply(entries, "ko", plan.changes)
    assert bulk.undo(entries, "ko", snap) == 3
    assert [e.translations.get("ko") for e in entries] == \
        [ko or None for _s, ko in ENTRIES]


def test_without_a_source_condition_everything_matches():
    """원문 조건을 비우면 진짜 호빵도 바뀝니다 — 그래서 경고를 답니다."""
    entries = make(ENTRIES)
    plan = bulk.plan(entries, "ko", find="호빵", replace="커피")
    assert len(plan) == 4
    assert "원문 조건 없이" in plan.note


def test_case_sensitive_source():
    entries = make(ENTRIES)
    plan = bulk.plan(entries, "ko", source_has="Coffee", find="호빵",
                     replace="커피", case_sensitive=True)
    assert [c.source for c in plan.changes] == ["Coffee break!"]


def test_whole_word_only_binds_on_latin():
    entries = make([("a cat sat", "고양이"), ("concatenate", "고양이 이어붙이기")])
    plan = bulk.plan(entries, "ko", source_has="cat", find="고양이",
                     replace="냥이", whole_word=True)
    assert [c.source for c in plan.changes] == ["a cat sat"]


def test_korean_whole_word_still_matches():
    """한국어에는 낱말 경계가 잘 안 맞습니다. 켜도 막히면 안 됩니다."""
    entries = make([("coffee", "호빵을 마신다")])
    plan = bulk.plan(entries, "ko", source_has="coffee", find="호빵",
                     replace="커피", whole_word=True)
    assert len(plan) == 1


def test_untranslated_lines_are_never_touched():
    entries = make(ENTRIES)
    plan = bulk.plan(entries, "ko", source_has="translation",
                     find="호빵", replace="커피")
    assert len(plan) == 0


def test_a_line_edited_meanwhile_is_left_alone():
    """미리보기를 본 뒤 사람이 그 줄을 고쳤다면 덮어쓰지 않습니다."""
    entries = make(ENTRIES)
    plan = bulk.plan(entries, "ko", source_has="coffee",
                     find="호빵", replace="커피")
    entries[0].translations["ko"] = "직접 고친 번역"
    snap = bulk.apply(entries, "ko", plan.changes)

    assert entries[0].translations["ko"] == "직접 고친 번역"
    assert len(snap) == 2


def test_only_lets_you_pick_a_subset():
    entries = make(ENTRIES)
    plan = bulk.plan(entries, "ko", source_has="coffee",
                     find="호빵", replace="커피")
    snap = bulk.apply(entries, "ko", plan.changes, only={plan.changes[0].id})
    assert len(snap) == 1


def test_machine_flag_is_cleared():
    entries = make([("coffee", "호빵")])
    entries[0].machine.append("ko")
    plan = bulk.plan(entries, "ko", source_has="coffee",
                     find="호빵", replace="커피")
    bulk.apply(entries, "ko", plan.changes)
    assert "ko" not in entries[0].machine


def test_empty_find_is_refused():
    plan = bulk.plan(make(ENTRIES), "ko", find="", replace="커피")
    assert len(plan) == 0
    assert "바꿀 말" in plan.note


def test_regex_characters_are_literal():
    """사용자가 넣는 건 정규식이 아니라 **글자 그대로** 입니다."""
    entries = make([("price (usd)", "값 (달러)")])
    plan = bulk.plan(entries, "ko", source_has="(usd)", find="(달러)",
                     replace="(원)")
    assert len(plan) == 1
    bulk.apply(entries, "ko", plan.changes)
    assert entries[0].translations["ko"] == "값 (원)"


def test_summary_counts_places_not_just_lines():
    entries = make([("coffee coffee", "호빵과 호빵")])
    plan = bulk.plan(entries, "ko", source_has="coffee",
                     find="호빵", replace="커피")
    assert "1줄" in plan.summary() and "2군데" in plan.summary()
    bulk.apply(entries, "ko", plan.changes)
    # 조사까지 같이 맞춰줍니다: 호빵'과' → 커피'와'
    assert entries[0].translations["ko"] == "커피와 커피"


# ------------------------------------------------------------ 조사 맞추기

def test_josa_is_fixed_after_replacement():
    """호빵(받침 O) → 커피(받침 X). '커피이' 가 아니라 '커피가' 여야 합니다."""
    entries = make([("coffee", "호빵이 식었어요."),
                    ("coffee", "호빵을 마신다."),
                    ("coffee", "호빵은 뜨겁다."),
                    ("coffee", "호빵과 빵.")])
    plan = bulk.plan(entries, "ko", source_has="coffee",
                     find="호빵", replace="커피")
    bulk.apply(entries, "ko", plan.changes)
    got = [e.translations["ko"] for e in entries]
    assert got == ["커피가 식었어요.", "커피를 마신다.",
                   "커피는 뜨겁다.", "커피와 빵."]


def test_josa_fix_works_the_other_way_too():
    entries = make([("bun", "커피가 식었어요.")])
    plan = bulk.plan(entries, "ko", source_has="bun",
                     find="커피", replace="호빵")
    bulk.apply(entries, "ko", plan.changes)
    assert entries[0].translations["ko"] == "호빵이 식었어요."


def test_josa_fix_does_not_touch_a_real_word():
    """'커피이야기' 의 '이' 는 조사가 아닙니다."""
    entries = make([("coffee", "호빵이야기를 읽었다.")])
    plan = bulk.plan(entries, "ko", source_has="coffee",
                     find="호빵", replace="커피")
    bulk.apply(entries, "ko", plan.changes)
    assert entries[0].translations["ko"] == "커피이야기를 읽었다."


def test_josa_fix_can_be_turned_off():
    entries = make([("coffee", "호빵이 식었어요.")])
    plan = bulk.plan(entries, "ko", source_has="coffee",
                     find="호빵", replace="커피", josa=False)
    bulk.apply(entries, "ko", plan.changes)
    assert entries[0].translations["ko"] == "커피이 식었어요."


def test_josa_is_left_alone_for_non_korean_replacements():
    entries = make([("coffee", "호빵이 식었어요.")])
    plan = bulk.plan(entries, "ko", source_has="coffee",
                     find="호빵", replace="Coffee")
    bulk.apply(entries, "ko", plan.changes)
    assert entries[0].translations["ko"] == "Coffee이 식었어요."


def test_euro_ro_follows_the_rieul_rule():
    entries = make([("a", "집으로 간다"), ("b", "커피로 만든"), ("c", "서울으로")])
    for src, find, rep in (("a", "집", "커피"), ("b", "커피", "집"),
                           ("c", "서울", "부산")):
        plan = bulk.plan(entries, "ko", source_has=src, find=find, replace=rep)
        bulk.apply(entries, "ko", plan.changes)
    assert [e.translations["ko"] for e in entries] == \
        ["커피로 간다", "집으로 만든", "부산으로"]
