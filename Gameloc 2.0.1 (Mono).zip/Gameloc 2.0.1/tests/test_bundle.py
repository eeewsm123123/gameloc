# SPDX-License-Identifier: GPL-3.0-or-later
"""덩이(``data.unity3d``) 의 무게를 **들어 올리기 전에** 재기.

진짜 신고에서 나왔습니다. Mono 유니티 게임에서 문장 뽑기가 몇십 분째
파일 이름 하나만 띄우고 멈춰 있었습니다. 실제 파일은 2.4GB 짜리
``data.unity3d`` 하나였고, 멈춘 게 아니라 압축을 푸는 중이었습니다.

UnityPy 는 ``b"".join`` 으로 **덩이를 통째로 한 덩어리로** 만듭니다. 그게
끝나기 전에는 오브젝트가 하나도 안 보여서 안에서는 진행 표시를 할 수가
없습니다. 그래서 밖에서, 미리 재는 수밖에 없습니다.
"""

import struct
import zlib
from pathlib import Path

import pytest

from gameloc import bundle


def make_bundle(path: Path, blocks: list[int], engine: str = "2021.3.0f1",
                version: int = 6, at_end: bool = False) -> None:
    """진짜 UnityFS 덩이 하나. **압축 없이**(flags 0) 만듭니다.

    포맷은 UnityPy 의 ``BundleFile.read_fs`` 를 그대로 따라갑니다. 우리 재기가
    거기서 어긋나면 이 시험이 깨집니다 — 그게 이 시험의 값입니다.
    """
    info = bytearray()
    info += b"\x00" * 16                     # hash
    info += struct.pack(">i", len(blocks))
    for n in blocks:
        info += struct.pack(">II", n, n)     # uncompressed, compressed
        info += struct.pack(">H", 0)         # flags = 압축 없음
    info += struct.pack(">i", 1)             # 파일 하나
    info += struct.pack(">qqI", 0, sum(blocks), 4) + b"CAB-x\x00"

    flags = 0x80 if at_end else 0            # 0x80 = 블록 목록이 뒤에 있음
    head = bytearray()
    head += b"UnityFS\x00"
    head += struct.pack(">I", version)
    head += b"5.x.x\x00"
    head += engine.encode() + b"\x00"
    head += struct.pack(">q", 0)             # 전체 크기 (안 씁니다)
    head += struct.pack(">III", len(info), len(info), flags)
    # UnityPy 와 **같은 조건**으로 정렬합니다. 판이 6이어도 2019.4.15 이상은
    # 정렬하는 게임이 있어서, 조건이 어긋나면 우리 재기가 헛다리를 짚습니다.
    ver = tuple(int(x) for x in engine.replace("f", ".").split(".")[:3] if x.isdigit())
    if version >= 7 or (ver[:1] == (2019,) and ver >= (2019, 4, 15)):
        head += b"\x00" * (-len(head) % 16)
    body = b"\x00" * sum(blocks)
    if at_end:
        path.write_bytes(bytes(head) + body + bytes(info))
    else:
        path.write_bytes(bytes(head) + bytes(info) + body)


# ── 재기 ─────────────────────────────────────────────────────────────────

@pytest.mark.parametrize("version,engine,at_end", [
    (6, "2021.3.0f1", False),
    (7, "2021.3.0f1", False),
    (7, "2021.3.0f1", True),         # 블록 목록이 파일 **뒤**에 있는 판
    (8, "6000.3.18f1", True),        # 실제로 막혔던 게임이 이 모양입니다
    (6, "2019.4.20f1", False),       # 판은 6인데 정렬은 하는 예외
])
def test_it_reads_the_real_size_without_unpacking(tmp_path, version, engine, at_end):
    """덩이의 생김새는 유니티 판마다 다릅니다. 하나만 맞춰 놓으면
    정작 막힌 게임(유니티 6000)에서 조용히 0 이 나옵니다."""
    p = tmp_path / "data.unity3d"
    make_bundle(p, [1024, 2048, 4096], engine=engine, version=version, at_end=at_end)
    w = bundle.weigh(p)
    assert w.is_bundle, w.why_unknown
    assert w.uncompressed == 7168
    assert w.blocks == 3


def test_a_huge_bundle_is_measured_in_no_time(tmp_path):
    """조각이 많아도 **블록 목록만** 읽으므로 즉시 끝나야 합니다."""
    import time

    p = tmp_path / "data.unity3d"
    make_bundle(p, [4096] * 5000)
    began = time.monotonic()
    w = bundle.weigh(p)
    assert w.uncompressed == 4096 * 5000
    assert time.monotonic() - began < 2.0


def test_something_that_is_not_a_bundle_is_left_alone(tmp_path):
    """``.assets`` 는 덩이가 아닙니다. 예전처럼 그냥 열면 됩니다."""
    p = tmp_path / "resources.assets"
    p.write_bytes(b"\x00" * 500)
    w = bundle.weigh(p)
    assert not w.is_bundle and w.trouble() == ""


def test_a_broken_bundle_does_not_raise(tmp_path):
    """재다가 터져서 전체가 멈추면 안 됩니다 — 재기는 곁다리입니다."""
    p = tmp_path / "data.unity3d"
    p.write_bytes(b"UnityFS\x00" + b"\xff" * 200)
    w = bundle.weigh(p)
    assert not w.is_bundle
    assert w.why_unknown, "왜 못 쟀는지는 남겨야 합니다"


# ── 재고 나서 무슨 말을 하는가 ───────────────────────────────────────────

def _weight(uncompressed: int, ram: int, bits: int = 64) -> bundle.Weight:
    return bundle.Weight(path=Path("data.unity3d"), compressed=uncompressed // 2,
                         uncompressed=uncompressed, blocks=10, ram=ram, bits=bits)


def test_32bit_python_is_told_it_will_never_work(tmp_path):
    """2GB 벽은 기다린다고 넘어가지지 않습니다. 40분 쓰고 죽느니 지금 말합니다."""
    w = _weight(3 * 1024 ** 3, 16 * 1024 ** 3, bits=32)
    assert "32비트" in w.trouble() and "64비트" in w.trouble()


def test_not_enough_memory_says_so_before_we_start(tmp_path):
    w = _weight(3 * 1024 ** 3, 8 * 1024 ** 3)
    said = w.trouble()
    assert said
    assert "6.9GB" in said and "8.0GB" in said


def test_a_tight_fit_is_a_warning_not_a_refusal():
    # 3GB 덩이는 잠깐 6.9GB 를 먹습니다. 9GB 짜리 컴퓨터면 되기는 되는데
    # 브라우저 하나만 켜져 있어도 위태롭습니다. 막지 말고 알려만 줍니다.
    w = _weight(3 * 1024 ** 3, 9 * 1024 ** 3)
    assert "다른 프로그램을 닫아" in w.trouble()


def test_plenty_of_memory_says_nothing():
    assert _weight(1024 ** 3, 32 * 1024 ** 3).trouble() == ""


def test_the_headline_gives_a_time_not_just_a_number():
    """'2.4GB' 만으로는 기다릴지 끌지를 못 정합니다."""
    said = _weight(3 * 1024 ** 3, 32 * 1024 ** 3).headline()
    assert "3.0GB" in said
    assert "분" in said or "시간" in said


def test_the_two_times_bigger_rule_is_not_forgotten():
    """``b"".join`` 때문에 잠깐 두 배가 듭니다. 푼 크기만 보면 안 됩니다."""
    w = _weight(4 * 1024 ** 3, 64 * 1024 ** 3)
    assert w.needs > w.uncompressed * 2
