"""End-to-end: a fake game folder goes in, an xlsx comes out, edits go back in.

The Unity binary layer is replaced by a JSON-backed stand-in that implements the
exact ObjectReader surface gameloc uses (``type.name``, ``path_id``,
``read()``, ``read_typetree()``, ``save_typetree()``, ``env.file.save()``).
That exercises every line of gameloc's own extract/apply plumbing — object
discovery, pointer math, dedup grouping, backup, restore — without needing a
real shipped game. Loose StreamingAssets files are patched for real.
"""

from __future__ import annotations

import json
import types
from pathlib import Path

import pytest

from gameloc.apply import apply as apply_translations
from gameloc.apply import restore
from gameloc.extract import extract
from gameloc.model import Project
from gameloc.sheet import merge_into_project, read_workbook, write_workbook


# --------------------------------------------------------------------------
# fake Unity layer
# --------------------------------------------------------------------------
class FakeObj:
    def __init__(self, env, d):
        self._env, self._d = env, d
        self.type = types.SimpleNamespace(name=d["type"])
        self.path_id = d["path_id"]

    def read(self):
        return types.SimpleNamespace(**self._d["tree"])

    def read_typetree(self):
        return json.loads(json.dumps(self._d["tree"]))

    def save_typetree(self, tree):
        self._d["tree"] = tree
        self._env.changed = True


class FakeFile:
    def __init__(self, env):
        self.env = env

    def save(self, packer=None):
        if packer == "original":      # exercise the packer fallback chain
            raise NotImplementedError("original")
        return json.dumps(self.env.doc, ensure_ascii=False).encode("utf-8")


class FakeEnv:
    # 첫 인자 이름을 path 로 두면 UnityPy.load(파일, path=폴더) 와 부딪힙니다.
    def __init__(self, source, **kwargs):
        # 진짜 UnityPy.load 처럼 경로도 받고, 바이트 스트림도 받습니다.
        # (쓰기 전 검증이 방금 만든 바이트를 그대로 다시 읽습니다.)
        if hasattr(source, "read"):
            raw = source.read()
            raw = raw.decode("utf-8") if isinstance(raw, bytes) else raw
        else:
            raw = Path(source).read_text("utf-8")
        self.doc = json.loads(raw)
        self.objects = [FakeObj(self, d) for d in self.doc["objects"]]
        self.file = FakeFile(self)
        self.changed = False


@pytest.fixture
def fake_unity(monkeypatch):
    import UnityPy
    monkeypatch.setattr(UnityPy, "load", lambda src, **k: FakeEnv(src))
    return UnityPy


# --------------------------------------------------------------------------
# fixture game
# --------------------------------------------------------------------------
@pytest.fixture
def game(tmp_path: Path) -> Path:
    root = tmp_path / "MyGame"
    data = root / "MyGame_Data"
    (data / "StreamingAssets" / "loc").mkdir(parents=True)
    (data / "Managed").mkdir()
    (data / "Managed" / "Assembly-CSharp.dll").write_bytes(b"\x00")
    (data / "globalgamemanagers").write_bytes(b"junk 2021.3.16f1 junk" + b"\x00" * 64)

    (data / "StreamingAssets" / "loc" / "ui.json").write_text(
        json.dumps({"start": "Start Game", "quit": "Quit to Desktop",
                    "icon": "Assets/UI/icon.png"}, ensure_ascii=False),
        "utf-8")
    (data / "StreamingAssets" / "loc" / "dialogue.csv").write_text(
        "id,text\nd1,Hello there traveller\nd2,Quit to Desktop\n", "utf-8")

    (data / "resources.assets").write_text(json.dumps({"objects": [
        {"path_id": 11, "type": "TextAsset",
         "tree": {"m_Name": "items", "m_Script":
                  "id,name\n1,Healing Potion\n2,Quit to Desktop\n"}},
        {"path_id": 12, "type": "MonoBehaviour",
         "tree": {"m_Name": "UITexts", "m_GameObject": {"m_PathID": 0},
                  "entries": [{"key": "hp_label", "value": "Health Points"},
                              {"key": "mp_label", "value": "Magic Points"}],
                  "m_Guid": "a1b2c3d4e5f60718"}},
        {"path_id": 13, "type": "Texture2D", "tree": {"m_Name": "atlas"}},
    ]}, ensure_ascii=False), "utf-8")
    return root


# --------------------------------------------------------------------------
def test_extract_finds_text_and_skips_noise(game, fake_unity):
    proj = extract(game)
    texts = {e.text for e in proj.entries}
    assert {"Start Game", "Quit to Desktop", "Hello there traveller",
            "Healing Potion", "Health Points", "Magic Points"} <= texts
    assert "Assets/UI/icon.png" not in texts   # path
    assert "a1b2c3d4e5f60718" not in texts     # denied key + hex
    assert "atlas" not in texts                # m_Name on an unrelated object
    assert proj.unity_version == "2021.3.16f1"
    assert proj.stats["scripting_backend"] == "Mono"


def test_dedup_groups_repeated_string(game, fake_unity):
    proj = extract(game)
    quit_entry = next(e for e in proj.entries if e.text == "Quit to Desktop")
    assert quit_entry.count == 3          # ui.json + dialogue.csv + TextAsset
    # 순서는 추출 순서 그대로여야 한다 (파일 순 = 읽는 순)
    files = [e.locations[0].file for e in proj.entries]
    assert files == sorted(files, key=lambda f: files.index(f)), "파일별로 뭉쳐 있어야 함"


def test_full_roundtrip(game, fake_unity, tmp_path):
    work = tmp_path / "work"
    work.mkdir()
    proj = extract(game, languages=["ko"])
    proj.save(work / "project.json")
    write_workbook(proj, work / "translation.xlsx")

    # --- translator fills in the sheet -----------------------------------
    from openpyxl import load_workbook
    wb = load_workbook(work / "translation.xlsx")
    ws = wb["번역"]
    header = [c.value for c in ws[1]]
    id_c, src_c, ko_c = header.index("ID") + 1, header.index("원문") + 1, header.index("ko") + 1
    table = {"Start Game": "게임 시작", "Quit to Desktop": "바탕화면으로 종료",
             "Hello there traveller": "안녕하시오, 나그네여",
             "Healing Potion": "회복 물약", "Health Points": "체력"}
    filled = 0
    for r in range(2, ws.max_row + 1):
        src = ws.cell(r, src_c).value
        if src in table:
            ws.cell(r, ko_c).value = table[src]
            filled += 1
    assert filled == len(table)
    wb.save(work / "translation.xlsx")

    # --- read back and apply ---------------------------------------------
    edits, langs = read_workbook(work / "translation.xlsx")
    assert langs == ["ko"]
    proj2 = Project.load(work / "project.json")
    assert merge_into_project(proj2, edits) == len(table)

    rep = apply_translations(proj2, "ko")
    assert not rep.failures
    assert rep.strings_written >= 7   # 5 unique strings, one occurring 3x

    sa = game / "MyGame_Data" / "StreamingAssets" / "loc"
    ui = json.loads((sa / "ui.json").read_text("utf-8"))
    assert ui["start"] == "게임 시작"
    assert ui["quit"] == "바탕화면으로 종료"
    assert ui["icon"] == "Assets/UI/icon.png"          # untouched

    csv_text = (sa / "dialogue.csv").read_text("utf-8")
    assert "안녕하시오, 나그네여" in csv_text
    assert csv_text.startswith("id,text")               # header intact

    doc = json.loads((game / "MyGame_Data" / "resources.assets").read_text("utf-8"))
    objs = {o["path_id"]: o for o in doc["objects"]}
    assert "회복 물약" in objs[11]["tree"]["m_Script"]
    assert "바탕화면으로 종료" in objs[11]["tree"]["m_Script"]
    assert objs[12]["tree"]["entries"][0]["value"] == "체력"
    assert objs[12]["tree"]["entries"][1]["value"] == "Magic Points"   # untranslated
    assert objs[12]["tree"]["m_Guid"] == "a1b2c3d4e5f60718"

    # --- restore ----------------------------------------------------------
    assert restore(game) == 3
    assert json.loads((sa / "ui.json").read_text("utf-8"))["start"] == "Start Game"
    doc = json.loads((game / "MyGame_Data" / "resources.assets").read_text("utf-8"))
    assert "Healing Potion" in doc["objects"][0]["tree"]["m_Script"]


def test_dry_run_writes_nothing(game, fake_unity, tmp_path):
    proj = extract(game, languages=["ko"])
    for e in proj.entries:
        e.translations["ko"] = "번역"
    before = (game / "MyGame_Data" / "StreamingAssets" / "loc" / "ui.json").read_text("utf-8")
    rep = apply_translations(proj, "ko", dry_run=True)
    assert rep.strings_written > 0
    after = (game / "MyGame_Data" / "StreamingAssets" / "loc" / "ui.json").read_text("utf-8")
    assert before == after
    assert not (game / "__gameloc_backup__").exists()


def test_second_language_column(game, fake_unity, tmp_path):
    """Adding a language must not require re-extracting."""
    work = tmp_path / "w2"
    work.mkdir()
    proj = extract(game, languages=["ko", "ja"])
    write_workbook(proj, work / "translation.xlsx")

    from openpyxl import load_workbook
    ws = load_workbook(work / "translation.xlsx")["번역"]
    header = [c.value for c in ws[1]]
    assert header[:4] == ["ID", "횟수", "위치", "원문"]
    assert "ko" in header and "ja" in header and header[-1] == "메모"

    target = next(e for e in proj.entries if e.text == "Start Game")
    target.translations["ja"] = "ゲーム開始"
    rep = apply_translations(proj, "ja")
    ui = json.loads((game / "MyGame_Data" / "StreamingAssets" / "loc" / "ui.json").read_text("utf-8"))
    assert ui["start"] == "ゲーム開始"
    assert rep.strings_written == 1


def test_filter_levels_change_yield(game, fake_unity):
    loose = len(extract(game, filter_level="loose").entries)
    normal = len(extract(game, filter_level="normal").entries)
    strict = len(extract(game, filter_level="strict").entries)
    assert loose >= normal >= strict
