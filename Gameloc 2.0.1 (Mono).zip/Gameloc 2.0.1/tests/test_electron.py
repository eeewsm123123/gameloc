"""Electron: 내용물이 resources/app.asar 한 덩어리에 묶여 있는 게임.

겉에서 보이는 건 크로미움 런타임 파일뿐이라 번역할 게 없어 보입니다.
풀어놓으면 Electron 이 resources/app/ 폴더를 대신 읽으므로, 그 뒤로는
평범한 파일 취급을 할 수 있습니다.
"""

from __future__ import annotations

import json
import struct
from pathlib import Path

import pytest

from gameloc import asar
from gameloc.detect import detect


def make_asar(files: dict[str, bytes]) -> bytes:
    """실제 asar 형식으로 아카이브를 만듭니다 (테스트용 최소 구현)."""
    tree: dict = {"files": {}}
    blob = b""
    for path, data in files.items():
        node = tree
        parts = path.split("/")
        for d in parts[:-1]:
            node = node["files"].setdefault(d, {"files": {}})
        node["files"][parts[-1]] = {"size": len(data), "offset": str(len(blob))}
        blob += data
    raw = json.dumps(tree).encode("utf-8")
    # 파일 본문은 8+header_size 에서 시작해야 하고, 앞의 uint32 4개가 16바이트다.
    pad = (4 - len(raw) % 4) % 4
    header_size = 8 + len(raw) + pad          # → base = 8+header_size = 16+len+pad
    head = struct.pack("<IIII", 4, header_size, len(raw) + 4, len(raw))
    return head + raw + b"\0" * pad + blob


@pytest.fixture
def game(tmp_path: Path) -> Path:
    root = tmp_path / "Game"
    (root / "resources").mkdir(parents=True)
    (root / "yurialice.exe").write_bytes(b"MZ")
    (root / "LICENSES.chromium.html").write_text("x", "utf-8")
    (root / "resources" / "app.asar").write_bytes(make_asar({
        "package.json": b'{"name":"yurialice","main":"index.html"}',
        "data/scenario.json": '{"text":"ようこそ。"}'.encode(),
        "js/main.js": '// "セーブしますか？"'.encode(),
    }))
    return root


def test_packed_electron_is_recognised(game):
    info = detect(game)
    assert info.engine == "electron-packed"
    assert info.electron_asar == game / "resources" / "app.asar"
    assert "app.asar" in info.summary() and "풀어야" in info.summary()


def test_unpack_produces_real_files(game):
    info = detect(game)
    n, dest = asar.open_up(info.electron_asar)
    assert n == 3
    assert (dest / "data" / "scenario.json").read_text("utf-8") == '{"text":"ようこそ。"}'
    assert json.loads((dest / "package.json").read_text("utf-8"))["name"] == "yurialice"


def test_asar_is_disabled_so_electron_reads_the_folder(game):
    """app.asar 가 그대로 있으면 Electron 이 그걸 먼저 읽습니다. 옆으로 치워야 합니다."""
    info = detect(game)
    asar.open_up(info.electron_asar)
    assert not (game / "resources" / "app.asar").exists()
    assert (game / "resources" / "app.asar.gameloc-off").is_file()


def test_inner_engine_is_detected_after_unpack(game):
    asar.open_up(detect(game).electron_asar)
    after = detect(game)
    assert after.engine != "electron-packed"
    assert after.electron_app == game / "resources" / "app"
    assert after.root == game / "resources" / "app", "안쪽을 루트로 잡아야 한다"
    assert "Electron 안" in after.summary()


def test_rpgmaker_inside_electron(tmp_path):
    """Electron 껍데기 안에 RPG Maker 가 들어 있는 경우도 있습니다."""
    root = tmp_path / "Game"
    app = root / "resources" / "app"
    (app / "data").mkdir(parents=True)
    (app / "js").mkdir()
    (app / "package.json").write_text('{"name":"x"}', "utf-8")
    (app / "js" / "rmmz_core.js").write_text("//", "utf-8")
    (app / "data" / "System.json").write_text(
        json.dumps({"gameTitle": "テスト"}, ensure_ascii=False), "utf-8")
    info = detect(root)
    assert info.engine == "rpgmaker"
    assert "Electron 안" in info.summary() and "RPG Maker" in info.summary()


def test_repack_restores_everything(game):
    before = (game / "resources" / "app.asar").read_bytes()
    asar.open_up(detect(game).electron_asar)
    assert asar.close_up(game) is True
    assert (game / "resources" / "app.asar").read_bytes() == before, "원본 그대로"
    assert not (game / "resources" / "app").exists()
    assert detect(game).engine == "electron-packed"


def test_unpack_twice_is_refused(game):
    asar.open_up(detect(game).electron_asar)
    (game / "resources" / "app.asar").write_bytes(make_asar({"a.txt": b"x"}))
    with pytest.raises(FileExistsError):
        asar.open_up(game / "resources" / "app.asar")


def test_not_an_asar(tmp_path):
    p = tmp_path / "fake.asar"
    p.write_bytes(b"not an asar at all")
    assert asar.is_asar(p) is False
