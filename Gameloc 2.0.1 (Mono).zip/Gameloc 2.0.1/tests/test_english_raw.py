"""원문이 영어인 유니티 게임 — 구조를 못 읽는 스크립트에서 영어 뽑기.

영어·중국어·일본어를 함께 지원하는 게임에서 "중국어랑 일본어만 나온다" 는
신고가 있었습니다. 구조를 못 읽는 MonoBehaviour 는 바이트에서 직접 긁는데,
거기서 **일본어·중국어가 든 것만** 가져오고 있었기 때문입니다. 영어는 명령
이름이나 경로인 경우가 많아 일부러 뺐던 것인데, 원문이 영어인 게임에서는
그게 곧 "아무것도 안 나온다" 가 됩니다.
"""

from __future__ import annotations

import struct

from gameloc import unityraw


def pack(*strings: str) -> bytes:
    out = b""
    for s in strings:
        b = s.encode("utf-8")
        out += struct.pack("<I", len(b)) + b + b"\x00" * (-len(b) % 4)
    return out


DIALOGUE_EN = "I told you it was dangerous, didn't I?"
DIALOGUE_JA = "危ないって言ったでしょう。"
NOT_TEXT = ("Assets/Scenes/Main.unity", "onPlayerDeath", "SFX_DOOR_OPEN",
            "ui/main_menu", "{0} HP", "Move", "MoveCamera", "OK")


# ------------------------------------------------------------ 영어 문장 판별

def test_real_sentences_pass():
    for s in (DIALOGUE_EN,
              "The door creaks open, slowly.",
              "Press any key to continue",
              "Are you sure you want to quit?"):
        assert unityraw.sentence_like(s), s


def test_machine_strings_never_pass():
    for s in NOT_TEXT:
        assert not unityraw.sentence_like(s), s


def test_japanese_is_not_a_latin_sentence():
    assert not unityraw.sentence_like(DIALOGUE_JA)


# ------------------------------------------------------------ 뽑기

def test_default_still_only_takes_cjk():
    data = pack(DIALOGUE_JA, DIALOGUE_EN, *NOT_TEXT)
    got = [s for _o, s in unityraw.translatable(data)]
    assert got == [DIALOGUE_JA]


def test_english_option_adds_sentences_only():
    data = pack(DIALOGUE_JA, DIALOGUE_EN, *NOT_TEXT)
    got = [s for _o, s in unityraw.translatable(data, include_latin=True)]
    assert DIALOGUE_EN in got
    assert DIALOGUE_JA in got
    for junk in NOT_TEXT:
        assert junk not in got, f"{junk} 는 대사가 아닙니다"


def test_latin_sentences_are_counted_for_the_advice():
    data = pack(DIALOGUE_JA, DIALOGUE_EN, "Nothing happens here.", *NOT_TEXT)
    assert len(unityraw.latin_sentences(data)) == 2


# ------------------------------------------------------------ 되돌려 넣기

def test_english_can_be_replaced_and_verified():
    data = pack(DIALOGUE_EN, "Move")
    off = next(o for o, s in unityraw.translatable(data, include_latin=True)
               if s == DIALOGUE_EN)
    new, moved = unityraw.patch_and_map(data, {off: "위험하다고 했잖아요."})
    assert unityraw.verify(new, {off: "위험하다고 했잖아요."}, moved)
    assert b"Move" in new                       # 옆 문자열은 그대로
    assert [s for _o, s in unityraw.scan(new)] == ["위험하다고 했잖아요.", "Move"]


# ------------------------------------------------------------ 연결

def test_extract_passes_the_option_down(monkeypatch):
    """옵션이 실제로 바닥까지 내려가는지 — 중간에서 끊기면 조용히 안 먹습니다."""
    from gameloc import extract as extract_mod

    seen = {}

    class FakeObj:
        path_id = 7

        def get_raw_data(self):
            return pack(DIALOGUE_EN, DIALOGUE_JA)

    real = unityraw.translatable

    def spy(data, *, include_latin=False):
        seen["include_latin"] = include_latin
        return real(data, include_latin=include_latin)

    monkeypatch.setattr(extract_mod.unityraw, "translatable", spy)

    stats = __import__("collections").defaultdict(int)
    got = extract_mod._from_monobehaviour_raw(FakeObj(), "a.assets", stats,
                                              include_latin=True)
    assert seen["include_latin"] is True
    assert DIALOGUE_EN in [t for t, _l in got]
    assert not stats.get("raw_latin_skipped")


def test_skipping_english_is_counted_not_silent():
    from gameloc import extract as extract_mod

    class FakeObj:
        path_id = 7

        def get_raw_data(self):
            return pack(DIALOGUE_EN, DIALOGUE_JA)

    stats = __import__("collections").defaultdict(int)
    got = extract_mod._from_monobehaviour_raw(FakeObj(), "a.assets", stats)
    assert [t for t, _l in got] == [DIALOGUE_JA]
    assert stats["raw_latin_skipped"] == 1


# ------------------------------------------------------------ 원문 언어 고르기

def test_language_guess():
    from gameloc import langs

    assert langs.guess("I told you.") == "en"
    assert langs.guess("危ないって言ったでしょう。") == "ja"
    assert langs.guess("안녕하세요") == "ko"
    assert langs.guess("设置") == "han"          # 한자만 — 중·일 구분 불가
    assert langs.guess("123 %") == "sym"          # 숫자·기호뿐
    assert langs.guess("ВОЙТИ В БАР") == "other"  # 다른 문자 체계


def test_han_only_goes_to_both_japanese_and_chinese():
    """`設定` 은 중국어일 수도 일본어일 수도 있습니다. 빠뜨리지 않습니다."""
    from gameloc import langs

    for choice in ("ja", "zh"):
        assert langs.matches("設定", langs.wanted_set(choice))
    assert not langs.matches("設定", langs.wanted_set("en"))


def test_all_keeps_everything():
    from gameloc import langs

    wanted = langs.wanted_set("all")
    for s in ("Hello there.", "こんにちは", "설정", "設定"):
        assert langs.matches(s, wanted)


def test_symbols_are_never_filtered_out():
    """숫자·기호만 있는 줄은 어느 언어도 아니라서 막으면 안 됩니다."""
    from gameloc import langs

    assert langs.matches("100%", langs.wanted_set("en"))
    assert langs.matches("―――", langs.wanted_set("ja"))


def test_extract_keeps_only_the_chosen_language(tmp_path):
    """영어·일본어·중국어가 한 파일에 있는 유니티 게임에서 영어만 뽑기."""
    from gameloc import extract as extract_mod

    root = tmp_path / "Game"
    data = root / "Game_Data" / "StreamingAssets"
    data.mkdir(parents=True)
    (root / "Game_Data" / "globalgamemanagers").write_bytes(b"\x00" * 32)
    (data / "text.json").write_text(
        '{"a": "I told you it was dangerous.",'
        ' "b": "危ないって言ったでしょう。",'
        ' "c": "我告诉过你很危险。"}', "utf-8")

    def texts(**kw):
        proj = extract_mod.extract(root, **kw)
        return {e.text for e in proj.entries}

    everything = texts()
    assert len(everything) == 3

    only_en = texts(source_lang="en")
    assert only_en == {"I told you it was dangerous."}

    only_ja = texts(source_lang="ja")
    assert "危ないって言ったでしょう。" in only_ja
    assert "I told you it was dangerous." not in only_ja
