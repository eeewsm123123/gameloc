"""한글이 □□□ 로 나오는 것 고치기.

번역은 이미 들어갔는데 폰트에 한글 모양이 없어서 네모가 나옵니다.
Static 폰트는 글자 그림이 구워져 있어 손댈 수 없지만, 옆에 있는
Dynamic 폰트를 한글 글꼴로 바꿔 **대체 폰트**로 걸면 됩니다.
"""

from __future__ import annotations

import json
import types
from pathlib import Path

import pytest

from gameloc import font

from test_e2e import FakeEnv, game  # noqa: F401

JP = list(range(0x3040, 0x3060))
KO = list(range(0xAC00, 0xAC00 + 20))


def mk_font(path_id, name, unicodes, *, mode=0, source=None, fallbacks=None):
    return {
        "path_id": path_id, "type": "MonoBehaviour", "cls": "TMPro.TMP_FontAsset",
        "tree": {
            "m_Name": name,
            "m_AtlasPopulationMode": mode,
            "m_CharacterTable": [{"m_Unicode": u} for u in unicodes],
            "m_FallbackFontAssetTable": list(fallbacks or []),
            "m_SourceFontFile": {"m_FileID": 0, "m_PathID": source or 0},
        },
    }


def mk_source(path_id, name):
    return {"path_id": path_id, "type": "Font", "cls": "UnityEngine.Font",
            "tree": {"m_Name": name, "m_FontNames": [name],
                     "m_FontData": "OLD"}}


class _BytesFile:
    """가짜 저장기. 진짜 유니티는 바이트를 그대로 쓰지만 여기선 JSON 이라
    latin-1 로 옮겨 담습니다 (테스트에서 눈으로 확인하기 쉽게)."""

    def __init__(self, env):
        self.env = env

    def save(self, packer=None):
        if packer == "original":
            raise NotImplementedError
        return json.dumps(self.env.doc, ensure_ascii=False,
                          default=lambda b: bytes(b).decode("latin-1")
                          ).encode("utf-8")


class FontEnv(FakeEnv):
    """script_class 가 동작하도록 클래스 이름을 들고 있는 가짜 환경."""

    def __init__(self, source, **kw):
        super().__init__(source, **kw)
        self.file = _BytesFile(self)
        for o in self.objects:
            cls = o._d.get("cls", "")
            ms = types.SimpleNamespace(
                m_Namespace=cls.rsplit(".", 1)[0] if "." in cls else "",
                m_ClassName=cls.rsplit(".", 1)[-1], m_AssemblyName="X")
            o.parse_monobehaviour_head = (
                lambda ms=ms: types.SimpleNamespace(
                    m_Script=types.SimpleNamespace(
                        deref_parse_as_object=lambda: ms)))


@pytest.fixture
def fonts(game, monkeypatch):  # noqa: F811
    import UnityPy

    data = game / "MyGame_Data"
    (data / "resources.assets").write_text(json.dumps({"objects": [
        mk_source(100, "Inter-Regular"),
        mk_font(1, "timemachine-wa SDF", JP, mode=0),
        mk_font(2, "LiberationSans SDF", [0x41], mode=0),
        mk_font(3, "Inter-Regular SDF", [0x41, 0x42], mode=1, source=100),
    ]}, ensure_ascii=False), "utf-8")
    monkeypatch.setattr(UnityPy, "load", lambda src, **k: FontEnv(src))
    return game


def _objs(path):
    return FontEnv(str(path)).objects


# ------------------------------------------------------------------ 계획

def test_plan_picks_the_dynamic_font_as_donor(fonts):
    p = font.plan(_objs(fonts / "MyGame_Data" / "resources.assets"))
    assert p.ok()
    assert p.donor_name == "Inter-Regular SDF"
    assert p.source_font_id == 100
    assert sorted(n for _i, n in p.targets) == [
        "LiberationSans SDF", "timemachine-wa SDF"]


def test_plan_skips_fonts_that_already_have_hangul(game, monkeypatch):  # noqa: F811
    import UnityPy

    data = game / "MyGame_Data"
    (data / "resources.assets").write_text(json.dumps({"objects": [
        mk_source(100, "Src"),
        mk_font(1, "이미한글 SDF", KO, mode=0),
        mk_font(3, "Dyn SDF", [0x41], mode=1, source=100),
    ]}, ensure_ascii=False), "utf-8")
    monkeypatch.setattr(UnityPy, "load", lambda src, **k: FontEnv(src))

    p = font.plan(_objs(data / "resources.assets"))
    assert not p.ok()
    assert any("고칠 게 없" in n for n in p.notes)


def test_plan_refuses_when_there_is_no_dynamic_font(game, monkeypatch):  # noqa: F811
    import UnityPy

    data = game / "MyGame_Data"
    (data / "resources.assets").write_text(json.dumps({"objects": [
        mk_font(1, "Static A", JP, mode=0),
        mk_font(2, "Static B", JP, mode=0),
    ]}, ensure_ascii=False), "utf-8")
    monkeypatch.setattr(UnityPy, "load", lambda src, **k: FontEnv(src))

    p = font.plan(_objs(data / "resources.assets"))
    assert not p.ok()
    assert any("Dynamic" in n for n in p.notes)


# ------------------------------------------------------------------ 적용

def test_fix_swaps_source_font_and_links_fallbacks(fonts, tmp_path):
    ttf = tmp_path / "malgun.ttf"
    ttf.write_bytes(b"KOREAN-FONT-BYTES")

    rep = font.fix(fonts, ttf=ttf)
    assert rep.patched, rep.notes
    assert rep.donor == "Inter-Regular SDF"
    assert sorted(rep.patched) == ["LiberationSans SDF", "timemachine-wa SDF"]

    doc = json.loads((fonts / "MyGame_Data" / "resources.assets")
                     .read_text("utf-8"))
    objs = {o["path_id"]: o["tree"] for o in doc["objects"]}

    # ① 원본 글꼴이 바뀌었다
    assert objs[100]["m_FontData"] == "KOREAN-FONT-BYTES"
    assert objs[100]["m_FontNames"] == ["malgun"]

    # ② 대체 폰트가 걸렸다
    for pid in (1, 2):
        table = objs[pid]["m_FallbackFontAssetTable"]
        assert [x["m_PathID"] for x in table] == [3]

    # ③ 대체 폰트 자신은 자기를 가리키지 않는다
    assert objs[3]["m_FallbackFontAssetTable"] == []
    # ④ 글자표는 손대지 않았다
    assert len(objs[1]["m_CharacterTable"]) == len(JP)


def test_fix_is_idempotent(fonts, tmp_path):
    ttf = tmp_path / "malgun.ttf"
    ttf.write_bytes(b"FONT")
    font.fix(fonts, ttf=ttf)
    rep2 = font.fix(fonts, ttf=ttf)

    doc = json.loads((fonts / "MyGame_Data" / "resources.assets")
                     .read_text("utf-8"))
    objs = {o["path_id"]: o["tree"] for o in doc["objects"]}
    assert len(objs[1]["m_FallbackFontAssetTable"]) == 1, "두 번 걸리면 안 됩니다"
    assert not rep2.patched


def test_dry_run_changes_nothing(fonts, tmp_path):
    ttf = tmp_path / "f.ttf"
    ttf.write_bytes(b"FONT")
    before = (fonts / "MyGame_Data" / "resources.assets").read_bytes()
    rep = font.fix(fonts, ttf=ttf, dry_run=True)
    assert rep.patched
    assert (fonts / "MyGame_Data" / "resources.assets").read_bytes() == before


def test_backup_and_restore(fonts, tmp_path):
    from gameloc.apply import restore

    ttf = tmp_path / "f.ttf"
    ttf.write_bytes(b"FONT")
    before = (fonts / "MyGame_Data" / "resources.assets").read_bytes()
    font.fix(fonts, ttf=ttf)
    assert (fonts / "MyGame_Data" / "resources.assets").read_bytes() != before

    restore(fonts)
    assert (fonts / "MyGame_Data" / "resources.assets").read_bytes() == before


def test_missing_font_file_is_explained(fonts):
    rep = font.fix(fonts, ttf=Path("/없는/글꼴.ttf"))
    assert not rep.patched
    assert any("글꼴" in n for n in rep.notes)


# ------------------------------------------------------------------ 글꼴 찾기

def test_system_font_search_prefers_known_paths(monkeypatch, tmp_path):
    fake = tmp_path / "malgun.ttf"
    fake.write_bytes(b"x")
    monkeypatch.setattr(font.platform, "system", lambda: "Windows")
    monkeypatch.setattr(font, "CANDIDATES", {"Windows": [str(fake)]})
    assert font.find_system_font() == fake


def test_typetree_generator_is_attached(fonts, tmp_path, monkeypatch):
    """폰트도 MonoBehaviour 입니다.

    배포 빌드에는 그 구조가 안 들어 있어서, 게임 DLL 에서 되살리지 않으면
    폰트가 아예 안 보입니다 — '폰트를 찾지 못했습니다' 로 끝납니다.
    """
    from gameloc import typetree

    seen = []
    monkeypatch.setattr(typetree, "attach",
                        lambda env, root, ver: seen.append((str(root), ver)) or True)
    ttf = tmp_path / "f.ttf"
    ttf.write_bytes(b"FONT")
    font.fix(fonts, ttf=ttf)
    assert seen, "타입 정보 생성기를 안 붙였습니다"
    assert all(str(fonts) in r for r, _v in seen), seen


def test_unreadable_font_says_why(game, monkeypatch):  # noqa: F811
    """'폰트가 없다' 와 '폰트를 못 읽는다' 는 원인이 전혀 다릅니다."""
    import UnityPy

    data = game / "MyGame_Data"
    (data / "resources.assets").write_text(json.dumps({"objects": [
        mk_font(1, "timemachine-wa SDF", JP, mode=0),
    ]}, ensure_ascii=False), "utf-8")

    class Blind(FontEnv):
        def __init__(self, source, **kw):
            super().__init__(source, **kw)
            for o in self.objects:
                o.read_typetree = _boom

    def _boom(*_a, **_k):
        raise RuntimeError("no typetree")

    monkeypatch.setattr(UnityPy, "load", lambda src, **k: Blind(src))
    p = font.plan(Blind(str(data / "resources.assets")).objects)
    assert not p.ok()
    assert p.font_like == 1
    # 이름만 FontAsset 이고 실제 폰트 모양이 아니면 '못 읽었다' 고 하지
    # 않습니다. 진짜 게임에서 없는 폰트를 있다고 말한 적이 있습니다.
    assert p.font_real == 0
    assert any("TextMeshPro 폰트는 아닙니다" in n for n in p.notes)


def test_real_font_shape_that_cannot_be_read_says_why(game, monkeypatch):  # noqa: F811
    """앞머리가 진짜 폰트 모양이면 '못 읽었다' 고 정확히 말해야 합니다."""
    import UnityPy

    from tests.test_tmpraw import build

    data = game / "MyGame_Data"
    (data / "resources.assets").write_text(json.dumps({"objects": [
        mk_font(1, "timemachine-wa SDF", JP, mode=0),
    ]}, ensure_ascii=False), "utf-8")

    def _boom(*_a, **_k):
        raise RuntimeError("no typetree")

    class Blind(FontEnv):
        def __init__(self, source, **kw):
            super().__init__(source, **kw)
            for o in self.objects:
                o.read_typetree = _boom
                o.get_raw_data = lambda: build(name="timemachine-wa SDF")

    monkeypatch.setattr(UnityPy, "load", lambda src, **k: Blind(src))
    p = font.plan(Blind(str(data / "resources.assets")).objects)
    assert p.font_real == 1
    assert any("구조를 읽지 못했습니다" in n for n in p.notes)


def test_no_fonts_at_all_says_so(game, monkeypatch):  # noqa: F811
    import UnityPy

    data = game / "MyGame_Data"
    (data / "resources.assets").write_text(json.dumps({"objects": [
        {"path_id": 9, "type": "Texture2D", "cls": "", "tree": {"m_Name": "x"}},
    ]}, ensure_ascii=False), "utf-8")
    monkeypatch.setattr(UnityPy, "load", lambda src, **k: FontEnv(src))
    p = font.plan(FontEnv(str(data / "resources.assets")).objects)
    assert any("폰트가 없습니다" in n for n in p.notes)


def test_notes_are_not_repeated_per_file(game, monkeypatch, tmp_path):  # noqa: F811
    """파일 5개에 같은 말이 5번 찍히면 읽기만 어렵습니다."""
    import UnityPy

    data = game / "MyGame_Data"
    for name in ("resources.assets", "sharedassets0.assets", "level0"):
        (data / name).write_text(json.dumps({"objects": [
            {"path_id": 9, "type": "Texture2D", "cls": "", "tree": {}},
        ]}), "utf-8")
    monkeypatch.setattr(UnityPy, "load", lambda src, **k: FontEnv(src))

    ttf = tmp_path / "f.ttf"
    ttf.write_bytes(b"F")
    rep = font.fix(game, ttf=ttf)
    assert len(rep.notes) == len(set(rep.notes))


# ── IL2CPP 우회로: 유니티 기본 Font ──────────────────────────────────────

class _FakeObj:
    def __init__(self, type_name, path_id, tree):
        import types
        self.type = types.SimpleNamespace(name=type_name)
        self.path_id = path_id
        self._tree = tree
        self.saved = None

    def read_typetree(self):
        return self._tree

    def save_typetree(self, tree):
        self.saved = tree


def test_legacy_font_is_found_when_tmp_cannot_be_read():
    """IL2CPP 에서는 TextMeshPro 구조를 못 읽습니다. 그때 기댈 곳."""
    from gameloc import font

    objs = [_FakeObj("Font", 11, {"m_Name": "LiberationSans",
                                  "m_FontData": b"\x00" * 100})]
    p = font.plan(objs)
    assert not p.ok()
    assert p.legacy_only()
    assert p.legacy == [(11, "LiberationSans")]
    assert any("유니티 기본 글꼴" in n for n in p.notes)


def test_legacy_route_replaces_the_font_data():
    from gameloc import font

    obj = _FakeObj("Font", 11, {"m_Name": "LiberationSans",
                                "m_FontData": b"\x00" * 100})
    p = font.plan([obj])
    rep = font.FontReport(ttf="malgun.ttf")

    class TTF:
        stem = "malgun"
        name = "malgun.ttf"

        @staticmethod
        def read_bytes():
            return b"KOREANFONT" * 10

    out, data = font._fix_legacy(None, [obj], p, TTF, rep,
                                 dry_run=True, progress=lambda m: None)
    assert out.patched == ["LiberationSans"]
    assert obj.saved["m_FontData"] == b"KOREANFONT" * 10
    assert out.legacy_route is True
    assert any("되돌리기" in n for n in out.notes)     # 안 될 수도 있음을 알림


def test_proper_route_is_preferred_over_the_workaround():
    """TextMeshPro 를 읽을 수 있으면 그쪽이 우선입니다."""
    from gameloc import font

    tmp = _FakeObj("MonoBehaviour", 21, {
        "m_Name": "Body SDF", "m_AtlasPopulationMode": 1,
        "m_SourceFontFile": {"m_FileID": 0, "m_PathID": 11},
        "m_CharacterTable": [], "m_FallbackFontAssetTable": []})
    legacy = _FakeObj("Font", 11, {"m_Name": "LiberationSans",
                                   "m_FontData": b"\x00" * 100})
    import gameloc.peek as peek
    orig = peek.script_class
    peek.script_class = lambda o: "TMPro.TMP_FontAsset"
    try:
        p = font.plan([tmp, legacy])
    finally:
        peek.script_class = orig
    assert p.legacy == [(11, "LiberationSans")]   # 알고는 있지만
    assert not p.legacy_only()                    # 제대로 된 길을 씁니다


# ── 멀쩡한 폰트를 손대지 않기 ────────────────────────────────────────────
#
# 이 게임(Unity 2022.3 · IL2CPP · TMP 1.4.0)에서 실제로 난 일입니다.
# 폰트는 전부 이미 '실행 중에 그리기' 였는데, 우리가 굳은 것까지 억지로
# 풀어 놓는 바람에 게임이 글자를 하나도 안 그리고 꺼졌습니다.

class _RawType:
    def __init__(self, name):
        self.name = name


class _RawObj:
    def __init__(self, raw, type_name="MonoBehaviour"):
        self._raw = raw
        self.type = _RawType(type_name)
        self.path_id = 1
        self.saved = None

    def get_raw_data(self):
        return self._raw

    def set_raw_data(self, data):
        self.saved = data


def _head(**kw):
    from tests.test_tmpraw import build

    return build(**kw)


def test_static_fonts_are_left_alone_when_something_already_works():
    """굳은 폰트 풀기는 게임을 꺼뜨립니다. 실제 게임에서 두 번 확인했습니다.

    Liar's Bar 로 A/B 를 했습니다 — 풀면 켜지다 꺼지고, 안 풀면 멀쩡히
    돕니다. 이름 관문으로 폰트 아닌 것을 걸러도 마찬가지였습니다.
    그 폰트를 쓰는 화면만 □□□ 로 남는 편이, 게임이 아예 안 켜지는
    것보다 낫습니다.
    """
    from gameloc import font, tmpraw

    objs = [_RawObj(_head(name="atabold", src_path=3162, mode=tmpraw.DYNAMIC)),
            _RawObj(_head(name="variex_regular SDF", mode=tmpraw.STATIC))]
    p = font.FontPlan(legacy=[(1, "UBUNTU-BOLD")])
    rep = font.FontReport()

    class _Env:
        pass

    # _fix_legacy 안에서 막힙니다 — _retarget_static 자체는 시키면 합니다.
    assert font.dynamic_ready(objs) == 1
    n = font._retarget_static(objs, rep, donor_id=3162, progress=lambda _m: None)
    assert n == 1, "관문은 _fix_legacy 에 있습니다"


def test_dynamic_ready_counts_only_fonts_that_already_work():
    from gameloc import font, tmpraw

    objs = [
        _RawObj(_head(src_path=663, mode=tmpraw.DYNAMIC)),   # 이미 됨
        _RawObj(_head(mode=tmpraw.STATIC)),                  # 굳음
        _RawObj(_head(src_path=0, mode=tmpraw.DYNAMIC)),     # 원본이 없음
        _RawObj(b"not a font", "Texture2D"),
    ]
    assert font.dynamic_ready(objs) == 1


def test_retarget_skips_things_that_are_not_text_fonts():
    """``DropCap Numbers`` 는 스프라이트 모음입니다. 폰트로 알고 고치면 깨집니다."""
    from gameloc import font

    rep = font.FontReport()
    objs = [_RawObj(_head(name="DropCap Numbers")),
            _RawObj(_head(name="Default Sprite Asset")),
            _RawObj(_head(name="LiberationSans SDF"))]
    n = font._retarget_static(objs, rep, donor_id=663, progress=lambda _m: None)
    assert n == 1
    assert rep.retargeted == ["LiberationSans SDF"]
    assert objs[0].saved is None and objs[1].saved is None


# ── 굳은 폰트: 손으로 켜는 마지막 수 (백로그 B) ──────────────────────────
#
# 자동으로 풀면 게임이 안 켜집니다(Liar's Bar 로 두 번 확인). 그렇다고
# 영영 막아 두면 그 폰트를 쓰는 화면은 계속 □□□ 입니다. 그래서 기본은
# 끄고, 사람이 알고 켤 때만 합니다.

def _legacy_objs():
    from gameloc import tmpraw

    return [_RawObj(_head(name="atabold", src_path=3162, mode=tmpraw.DYNAMIC)),
            _RawObj(_head(name="variex_regular SDF", mode=tmpraw.STATIC))]


def test_frozen_fonts_are_left_alone_by_default():
    from gameloc import font

    objs = _legacy_objs()
    assert font.dynamic_ready(objs) == 1
    # _fix_legacy 의 관문: 되는 게 있고 켜지 않았으면 기증자를 안 고릅니다.
    assert font._donor_font_id(objs, {3162}) == 3162   # 부품 자체는 멀쩡


def test_asking_for_it_unfreezes_and_says_how_to_undo(tmp_path, monkeypatch):
    """켜면 풀되, 안 켜질 때 돌아오는 길을 반드시 알려 줍니다."""
    from gameloc import font

    said = []
    rep = font.FontReport()
    objs = _legacy_objs()
    n = font._retarget_static(objs, rep, donor_id=3162, progress=said.append)
    assert n == 1 and rep.retargeted == ["variex_regular SDF"]


def test_the_screen_can_ask_for_it():
    """화면에서 체크한 값이 실제로 전달되는 통로가 있어야 합니다."""
    import inspect

    from gameloc import font

    for fn in (font.fix, font.apply_to_file, font._fix_legacy):
        assert "unfreeze" in inspect.signature(fn).parameters, fn.__name__
