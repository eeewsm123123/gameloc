"""설치된 글꼴을 직접 읽어 한글이 있는지 판별.

파일 이름만 보면 안 됩니다. ``H2GTRM.TTF`` 가 한글 글꼴인지 아닌지는
열어봐야 압니다. 그래서 이름표(name)와 글자표(cmap)를 직접 읽습니다.
"""

from __future__ import annotations

import shutil
import struct
from pathlib import Path

import pytest

from gameloc import fontlist

# 이 컨테이너에 실제로 깔려 있는 글꼴로 검사합니다 (가짜가 아닌 진짜 파일).
REAL_DIRS = [d for d in fontlist.font_dirs() if d.is_dir()]


def _some_real_fonts(n=6):
    out = []
    for d in REAL_DIRS:
        for p in sorted(d.rglob("*")):
            if p.is_file() and p.suffix.lower() in fontlist.SUFFIXES:
                out.append(p)
            if len(out) >= n:
                return out
    return out


@pytest.mark.skipif(not REAL_DIRS, reason="글꼴 폴더가 없습니다")
def test_reads_real_font_names():
    for p in _some_real_fonts():
        info = fontlist.read_font(p)
        assert info is not None, p
        assert info.name, f"{p} 의 이름을 못 읽었습니다"
        assert not info.name.startswith("\x00")


@pytest.mark.skipif(not REAL_DIRS, reason="글꼴 폴더가 없습니다")
def test_hangul_detection_matches_expectation():
    """CJK 글꼴은 한글이 있고, DejaVu 계열은 없습니다."""
    got = {}
    for p in _some_real_fonts(40):
        info = fontlist.read_font(p)
        if info:
            got[p.name.lower()] = info.hangul

    cjk = [v for k, v in got.items() if "cjk" in k or "nanum" in k]
    plain = [v for k, v in got.items() if "dejavu" in k or "liberation" in k]
    if cjk:
        assert any(cjk), "CJK 글꼴에서 한글을 못 찾았습니다"
    if plain:
        assert not any(plain), "한글 없는 글꼴을 있다고 했습니다"


@pytest.mark.skipif(not REAL_DIRS, reason="글꼴 폴더가 없습니다")
def test_scan_returns_only_hangul_fonts():
    found = fontlist.scan()
    assert all(f.hangul for f in found)
    assert len({f.name.lower() for f in found}) == len(found), "이름이 겹칩니다"
    assert found == sorted(found, key=lambda f: f.name.lower())
    for f in found:
        assert Path(f.path).is_file()


@pytest.mark.skipif(not REAL_DIRS, reason="글꼴 폴더가 없습니다")
def test_scan_without_filter_finds_more():
    assert len(fontlist.scan(only_hangul=False)) >= len(fontlist.scan())


def test_garbage_file_does_not_crash(tmp_path):
    bad = tmp_path / "broken.ttf"
    bad.write_bytes(b"not a font at all" * 10)
    info = fontlist.read_font(bad)
    assert info is None or info.hangul is False


def test_truncated_font_does_not_crash(tmp_path):
    real = _some_real_fonts(1)
    if not real:
        pytest.skip("글꼴이 없습니다")
    cut = tmp_path / "cut.ttf"
    cut.write_bytes(real[0].read_bytes()[:400])
    fontlist.read_font(cut)          # 예외만 안 나면 됩니다


def test_missing_file_is_none(tmp_path):
    assert fontlist.read_font(tmp_path / "없음.ttf") is None


def test_to_dict_shape():
    info = fontlist.FontInfo(path="/x/y.ttf", name="맑은 고딕", hangul=True)
    assert info.to_dict() == {"path": "/x/y.ttf", "name": "맑은 고딕",
                              "hangul": True}
