"""번역하면 게임이 죽는 것들 — 에셋·모델·모션 이름.

실제 사고: `海の家_波_木の揺れ` 를 번역했더니 플러그인이
`'海の家_波_木の揺れ' is unknown model.` 로 죽었습니다.
일본어가 들어 있다고 전부 대사인 게 아닙니다.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from gameloc import heuristics
from gameloc.apply import apply as apply_translations
from gameloc.extract import extract
from gameloc.model import Entry, Location, Project

CRASHER = "海の家_波_木の揺れ"


@pytest.mark.parametrize("text", [
    CRASHER,
    "水の音_ループ",
    "BGM_01_海",
    "player_name",
    "se_door_open",
    "キャラ_立ち絵_01",
])
def test_identifiers_are_rejected_at_every_level(text):
    assert heuristics.looks_like_identifier(text)
    assert heuristics.score(text) < min(heuristics.LEVELS.values())


@pytest.mark.parametrize("text", [
    "海の家",                      # 같은 낱말이라도 이름 모양이 아니면 대사
    "木の揺れ",
    "回復薬",
    "ようこそ、夜の図書館へ。",
    "はい",
    "Auto-Save",                  # 하이픈은 진짜 문구에도 흔하다
    "Press any key to continue",
])
def test_real_text_still_passes(text):
    assert not heuristics.looks_like_identifier(text)
    assert heuristics.score(text) >= heuristics.LEVELS["loose"]


def test_plugin_param_identifier_not_extracted(tmp_path):
    root = tmp_path / "Game"
    (root / "data").mkdir(parents=True)
    (root / "js").mkdir()
    (root / "js" / "rmmz_core.js").write_text("//", "utf-8")
    (root / "data" / "System.json").write_text('{"gameTitle":"テスト"}', "utf-8")
    (root / "js" / "plugins.js").write_text(
        "var $plugins =\n[\n"
        '{"name":"LiveModel","status":true,"parameters":'
        f'{{"models":"[\\"{CRASHER}\\",\\"海の家_夜\\"]",'
        '"prompt":"モデルを選んでください。"}}\n];\n', "utf-8")
    texts = {e.text for e in extract(root).entries}
    assert CRASHER not in texts, "모델 이름이 번역 대상에 들어가면 안 된다"
    assert "モデルを選んでください。" in texts, "진짜 안내문은 살아 있어야 한다"


def test_apply_refuses_identifier_even_if_already_in_project(tmp_path):
    """예전 버전으로 뽑아 둔 목록에 남아 있어도 적용 단계에서 막는다."""
    game = tmp_path / "Game"
    (game / "data").mkdir(parents=True)
    doc = {"a": CRASHER, "b": "こんにちは。"}
    (game / "data" / "x.json").write_text(
        json.dumps(doc, ensure_ascii=False, separators=(",", ":")), "utf-8")

    proj = Project(game_root=str(game), languages=["ko"], entries=[
        Entry(id="1", text=CRASHER,
              locations=[Location(file="data/x.json", kind="loose", fmt="json", ptr="a")],
              translations={"ko": "바다의 집_파도_나무흔들림"}),
        Entry(id="2", text="こんにちは。",
              locations=[Location(file="data/x.json", kind="loose", fmt="json", ptr="b")],
              translations={"ko": "안녕하세요."}),
    ])
    rep = apply_translations(proj, "ko")

    after = json.loads((game / "data" / "x.json").read_text("utf-8"))
    assert after["a"] == CRASHER, "이름은 원문 그대로여야 한다"
    assert after["b"] == "안녕하세요.", "진짜 대사는 반영돼야 한다"
    assert len(rep.risky) == 1 and CRASHER in rep.risky[0]
    assert "이름으로 보여 건너뜀" in rep.summary()


def test_summary_says_why_when_nothing_landed():
    """한 건도 안 들어갔으면 그 사실과 까닭을 분명히 적어야 합니다."""
    from gameloc.apply import ApplyReport

    rep = ApplyReport(lang="ko", skipped_untranslated=12)
    out = rep.summary()
    assert "한 건도 안 들어갔습니다" in out
    assert "번역문이 비어 있어 건너뜀 12건" in out


def test_summary_stays_quiet_when_all_is_well():
    from gameloc.apply import ApplyReport

    rep = ApplyReport(lang="ko", files_written=3, strings_written=40)
    out = rep.summary()
    assert "한 건도" not in out
    assert "건너뜀" not in out
