"""유니티 입력 시스템 값은 화면 문구가 아니라 **입력을 잇는 이름**입니다.

    m_ExpectedControlType: "Button"
    m_Interactions: "Hold"
    m_Action: "Move" / "Attack" / "Next"

번역하면 클릭·키 입력이 어디로도 연결되지 않아 **버튼이 안 눌립니다.**
게임은 멀쩡히 켜지고 화면도 정상이라 원인을 찾기가 가장 어려운 고장입니다.
"""

from __future__ import annotations

import json

import pytest

from gameloc import heuristics
from gameloc.apply import apply as apply_translations
from gameloc.extract import extract
from gameloc.model import Entry, Location, Project

from test_e2e import FakeEnv, fake_unity, game  # noqa: F401

INPUT_KEYS = [
    "m_ActionMaps[0].m_Actions[2].m_ExpectedControlType",
    "m_ActionMaps[0].m_Actions[3].m_Interactions",
    "m_ActionMaps[0].m_Bindings[0].m_Action",
    "m_ActionMaps[0].m_Bindings[1].m_Path",
    "m_ActionMaps[0].m_Bindings[11].m_Groups",
]


@pytest.mark.parametrize("ptr", INPUT_KEYS)
def test_input_system_fields_are_denied(ptr):
    assert heuristics.is_denied_key(ptr), ptr


@pytest.mark.parametrize("ptr", [
    "entries[0].value", "m_Text", "lines[3]", "dialogue.text",
])
def test_normal_text_fields_still_pass(ptr):
    assert not heuristics.is_denied_key(ptr)


def test_input_actions_never_reach_the_list(game, fake_unity):  # noqa: F811
    """뽑을 때부터 안 나옵니다."""
    data = game / "MyGame_Data"
    (data / "globalgamemanagers.assets").write_text(json.dumps({"objects": [
        {"path_id": 50, "type": "MonoBehaviour", "tree": {
            "m_Name": "InputSystem_Actions",
            "m_ActionMaps": [{
                "m_Actions": [{"m_ExpectedControlType": "Button",
                               "m_Interactions": "Hold"}],
                "m_Bindings": [{"m_Action": "Move", "m_Path": "<Gamepad>/dpad",
                                "m_Groups": "Joystick"}],
            }],
        }},
    ]}, ensure_ascii=False), "utf-8")

    texts = {e.text for e in extract(game).entries}
    for junk in ("Button", "Hold", "Move", "Joystick", "<Gamepad>/dpad"):
        assert junk not in texts, f"{junk} 가 번역 목록에 들어왔습니다"


def test_old_project_with_input_strings_is_blocked(game, fake_unity):  # noqa: F811
    """예전 버전으로 뽑아 둔 목록을 그대로 적용해도 막습니다.

    이미 번역해 둔 사람이 다시 뽑지 않아도 안전해야 합니다.
    """
    data = game / "MyGame_Data"
    (data / "globalgamemanagers.assets").write_text(json.dumps({"objects": [
        {"path_id": 50, "type": "MonoBehaviour", "tree": {
            "m_Name": "InputSystem_Actions",
            "m_ActionMaps": [{"m_Actions": [{"m_ExpectedControlType": "Button"}]}],
        }},
    ]}, ensure_ascii=False), "utf-8")

    proj = Project(game_root=str(game), engine="unity", languages=["ko"])
    proj.entries = [Entry(
        id="x", text="Button",
        locations=[Location(
            file="MyGame_Data/globalgamemanagers.assets", kind="asset",
            fmt="typetree", path_id=50,
            ptr="m_ActionMaps[0].m_Actions[0].m_ExpectedControlType")],
        translations={"ko": "버튼"})]

    rep = apply_translations(proj, "ko")
    assert rep.strings_written == 0
    assert any("Button" in r for r in rep.risky)

    doc = json.loads((data / "globalgamemanagers.assets").read_text("utf-8"))
    tree = doc["objects"][0]["tree"]
    got = tree["m_ActionMaps"][0]["m_Actions"][0]["m_ExpectedControlType"]
    assert got == "Button", "입력 이름이 번역되었습니다 — 버튼이 안 눌립니다"


def test_real_dialogue_still_applies_alongside(game, fake_unity):  # noqa: F811
    """입력 값만 막고 진짜 대사는 그대로 들어갑니다."""
    proj = extract(game)
    for e in proj.entries:
        e.translations["ko"] = "번역: " + e.text
    rep = apply_translations(proj, "ko")
    assert rep.strings_written > 0
    assert not rep.failures
