# SPDX-License-Identifier: GPL-3.0-or-later
"""무거운 읽기를 딴 프로세스에 맡기는 길 (백로그 C).

**막으려는 사고** — 오브젝트가 수만 개인 유니티 게임에서 프로그램이 통째로
사라집니다. 41개 중 40개를 멀쩡히 읽고도 큰 것 하나에서 죽으면 전부
날아가고 처음부터 다시입니다.

파이썬 ``try`` 로는 못 막습니다. 32비트의 2GB 벽이나 운영체제의 메모리 부족
처리는 예외가 아니라 프로세스를 그냥 죽이는 일이라서요. 그래서 여기서는
**진짜로 죽는 자식**을 만들어 확인합니다.
"""

import json
import os
import subprocess
import sys
import textwrap
import types
from pathlib import Path

import pytest

from gameloc import isolate
from gameloc.model import Location


@pytest.fixture(autouse=True)
def _yes_isolate(monkeypatch):
    """여기서는 딴 프로세스로 도는 길을 켭니다 (conftest 가 꺼 둡니다)."""
    monkeypatch.delenv("GAMELOC_NO_ISOLATE", raising=False)


ROOT = str(Path(__file__).resolve().parent.parent)


def _child(body: str) -> str:
    """부모가 시키는 대로 행동하는 가짜 자식을 만들어 그 코드를 돌려줍니다."""
    return textwrap.dedent(body)


class _FakeWorker(isolate.Worker):
    """진짜 UnityPy 대신, 시키는 대로 굴거나 죽는 자식을 씁니다."""

    def __init__(self, script: str, **kw):
        super().__init__(Path("/game"), 0.5, "2022.3.27f1", **kw)
        self._script = script

    def _spawn(self) -> bool:
        env = dict(os.environ)
        env["PYTHONPATH"] = ROOT + os.pathsep + env.get("PYTHONPATH", "")
        self.proc = subprocess.Popen(
            [sys.executable, "-u", "-c", self._script],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL, env=env, text=True,
            encoding="utf-8", errors="replace")
        return True


# ── 잘 되는 경우 ─────────────────────────────────────────────────────────

GOOD = _child('''
    import json, sys
    for line in sys.stdin:
        if not line.strip():
            continue
        ask = json.loads(line)
        loc = {"file": "level5", "kind": "asset", "fmt": "typetree",
               "ptr": "m_Text", "path_id": 7}
        print(json.dumps({"ok": True, "rows": [["説明", loc]],
                          "stats": {"objects": 3}}, ensure_ascii=False),
              flush=True)
''')


def test_a_working_child_hands_back_real_locations():
    with _FakeWorker(GOOD) as w:
        rows, stats = w.read(Path("/game/level5"))
    assert rows == [("説明", Location(file="level5", kind="asset",
                                     fmt="typetree", ptr="m_Text", path_id=7))]
    assert stats["objects"] == 3


def test_one_child_serves_many_files():
    """파일마다 새로 띄우면 파이썬 시작 비용만 1분씩 듭니다."""
    with _FakeWorker(GOOD) as w:
        assert w.read(Path("/game/level0")) is not None
        first = w.proc                      # 첫 요청 때 띄웁니다
        for i in range(1, 5):
            assert w.read(Path(f"/game/level{i}")) is not None
        assert w.proc is first, "같은 자식을 계속 써야 합니다"


# ── 자식이 진짜로 죽는 경우 ──────────────────────────────────────────────

DIES = _child('''
    import json, os, sys
    n = 0
    for line in sys.stdin:
        if not line.strip():
            continue
        n += 1
        if n == 2:
            os._exit(1)          # 메모리 부족처럼 대답 없이 사라집니다
        loc = {"file": "x", "kind": "asset", "fmt": "typetree", "ptr": "t"}
        print(json.dumps({"ok": True, "rows": [["a", loc]], "stats": {}}),
              flush=True)
''')


def test_a_dead_child_is_reported_not_raised():
    """죽음은 예외로 오지 않습니다. None 으로 와야 부모가 이어 갈 수 있습니다."""
    with _FakeWorker(DIES) as w:
        assert w.read(Path("/game/a")) is not None
        assert w.read(Path("/game/big")) is None       # 여기서 죽습니다
        assert w.deaths == 1


def test_work_continues_after_a_death():
    """이것이 핵심입니다 — 한 파일을 잃어도 나머지는 살아야 합니다."""
    with _FakeWorker(DIES) as w:
        got = [w.read(Path(f"/game/f{i}")) for i in range(4)]
        deaths = w.deaths
    # 이 가짜 자식은 **받은 두 번째 요청**에서 죽습니다. 새로 띄우면 그
    # 셈이 다시 시작되므로 죽는 자리는 1번과 3번입니다.
    assert [g is None for g in got] == [False, True, False, True]
    assert deaths == 2, "죽을 때마다 다시 띄워 이어 가야 합니다"
    assert len([g for g in got if g is not None]) == 2


# ── 자식이 오류를 잡아서 돌려주는 경우 ───────────────────────────────────

COMPLAINS = _child('''
    import json, sys
    for line in sys.stdin:
        if not line.strip():
            continue
        print(json.dumps({"ok": False, "why": "ValueError: 이상한 파일"},
                         ensure_ascii=False), flush=True)
''')


def test_a_caught_error_keeps_the_child_alive():
    """잡힌 오류는 죽음이 아닙니다. 자식을 버리면 다음 파일이 느려집니다."""
    with _FakeWorker(COMPLAINS) as w:
        with pytest.raises(RuntimeError, match="이상한 파일"):
            w.read(Path("/game/a"))
        first = w.proc
        with pytest.raises(RuntimeError, match="이상한 파일"):
            w.read(Path("/game/b"))
        assert w.proc is first and w.deaths == 0


# ── 죽은 까닭을 사람 말로 ────────────────────────────────────────────────

def test_a_32bit_python_gets_the_answer_that_actually_fixes_it(monkeypatch):
    monkeypatch.setattr(sys, "maxsize", 2 ** 31 - 1)
    say = isolate.why_it_died(Path("/없음"))
    assert "32비트" in say and "64비트" in say


def test_a_big_file_says_it_is_big(tmp_path):
    big = tmp_path / "level5"
    big.write_bytes(b"\0" * (70 * 1024 * 1024))
    say = isolate.why_it_died(big)
    assert "70MB" in say


def test_the_reason_never_shows_developer_words(tmp_path):
    for p in (tmp_path / "x", Path("/없음")):
        say = isolate.why_it_died(p)
        for word in ("Error", "Traceback", "malloc"):
            assert word not in say


# ── 진짜 자식 프로그램 ───────────────────────────────────────────────────

def test_the_real_child_answers_and_does_not_nest(tmp_path):
    """``python -m gameloc.isolate`` 가 실제로 돌아야 합니다.

    그리고 자식 안에서 또 자식을 띄우면 프로세스가 끝없이 늘어납니다.
    """
    from gameloc import extract

    env = dict(os.environ)
    env["PYTHONPATH"] = ROOT + os.pathsep + env.get("PYTHONPATH", "")
    env.pop("GAMELOC_NO_ISOLATE", None)
    junk = tmp_path / "level5"
    junk.write_bytes(b"NOT-A-UNITY-FILE" * 20)
    ask = json.dumps({"path": str(junk), "root": str(tmp_path),
                      "threshold": 0.5, "unity_version": "", "include_latin": False})
    out = subprocess.run([sys.executable, "-m", "gameloc.isolate"],
                         input=ask + "\n", capture_output=True, text=True,
                         env=env, timeout=120)
    got = json.loads(out.stdout.strip().splitlines()[-1])
    # 읽히든 안 읽히든, **한 줄짜리 대답**이 와야 부모가 이어 갈 수 있습니다.
    assert "ok" in got
    if not got["ok"]:
        assert got["why"], "못 읽었으면 까닭을 말해야 합니다"
    else:
        assert got["rows"] == []

    monkey = sys.argv[0]
    try:
        sys.argv[0] = "/어딘가/gameloc/isolate.py"
        assert extract._isolated() is False, "자식 안에서 또 띄우면 안 됩니다"
    finally:
        sys.argv[0] = monkey


def test_the_switch_turns_it_off(monkeypatch):
    from gameloc import extract

    monkeypatch.setenv("GAMELOC_NO_ISOLATE", "1")
    assert extract._isolated() is False


# ── 진행 소식과 무한 대기 (2.0.1) ────────────────────────────────────────
#
# 진짜 신고: Mono 유니티 게임에서 문장 뽑기가 몇십 분째 파일 이름 하나만
# 띄우고 있었습니다. 실제 파일은 2.4GB 짜리 data.unity3d 하나였습니다.
#
# 원인이 둘이었고 **둘 다 제가 만든 것**입니다.

def _talking(tmp_path, monkeypatch) -> isolate.Worker:
    """말을 넣어 줄 수 있는 일꾼. 자식 대신 우리가 줄을 큐에 넣습니다."""
    w = isolate.Worker(tmp_path, 0.0)
    monkeypatch.setattr(w, "_alive", lambda: True)
    w.proc = types.SimpleNamespace(
        stdin=types.SimpleNamespace(write=lambda _s: None, flush=lambda: None))
    w._watching = w.proc                    # 갈래는 우리가 대신합니다
    monkeypatch.setattr(w, "_watch", lambda: None)
    return w


def test_the_child_can_report_while_it_works(monkeypatch, tmp_path):
    """``_from_unity_file`` 안의 진행 표시가 자식한테서도 나와야 합니다.

    그 코드는 원래 있었습니다. 주석에 ``data.unity3d`` 라고 이름까지 적어
    두고서, 읽기를 자식에게 옮길 때 ``progress`` 를 안 넘겨서 통째로
    끊어 놨습니다. **바로 그 파일에서만** 안 나오게 만든 셈입니다.
    """
    w = _talking(tmp_path, monkeypatch)
    said: list[str] = []
    for line in ('{"tick": "      … 2,000/38,242개 읽는 중 (약 12분 남음)"}',
                 '{"tick": "      … 4,000/38,242개 읽는 중"}',
                 '{"ok": true, "rows": [], "stats": {"monobehaviours": 7}}'):
        w._lines.put(line + "\n")

    got = w.read(tmp_path / "data.unity3d", progress=said.append)
    assert got is not None
    _rows, stats = got
    assert stats["monobehaviours"] == 7
    assert len(said) == 2, "중간 소식이 사라졌습니다"
    assert "38,242" in said[0] and "남음" in said[0]


def test_silence_is_cut_but_work_is_not(monkeypatch, tmp_path):
    """자르는 기준은 **전체 시간이 아니라 소식이 끊긴 시간**입니다.

    전체 시간으로 자르면 한 시간짜리 큰 게임을 다 읽어 가다가 버립니다.
    """
    monkeypatch.setattr(isolate, "SILENCE", 0.15)
    w = _talking(tmp_path, monkeypatch)
    monkeypatch.setattr(w, "close", lambda: None)

    assert w.read(tmp_path / "big") is None, "말이 없는데도 계속 기다렸습니다"
    assert "진행이 없었" in w.last_why
    assert "메모리" not in w.last_why, "굳은 것과 죽은 것은 처방이 다릅니다"


def test_a_long_job_that_keeps_talking_is_never_cut(monkeypatch, tmp_path):
    import threading

    monkeypatch.setattr(isolate, "SILENCE", 0.3)
    w = _talking(tmp_path, monkeypatch)

    def drip():
        import time
        for i in range(6):                  # 0.6초 — SILENCE 의 두 배
            time.sleep(0.1)
            w._lines.put('{"tick": "일하는 중 %d"}\n' % i)
        w._lines.put('{"ok": true, "rows": [], "stats": {}}\n')

    threading.Thread(target=drip, daemon=True).start()
    got = w.read(tmp_path / "big", progress=lambda _m: None)
    assert got is not None, "일하고 있는데 잘랐습니다"


def test_the_timeout_constant_is_actually_used():
    """2.0 에는 ``TIMEOUT = 900`` 이 있었는데 **어디서도 안 썼습니다.**

    그래서 ``readline()`` 이 영원히 기다렸고, 그게 무한 로딩의 정체였습니다.
    상수를 선언해 놓고 안 붙이면 없는 것보다 나쁩니다 — 있는 줄 알거든요.
    """
    import inspect

    assert not hasattr(isolate, "TIMEOUT"), "안 쓰는 상수가 다시 생겼습니다"
    src = inspect.getsource(isolate)
    assert "timeout=SILENCE" in src, "기다리는 곳에 안 붙어 있습니다"
