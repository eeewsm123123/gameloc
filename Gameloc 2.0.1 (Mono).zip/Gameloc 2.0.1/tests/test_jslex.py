# SPDX-License-Identifier: GPL-3.0-or-later
"""플러그인 js 를 건드려도 게임이 죽지 않는지."""

import subprocess
import shutil

import pytest

from gameloc import jslex


def _bodies(src):
    return [lit.text for lit in jslex.literals(src)]


# ── 찾기 ─────────────────────────────────────────────────────────────────

def test_skips_line_comment():
    src = "// don't touch 日本語\nvar a = '文字';\n"
    assert _bodies(src) == ["文字"]


def test_skips_block_comment():
    src = "/* it's a 'trap' */\nvar a = \"文字\";\n"
    assert _bodies(src) == ["文字"]


def test_skips_regex_literal():
    src = "var re = /['\"]/g;\nvar a = '文字';\n"
    assert _bodies(src) == ["文字"]


def test_division_is_not_regex():
    src = "var x = a / b; var s = '文字'; var y = c / d;"
    assert _bodies(src) == ["文字"]


def test_apostrophe_inside_double_quotes():
    src = "var s = \"It's 文字\";"
    assert _bodies(src) == ["It's 文字"]


def test_template_with_substitution_is_marked():
    lits = jslex.literals("var s = `${name}님 안녕`;")
    assert len(lits) == 1 and lits[0].subst


def test_plain_template_is_translatable():
    lits = jslex.literals("var s = `文字`;")
    assert len(lits) == 1 and not lits[0].subst


def test_unterminated_quote_does_not_swallow_file():
    src = "var bad = 'ここで끝나지않음\nvar good = '文字';\n"
    assert "文字" in _bodies(src)


# ── 이스케이프 ────────────────────────────────────────────────────────────

@pytest.mark.parametrize("raw,want", [
    (r"a\nb", "a\nb"),
    (r"a\tb", "a\tb"),
    (r"文字", "文字"),
    (r"\x41", "A"),
    (r"\u{1F600}", "\U0001F600"),
    (r"it\'s", "it's"),
])
def test_decode(raw, want):
    assert jslex.decode(raw) == want


@pytest.mark.parametrize("value", [
    "따옴표 \" 와 ' 와 ` 전부",
    "역슬래시 \\ 하나",
    "줄바꿈\n포함",
    "캐리지리턴\r포함",
    "탭\t포함",
    "제어문자\x01포함",
    "구분자  포함",
    "템플릿 ${name} 처럼 생긴 것",
])
@pytest.mark.parametrize("quote", ["'", '"', "`"])
def test_encode_roundtrip(value, quote):
    enc = jslex.encode(value, quote)
    src = "var s = %s%s%s;" % (quote, enc, quote)
    lits = jslex.literals(src)
    assert len(lits) == 1
    assert lits[0].text == value


# ── 바꾸기 ───────────────────────────────────────────────────────────────

def test_replace_only_touches_strings():
    src = "// 文字 는 주석\nvar re = /文字/;\nvar s = '文字';\n"
    out, n = jslex.replace(src, {"文字": "글자"})
    assert n == 1
    assert out == "// 文字 는 주석\nvar re = /文字/;\nvar s = '글자';\n"


def test_replace_handles_both_quote_styles():
    src = "var a = '文字'; var b = \"文字\";"
    out, n = jslex.replace(src, {"文字": "글자"})
    assert n == 2
    assert out == "var a = '글자'; var b = \"글자\";"


def test_replace_escapes_quotes_in_translation():
    src = "var a = '文字';"
    out, _ = jslex.replace(src, {"文字": "그가 '안녕' 이라 했다"})
    assert jslex.literals(out)[0].text == "그가 '안녕' 이라 했다"


def test_replace_escapes_newline_in_translation():
    src = 'var a = "文字";'
    out, _ = jslex.replace(src, {"文字": "첫 줄\n둘째 줄"})
    assert "\n" not in jslex.literals(out)[0].raw
    assert jslex.literals(out)[0].text == "첫 줄\n둘째 줄"


def test_replace_leaves_substitution_templates_alone():
    src = "var s = `${n}文字`;"
    out, n = jslex.replace(src, {"${n}文字": "글자"})
    assert (out, n) == (src, 0)


def test_replace_keeps_escapes_meaning():
    src = r"var s = '文字\nつづき';"
    out, _ = jslex.replace(src, {"文字\nつづき": "글자\n계속"})
    assert jslex.literals(out)[0].text == "글자\n계속"
    assert "\\n" in out


def test_replace_is_noop_when_nothing_matches():
    src = "var s = '文字';"
    assert jslex.replace(src, {"없는말": "x"}) == (src, 0)


NODE = shutil.which("node")


@pytest.mark.skipif(not NODE, reason="node 없음")
@pytest.mark.parametrize("value", [
    "그가 '안녕' 이라 했다",
    '따옴표 " 포함',
    "백틱 ` 포함",
    "역슬래시 \\ 포함",
    "줄바꿈\n포함",
    "캐리지리턴\r포함",
    "${name} 처럼 생긴 것",
    "이모지 \U0001F600 포함",
])
@pytest.mark.parametrize("quote", ["'", '"', "`"])
def test_node_still_parses(tmp_path, value, quote):
    """실제 자바스크립트 엔진이 읽을 수 있는지 — 게임과 같은 잣대."""
    src = "var s = %s%s%s;\n" % (quote, "文字", quote)
    out, n = jslex.replace(src, {"文字": value})
    assert n == 1
    f = tmp_path / "p.js"
    f.write_text(out, "utf-8")
    r = subprocess.run([NODE, "--check", str(f)], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr


def test_patch_js_refuses_when_verification_fails(tmp_path, monkeypatch):
    """확인에 실패하면 파일을 쓰지 않고 알립니다."""
    from gameloc import apply as ap

    f = tmp_path / "P.js"
    f.write_text("var s = '文字';\n", "utf-8")
    monkeypatch.setattr(jslex, "encode", lambda v, q: v)   # 일부러 망가뜨립니다
    with pytest.raises(RuntimeError):
        ap._patch_js(f, tmp_path, {"文字": "따옴표 ' 포함"}, dry_run=False)
    assert f.read_text("utf-8") == "var s = '文字';\n"


@pytest.mark.skipif(not NODE, reason="node 없음")
def test_patch_js_end_to_end(tmp_path):
    from gameloc import apply as ap

    src = (
        "// 「はい」 は 주석\n"
        "var re = /「はい」/g;\n"
        "var a = '「はい」';\n"
        "var b = \"それで、'はい' と\";\n"
        "var c = `テンプレ`;\n"
        "var d = `${x}はい`;\n"
    )
    f = tmp_path / "P.js"
    f.write_text(src, "utf-8")
    n = ap._patch_js(f, tmp_path, {
        "「はい」": '"네"\n그렇게',
        "それで、'はい' と": "그래서 '네' 라고",
        "テンプレ": "템플릿 ${x} \\ 백슬래시",
    }, dry_run=False)
    assert n == 3
    out = f.read_text("utf-8")
    assert "// 「はい」 は 주석" in out                      # 주석은 그대로
    assert "/「はい」/g" in out                              # 정규식도 그대로
    assert "${x}はい" in out                                # 치환 템플릿은 그대로
    r = subprocess.run([NODE, "--check", str(f)], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
