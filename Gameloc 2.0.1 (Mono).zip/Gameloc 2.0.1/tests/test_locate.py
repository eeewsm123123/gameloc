"""'어디있나' 진단 — 게임 텍스트가 파일에서 어떻게 생겼는지를 견디는지.

화면에서 한 덩어리로 보이는 대사가 파일에서는 줄마다 명령이 따로고 문장 한가운데
색 제어문자가 박혀 있습니다. 단순 문자열 검색으로는 못 찾습니다.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from gameloc.extract import extract
from gameloc.locate import find, normalize


def cmd(code, params):
    return {"code": code, "indent": 0, "parameters": params}


@pytest.fixture
def game(tmp_path: Path) -> Path:
    root = tmp_path / "Game"
    (root / "data").mkdir(parents=True)
    (root / "js").mkdir()
    (root / "img").mkdir()
    (root / "js" / "rmmz_core.js").write_text("//", "utf-8")
    (root / "js" / "rmmz_windows.js").write_text(
        'Window_NameInput.JAPAN1 = [ "あ","決定" ];\n', "utf-8")

    def w(name, obj):
        (root / "data" / name).write_text(
            json.dumps(obj, ensure_ascii=False, separators=(",", ":")), "utf-8")

    w("System.json", {"gameTitle": "深夜の図書館", "terms": {"basic": ["レベル"]}})
    # 실제 게임 그대로: 두 줄로 쪼개지고, 문장 한가운데 색 제어문자
    w("Map001.json", {"displayName": "自室", "events": [None, {
        "id": 1, "pages": [{"list": [
            cmd(101, ["Actor1", 0, 0, 2]),
            cmd(401, ["仕事を手伝いに行かないと。"]),
            cmd(401, ["\\C[18]厨房\\C[0]で彼女が待ってるはずだ。"]),
            cmd(0, []),
        ]}]}]})
    (root / "img" / "title.png").write_bytes(b"\x89PNG " + "深夜".encode())
    return root


# ------------------------------------------------------------------ 정규화
def test_normalize_strips_codes_and_space():
    assert normalize("\\C[18]厨房\\C[0]で彼女が") == "厨房で彼女が"
    assert normalize("%1は %2 のダメージ") == "はのダメージ"
    assert normalize("한 줄\n두 줄") == "한줄두줄"
    assert normalize("　전각 공백") == "전각공백"


# ------------------------------------------------------------------ 찾기
def test_finds_line_with_control_codes_in_the_middle(game):
    """스크린샷의 실패 사례 그대로 — 색 코드가 문장 한가운데 있다."""
    rep = find(game, "厨房で彼女が待ってるはずだ。")
    assert rep.hits, "제어문자 때문에 못 찾으면 안 된다"
    h = rep.hits[0]
    assert h.file.endswith("Map001.json")
    assert "제어문자 무시" in h.how
    assert "\\C[18]" in h.raw, "파일에 실제로 든 모양을 보여줘야 한다"
    assert "list[2].parameters[0]" in h.where


def test_finds_dialogue_split_over_two_commands(game):
    """화면에서 본 대로 두 줄을 통째로 붙여넣어도 찾아야 한다."""
    rep = find(game, "仕事を手伝いに行かないと。\n厨房で彼女が待ってるはずだ。")
    assert rep.hits
    h = rep.hits[0]
    assert "2줄에 나뉘어 있음" in h.how
    assert "list[1]" in h.where and "list[2]" in h.where


def test_plain_exact_match_still_works(game):
    rep = find(game, "深夜の図書館")
    assert rep.hits and "정확히 일치" in rep.hits[0].how


def test_partial_match(game):
    rep = find(game, "彼女が待って")
    assert rep.hits and "일부 일치" in rep.hits[0].how


def test_reports_already_extracted(game):
    proj = extract(game)
    rep = find(game, "厨房で彼女が待ってるはずだ。", proj)
    assert rep.in_project
    assert "이미 목록에" in rep.verdict()
    assert "\\C[18]" in rep.project_text


def test_reports_translated_but_not_applied(game):
    proj = extract(game)
    for e in proj.entries:
        if "厨房" in e.text:
            e.translations["ko"] = "주방에서 그녀가 기다리고 있을 거야."
    rep = find(game, "厨房で彼女が待ってるはずだ。", proj)
    assert rep.translated
    assert "적용" in rep.verdict()


def test_engine_core_flagged_uncovered(game):
    rep = find(game, "決定")
    core = next(h for h in rep.hits if "rmmz_windows" in h.file)
    assert core.covered is False and "코어" in core.reason


def test_images_are_not_searched(game):
    rep = find(game, "深夜")
    assert not any(h.file.endswith(".png") for h in rep.hits)
    assert rep.skipped_binary >= 1


def test_missing_text_says_so(game):
    rep = find(game, "이 게임에 절대 없는 문장입니다")
    assert not rep.hits and "찾지 못했습니다" in rep.verdict()


def test_too_short_query_is_ignored(game):
    assert find(game, "あ").hits == []
    assert find(game, "").hits == []
