# SPDX-License-Identifier: GPL-3.0-or-later
"""덧씌우기 — 원본을 안 건드리고 사전 + 후크를 얹는 길 (백로그 D).

네 엔진 중 사고가 하나도 없었던 것은 Ren'Py 뿐인데, Ren'Py 만 이 방식입니다.
같은 길을 RPG Maker 와 티라노에도 냅니다.
"""

import json
import types

import pytest

from gameloc import overlay


# ── plugins.js 에 우리 것 달기 ───────────────────────────────────────────
#
# 게임마다 이 파일의 모양이 제각각입니다. 줄바꿈 자리, 세미콜론, 주석,
# 마지막 쉼표 — 어느 것 하나 믿을 수 없습니다.

SHAPES = {
    "MZ 기본": 'var $plugins =\n[\n{"name":"A","status":true},\n'
               '{"name":"B","status":false}\n];\n',
    "한 줄": 'var $plugins = [{"name":"A","status":true}];',
    "빈 목록": 'var $plugins =\n[\n];\n',
    "주석 붙음": '// 건드리지 마세요\nvar $plugins =\n[\n'
                 '{"name":"A","status":true}\n];\n// 끝\n',
    "세미콜론 없음": 'var $plugins = [\n{"name":"A","status":true}\n]\n',
}


@pytest.mark.parametrize("shape", sorted(SHAPES))
def test_our_entry_lands_and_the_file_still_parses(shape):
    got = overlay.rm_register(SHAPES[shape])
    body = got[got.index("["):got.rindex("]") + 1]
    items = json.loads(body)
    assert items[-1]["name"] == "GamelocKo", "맨 뒤여야 합니다"
    assert items[-1]["status"] is True


@pytest.mark.parametrize("shape", sorted(SHAPES))
def test_the_others_are_left_exactly_as_they_were(shape):
    got = overlay.rm_register(SHAPES[shape])
    before = json.loads(SHAPES[shape][SHAPES[shape].index("["):
                                      SHAPES[shape].rindex("]") + 1])
    after = json.loads(got[got.index("["):got.rindex("]") + 1])
    assert after[:len(before)] == before


def test_we_go_last_so_other_plugins_run_first():
    """다른 플러그인이 데이터를 손본 뒤에 우리가 바꿔야 화면에 나옵니다."""
    got = overlay.rm_register(SHAPES["MZ 기본"])
    assert got.index("GamelocKo") > got.index('"name":"B"')


def test_pressing_it_twice_does_not_add_it_twice():
    once = overlay.rm_register(SHAPES["MZ 기본"])
    assert overlay.rm_register(once) == once


def test_undo_takes_our_line_out_and_leaves_valid_js():
    got = overlay.rm_register(SHAPES["MZ 기본"])
    back = overlay.rm_unregister(got)
    assert "GamelocKo" not in back
    assert json.loads(back[back.index("["):back.rindex("]") + 1]) == \
        json.loads(SHAPES["MZ 기본"][SHAPES["MZ 기본"].index("["):
                                     SHAPES["MZ 기본"].rindex("]") + 1])


def test_a_file_with_no_list_is_refused_not_mangled():
    with pytest.raises(ValueError, match="플러그인 목록"):
        overlay.rm_register("var $plugins = 이상한것;")


# ── index.html 에 우리 것 달기 (티라노) ──────────────────────────────────

PAGES = {
    "보통": "<html><body><div id='tyrano'></div>\n"
            "<script src='./tyrano/tyrano.min.js'></script>\n</body></html>",
    "대문자": "<HTML><BODY>\n<SCRIPT src='x.js'></SCRIPT>\n</BODY></HTML>",
    "body 없음": "<html><head></head>\n<script src='x.js'></script>\n</html>",
}


@pytest.mark.parametrize("shape", sorted(PAGES))
def test_the_hook_is_added_once_at_the_end(shape):
    got = overlay.ty_register(PAGES[shape])
    assert got.count("gameloc_ko.js") == 1
    assert got.index("gameloc_ko.js") > got.index("x.js") \
        if "x.js" in PAGES[shape] else True
    assert overlay.ty_register(got) == got          # 두 번 눌러도 하나


def test_undo_takes_the_hook_line_out():
    got = overlay.ty_register(PAGES["보통"])
    assert "GamelocKo" not in overlay.ty_unregister(got)
    assert "tyrano.min.js" in overlay.ty_unregister(got)


# ── 사전이 후크 파일 안에 같이 들어가야 합니다 ───────────────────────────

def test_the_dictionary_travels_inside_the_hook():
    """따로 불러오게 만들면 파일 읽기가 막힌 게임에서 조용히 실패합니다."""
    src = overlay.rm_plugin_source({"説明": "설명"})
    assert "$gamelocKo" in src and "설명" in src
    assert "fetch(" not in src and "XMLHttpRequest" not in src


def test_the_dictionary_is_valid_json_even_with_awkward_text():
    nasty = {'그는 "안녕" 이라 했다\n다음 줄': '그는 "hi" 라 했다\n다음 줄',
             "\\역슬래시\\": "\\backslash\\"}
    src = overlay.ty_hook_source(nasty)
    body = src[src.index("{"):src.index(";\n")]
    assert json.loads(body) == nasty


# ── 실제로 게임 폴더에 얹기 ──────────────────────────────────────────────

def entry(text, ko="", ident=False):
    return types.SimpleNamespace(
        text=text, translations={"ko": ko} if ko else {}, locations=[])


def proj(*entries, engine="rpgmaker"):
    return types.SimpleNamespace(entries=list(entries), engine=engine,
                                 identifiers=[], languages=["ko"],
                                 game_root=None, source_lang="ja")


@pytest.fixture
def rm_game(tmp_path):
    g = tmp_path / "G"
    (g / "js" / "plugins").mkdir(parents=True)
    (g / "data").mkdir()
    (g / "js" / "plugins.js").write_text(SHAPES["MZ 기본"], "utf-8")
    (g / "js" / "rmmz_core.js").write_text("//", "utf-8")
    return g


def test_the_original_data_files_are_never_opened(rm_game):
    from gameloc.apply import apply_overlay

    keep = (rm_game / "data" / "Map001.json")
    keep.write_text('{"displayName":"教室"}', "utf-8")
    before = keep.read_bytes()
    rep = apply_overlay(proj(entry("教室", "교실")), "ko", game_root=rm_game)
    assert rep.strings_written == 1
    assert keep.read_bytes() == before, "원본은 열지도 않아야 합니다"


def test_the_hook_and_the_registration_both_land(rm_game):
    from gameloc.apply import apply_overlay

    apply_overlay(proj(entry("教室", "교실")), "ko", game_root=rm_game)
    hook = rm_game / "js" / "plugins" / overlay.RM_PLUGIN
    assert hook.is_file() and "교실" in hook.read_text("utf-8")
    assert "GamelocKo" in (rm_game / "js" / "plugins.js").read_text("utf-8")


def test_the_edited_file_is_backed_up_but_the_new_one_is_not(rm_game):
    from gameloc.apply import BACKUP_DIR, apply_overlay

    apply_overlay(proj(entry("教室", "교실")), "ko", game_root=rm_game)
    assert (rm_game / BACKUP_DIR / "js" / "plugins.js").is_file()
    assert not (rm_game / BACKUP_DIR / "js" / "plugins" /
                overlay.RM_PLUGIN).exists(), "새로 넣은 것은 백업할 게 없습니다"


def test_undo_puts_the_game_back_exactly(rm_game):
    from gameloc.apply import apply_overlay, restore

    (rm_game / "data" / "Map001.json").write_text('{"a":"教室"}', "utf-8")
    before = {p.relative_to(rm_game): p.read_bytes()
              for p in rm_game.rglob("*") if p.is_file()}
    apply_overlay(proj(entry("教室", "교실")), "ko", game_root=rm_game)
    restore(rm_game)
    after = {p.relative_to(rm_game): p.read_bytes()
             for p in rm_game.rglob("*") if p.is_file()
             and "__gameloc_backup__" not in p.parts}
    assert after == before


def test_names_the_game_points_at_are_still_protected(rm_game):
    """덧씌우기라고 아무 글자나 바꾸면 안 됩니다. 이름은 여기서도 위험합니다."""
    from gameloc.apply import apply_overlay

    p = proj(entry("教室", "교실"), entry("talk_start", "대화시작"))
    rep = apply_overlay(p, "ko", game_root=rm_game)
    hook = (rm_game / "js" / "plugins" / overlay.RM_PLUGIN).read_text("utf-8")
    assert "교실" in hook
    assert "대화시작" not in hook, "이름 모양은 빠져야 합니다"
    assert rep.risky and "talk_start" in rep.risky[0]


def test_a_dry_run_writes_nothing(rm_game):
    from gameloc.apply import apply_overlay

    rep = apply_overlay(proj(entry("教室", "교실")), "ko", game_root=rm_game,
                        dry_run=True)
    assert rep.strings_written == 1
    assert not (rm_game / "js" / "plugins" / overlay.RM_PLUGIN).exists()
    assert "GamelocKo" not in (rm_game / "js" / "plugins.js").read_text("utf-8")


def test_unity_is_told_plainly_that_this_road_does_not_exist(tmp_path):
    from gameloc.apply import apply_overlay

    rep = apply_overlay(proj(entry("a", "가"), engine="unity"), "ko",
                        game_root=tmp_path)
    assert rep.failures and "덧씌우기" in rep.failures[0]


def test_renpy_goes_the_way_it_already_went(tmp_path):
    """Ren'Py 는 원래부터 이 방식입니다. 두 벌로 나뉘면 안 됩니다."""
    from gameloc.apply import apply_overlay

    (tmp_path / "game").mkdir()
    (tmp_path / "game" / "script.rpy").write_text('"あ"', "utf-8")
    rep = apply_overlay(proj(entry("あ", "아"), engine="renpy"), "ko",
                        game_root=tmp_path)
    assert (tmp_path / "game").is_dir()
    assert rep.strings_written == 1


# ── 화면에서 부르는 길 ────────────────────────────────────────────────────
#
# 함수는 멀쩡한데 그리로 가는 통로가 끊겨 있던 적이 오늘만 두 번입니다.

def test_the_screen_offers_this_road_only_where_it_exists(monkeypatch):
    from gameloc import webui

    def offered(engine):
        monkeypatch.setattr(webui.STATE, "project",
                            proj(engine=engine), raising=False)
        acts = webui.api_stuck({"what": "notshown"})["actions"]
        return any(a.get("do") == "overlay" for a in acts)

    assert offered("rpgmaker") and offered("tyrano")
    assert not offered("unity"), "유니티는 [마지막 수단] 이 그 자리입니다"
    assert not offered("renpy"), "Ren'Py 는 원래부터 이 방식입니다"


def test_pressing_it_on_the_screen_really_lays_the_hook(rm_game, monkeypatch):
    from gameloc import webui

    box = {}
    monkeypatch.setattr(webui.STATE, "game", rm_game, raising=False)
    monkeypatch.setattr(webui.STATE, "project",
                        proj(entry("教室", "교실")), raising=False)
    monkeypatch.setattr(webui.STATE, "save", lambda: None, raising=False)
    monkeypatch.setattr(webui.STATE, "start_job",
                        lambda _t, job: box.update(
                            out=job(box.setdefault("log", []).append)),
                        raising=False)
    webui.api_apply({"lang": "ko", "how": "overlay"})
    assert box["out"]["strings"] == 1
    assert (rm_game / "js" / "plugins" / overlay.RM_PLUGIN).is_file()
    assert "덧씌우기" in "\n".join(box["log"])
