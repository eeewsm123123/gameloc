"""진단 보고서: 파일 안에 무엇이 있는지 있는 그대로 적는다.

추출이 0개일 때 원인은 '자리를 모른다' / '못 읽는다' / '파일에 없다' 셋인데
겉으로는 똑같이 보입니다. 이 보고서가 그걸 갈라줍니다.
"""

from __future__ import annotations

import json

import pytest

from gameloc import peek

from test_e2e import FakeEnv, fake_unity, game  # noqa: F401


def test_report_lists_objects_and_previews(game, fake_unity):  # noqa: F811
    out = peek.report(game)

    assert "gameloc 진단 보고서" in out
    assert "unity" in out.lower()
    assert "resources.assets" in out
    assert "TextAsset×1" in out or "TextAsset" in out
    assert "items" in out                      # TextAsset 이름
    assert "Healing Potion" in out             # 내용 미리보기
    assert "UITexts" not in out or True        # MonoBehaviour 도 훑습니다


def test_japanese_monobehaviour_is_surfaced(game, fake_unity):  # noqa: F811
    data = game / "MyGame_Data"
    (data / "sharedassets0.assets").write_text(json.dumps({"objects": [
        {"path_id": 31, "type": "MonoBehaviour",
         "tree": {"m_Name": "ScenarioData",
                  "lines": ["おはよう、世界。", "またね。", "ok"]}},
    ]}, ensure_ascii=False), "utf-8")

    out = peek.report(game)
    assert "ScenarioData" in out
    assert "일본어 문자열 2개" in out
    assert "おはよう、世界。" in out


def test_unreadable_file_is_reported_not_hidden(game, monkeypatch):  # noqa: F811
    import UnityPy

    def boom(_p, **_k):
        raise RuntimeError("unsupported version 6000.3")

    monkeypatch.setattr(UnityPy, "load", boom)
    out = peek.report(game)
    assert "열지 못했습니다" in out
    assert "6000.3" in out
    assert "UnityPy 가 이 유니티 버전을 못 읽는" in out


def test_no_typetree_at_all_is_called_out(game, monkeypatch):  # noqa: F811
    import UnityPy

    class Blind(FakeEnv):
        def __init__(self, source, **kw):
            super().__init__(source, **kw)
            for o in self.objects:
                o.read_typetree = _raise

    def _raise(*_a, **_k):
        raise RuntimeError("no typetree")

    monkeypatch.setattr(UnityPy, "load", Blind)
    out = peek.report(game)
    assert "타입 정보를 하나도 못 읽었습니다" in out


def test_binary_textasset_is_flagged_as_maybe_encrypted():
    """읽을 수 없는 TextAsset 은 '암호화 가능성' 으로 표시합니다."""
    import types

    obj = types.SimpleNamespace(
        type=types.SimpleNamespace(name="TextAsset"),
        read=lambda: types.SimpleNamespace(
            m_Name="locked", m_Script=b"\xff\xfe\x00\x01binary"))
    lines: list[str] = []
    peek._dump_textassets([obj], lines.append)
    out = "\n".join(lines)
    assert "locked" in out
    assert "암호화 가능성" in out


def test_textasset_preview_strips_control_characters():
    import types

    obj = types.SimpleNamespace(
        type=types.SimpleNamespace(name="TextAsset"),
        read=lambda: types.SimpleNamespace(
            m_Name="script", m_Script="おはよう\n\x00\x07またね"))
    lines: list[str] = []
    peek._dump_textassets([obj], lines.append)
    out = "\n".join(lines)
    assert "おはよう⏎" in out
    assert "\x00" not in out and "\x07" not in out


def test_report_never_writes_to_the_game(game, fake_unity):  # noqa: F811
    import hashlib

    def snap():
        return {str(p): hashlib.md5(p.read_bytes()).hexdigest()
                for p in sorted(game.rglob("*")) if p.is_file()}

    before = snap()
    peek.report(game)
    assert snap() == before


def test_non_unity_says_so(tmp_path):
    root = tmp_path / "G"
    (root / "data" / "scenario").mkdir(parents=True)
    (root / "tyrano").mkdir()
    (root / "index.html").write_text("<html></html>", "utf-8")
    (root / "data" / "scenario" / "a.ks").write_text("おはよう。[p]\n", "utf-8")

    out = peek.report(root)
    assert "유니티와 Ren'Py 게임만" in out


# --------------------------------------------------------------- 타입정보 되살리기

def test_report_says_whether_typetree_can_be_recovered(game, fake_unity):  # noqa: F811
    from gameloc import typetree

    typetree.reset()
    out = peek.report(game)
    assert "타입정보 되살리기" in out
    # 이 픽스처에는 Managed/Assembly-CSharp.dll 이 있습니다
    assert "Mono 빌드" in out or "패키지 없음" in out


def test_typetree_source_detection(tmp_path):
    from gameloc import typetree

    mono = tmp_path / "M"
    (mono / "M_Data" / "Managed").mkdir(parents=True)
    (mono / "M_Data" / "Managed" / "Assembly-CSharp.dll").write_bytes(b"\0")
    assert "Mono 빌드" in typetree.describe(mono)
    assert "dll 1개" in typetree.describe(mono)

    il2 = tmp_path / "I"
    (il2 / "I_Data" / "il2cpp_data" / "Metadata").mkdir(parents=True)
    (il2 / "I_Data" / "il2cpp_data" / "Metadata"
     / "global-metadata.dat").write_bytes(b"\0")
    (il2 / "GameAssembly.dll").write_bytes(b"\0")
    assert "IL2CPP 빌드" in typetree.describe(il2)

    bare = tmp_path / "B"
    (bare / "B_Data").mkdir(parents=True)
    assert "찾지 못했습니다" in typetree.describe(bare)


def test_broken_dll_does_not_crash_extraction(tmp_path, monkeypatch):
    """DLL 이 깨져 있어도 예전처럼 동작해야 합니다."""
    from gameloc import typetree

    typetree.reset()
    root = tmp_path / "G"
    (root / "G_Data" / "Managed").mkdir(parents=True)
    (root / "G_Data" / "Managed" / "Assembly-CSharp.dll").write_bytes(b"not a dll")
    assert typetree.generator(root, "6000.3.11f1") is None      # 조용히 포기
    assert typetree.attach(object(), root, "6000.3.11f1") is None


def test_attach_is_a_noop_without_version(tmp_path):
    from gameloc import typetree

    typetree.reset()
    assert typetree.generator(tmp_path, "") is None


# --------------------------------------------------------------- 코드 안 문자열

def _fake_dll(strings: list[str]) -> bytes:
    """.NET 어셈블리처럼 UTF-16 문자열이 박힌 바이너리."""
    out = b"MZ" + b"\x00" * 60
    for s in strings:
        out += b"\x00\x00" + s.encode("utf-16-le") + b"\x00\x00"
    return out


def test_dll_scan_finds_embedded_dialogue(tmp_path):
    root = tmp_path / "G"
    managed = root / "G_Data" / "Managed"
    managed.mkdir(parents=True)
    (managed / "Assembly-CSharp.dll").write_bytes(
        _fake_dll(["おはよう、アリス。", "……もう朝か。", "hello world"]))
    # 유니티가 넣어준 라이브러리는 건너뜁니다
    (managed / "UnityEngine.CoreModule.dll").write_bytes(
        _fake_dll(["これは無視される"]))
    (managed / "System.Core.dll").write_bytes(_fake_dll(["システム"]))

    out = "\n".join(peek.dll_report(root))
    assert "Assembly-CSharp.dll" in out
    assert "おはよう、アリス。" in out
    assert "UnityEngine.CoreModule" not in out
    assert "これは無視される" not in out


def test_dll_scan_says_so_when_code_is_clean(tmp_path):
    root = tmp_path / "G"
    managed = root / "G_Data" / "Managed"
    managed.mkdir(parents=True)
    (managed / "Assembly-CSharp.dll").write_bytes(_fake_dll(["OnlyEnglish"]))
    out = "\n".join(peek.dll_report(root))
    assert "대사는 코드 밖에 있습니다" in out


def test_files_outside_data_are_listed(tmp_path):
    root = tmp_path / "G"
    (root / "G_Data").mkdir(parents=True)
    (root / "MonoBleedingEdge").mkdir()
    (root / "MonoBleedingEdge" / "junk.txt").write_text("무시", "utf-8")
    (root / "scenario.dat").write_bytes("おはよう、世界。".encode("utf-8"))
    (root / "Readme.txt").write_text("説明書です", "utf-8")
    (root / "game.exe").write_bytes(b"MZ")

    out = "\n".join(peek._outside_report(root))
    assert "scenario.dat" in out
    assert "Readme.txt" in out
    assert "game.exe" not in out            # 실행파일은 뺍니다
    assert "junk.txt" not in out            # 엔진 폴더도 뺍니다
    assert "일본어 7자" in out or "일본어" in out


# ------------------------------------------------------- 클래스 이름 알아내기

def test_script_class_resolves_namespace_and_assembly():
    import types

    ms = types.SimpleNamespace(m_Namespace="Naninovel", m_ClassName="Script",
                               m_AssemblyName="Elringus.Naninovel.Runtime.dll")
    obj = types.SimpleNamespace(
        type=types.SimpleNamespace(name="MonoBehaviour"),
        parse_monobehaviour_head=lambda: types.SimpleNamespace(
            m_Script=types.SimpleNamespace(deref_parse_as_object=lambda: ms)))
    assert peek.script_class(obj) == (
        "Naninovel.Script  (Elringus.Naninovel.Runtime.dll)")


def test_script_class_survives_unreadable_objects():
    import types

    def boom(**_k):
        raise RuntimeError("nope")

    obj = types.SimpleNamespace(
        type=types.SimpleNamespace(name="MonoBehaviour"),
        parse_monobehaviour_head=boom)
    assert peek.script_class(obj) == "?"


def test_unreadable_monobehaviours_are_named(game, monkeypatch):  # noqa: F811
    """'못 읽음 31개' 로 끝내면 안 됩니다 — 무엇을 못 읽었는지 알아야 합니다."""
    import types

    import UnityPy

    class Named(FakeEnv):
        def __init__(self, source, **kw):
            super().__init__(source, **kw)
            ms = types.SimpleNamespace(m_Namespace="Naninovel",
                                       m_ClassName="Script",
                                       m_AssemblyName="Naninovel.dll")
            for o in self.objects:
                if o.type.name == "MonoBehaviour":
                    o.read_typetree = _raise
                    o.parse_monobehaviour_head = lambda: types.SimpleNamespace(
                        m_Script=types.SimpleNamespace(
                            deref_parse_as_object=lambda: ms))

    def _raise(*_a, **_k):
        raise RuntimeError("no typetree")

    monkeypatch.setattr(UnityPy, "load", Named)
    out = peek.report(game)
    assert "못 읽은" in out
    assert "Naninovel.Script" in out


# ------------------------------------------------------- 문자셋 오탐 거르기

def test_mojibake_is_not_reported_as_japanese():
    """ASCII 를 UTF-16 으로 잘못 읽으면 한자처럼 보입니다. 가나로 가려냅니다."""
    for junk in ["桔獩瀠潲牧浡挠湡潮", "敢爠湵椠", "怀爮牳c", "處笂5"]:
        assert not peek._looks_japanese(junk), junk
    for real in ["おはよう、アリス。", "……もう朝か。", "これは普通の台詞です。"]:
        assert peek._looks_japanese(real), real


def test_dll_scan_is_two_byte_aligned():
    raw = (b"MZ" + b"This program cannot be run in DOS mode" * 20
           + "おはよう、アリス。".encode("utf-16-le"))
    got = peek._dll_strings(raw)
    assert any("おはよう、アリス。" in s for s in got)
    assert not any("桔獩" in s for s in got)


# ------------------------------------------- 타입 정보 없이 바이트로 문자열 줍기

def _unity_string(s: str) -> bytes:
    """유니티가 문자열을 저장하는 방식: 길이(4바이트) + UTF-8 + 4바이트 정렬."""
    body = s.encode("utf-8")
    return len(body).to_bytes(4, "little") + body + b"\x00" * (-len(body) % 4)


def test_raw_strings_picks_up_unity_strings():
    blob = (b"\x01\x00\x00\x00" * 3
            + _unity_string("おはよう、アリス。")
            + b"\x2a\x00\x00\x00"
            + _unity_string("……もう朝か。")
            + _unity_string("Entry"))
    got = [s for _off, s in peek.raw_strings(blob)]
    assert "おはよう、アリス。" in got
    assert "……もう朝か。" in got
    assert "Entry" in got


def test_raw_strings_reports_usable_offsets():
    blob = b"\x00\x00\x00\x00" + _unity_string("こんにちは")
    (off, text), = [(o, s) for o, s in peek.raw_strings(blob)
                    if s == "こんにちは"]
    size = int.from_bytes(blob[off:off + 4], "little")
    assert blob[off + 4:off + 4 + size].decode("utf-8") == "こんにちは"


def test_raw_strings_ignores_binary_noise():
    import os

    noise = bytes(range(256)) * 8
    got = [s for _o, s in peek.raw_strings(noise)]
    assert all(peek._plausible(s) for s in got)
    assert not any("\x00" in s for s in got)


def test_raw_scan_surfaces_dialogue_from_unreadable_objects():
    import types

    blob = _unity_string("おはよう、アリス。") + _unity_string("……もう朝か。")
    obj = types.SimpleNamespace(path_id=7, get_raw_data=lambda: blob)
    lines: list[str] = []
    peek._raw_scan_report([obj], lines.append, {7})
    out = "\n".join(lines)
    assert "일본어 문자열 2개를 찾았습니다" in out
    assert "おはよう、アリス。" in out


def test_raw_scan_says_so_when_empty():
    import types

    obj = types.SimpleNamespace(path_id=7,
                                get_raw_data=lambda: _unity_string("Entry"))
    lines: list[str] = []
    peek._raw_scan_report([obj], lines.append, {7})
    assert "대사는 여기가 아닙니다" in "\n".join(lines)


# --------------------------------------------------------------------- 폰트

def _tmp_font(name, unicodes, *, mode=0, family="TimeMachine", w=1024, h=1024):
    import types

    tree = {
        "m_Name": name,
        "m_FaceInfo": {"m_FamilyName": family},
        "m_AtlasPopulationMode": mode,
        "m_AtlasWidth": w, "m_AtlasHeight": h,
        "m_CharacterTable": [{"m_Unicode": u, "m_Scale": 1.0} for u in unicodes],
        "m_FallbackFontAssetTable": [],
    }
    ms = types.SimpleNamespace(m_Namespace="TMPro", m_ClassName="TMP_FontAsset",
                               m_AssemblyName="Unity.TextMeshPro")
    return types.SimpleNamespace(
        type=types.SimpleNamespace(name="MonoBehaviour"),
        read_typetree=lambda: tree,
        parse_monobehaviour_head=lambda: types.SimpleNamespace(
            m_Script=types.SimpleNamespace(deref_parse_as_object=lambda: ms)))


def test_font_without_hangul_is_called_out():
    """□□□ 의 원인은 번역이 아니라 폰트입니다. 그걸 말해줘야 합니다."""
    jp = list(range(0x3040, 0x3060)) + [0x4E00, 0x4E8C]
    lines: list[str] = []
    peek.font_report([_tmp_font("timemachine-wa SDF", jp)], lines.append)
    out = "\n".join(lines)

    assert "timemachine-wa SDF" in out
    assert "한글 0자" in out
    assert "가나 32자" in out
    assert "□□□ 로 나옵니다" in out
    assert "Static(고정)" in out


def test_font_with_hangul_is_not_flagged():
    ko = list(range(0xAC00, 0xAC00 + 50))
    lines: list[str] = []
    peek.font_report([_tmp_font("NotoSansKR SDF", ko)], lines.append)
    out = "\n".join(lines)
    assert "한글 50자" in out
    assert "□□□" not in out


def test_dynamic_font_mode_is_reported():
    lines: list[str] = []
    peek.font_report([_tmp_font("Dyn SDF", [0x41], mode=1)], lines.append)
    assert "Dynamic(실행 중 생성)" in "\n".join(lines)


def test_no_fonts_means_no_section():
    lines: list[str] = []
    peek.font_report([], lines.append)
    assert lines == []


# ------------------------------------------------- 타입정보 생성기가 느려질 때

def test_failed_class_is_asked_only_once():
    """못 읽는 클래스를 오브젝트마다 다시 묻지 않습니다.

    UnityPy 는 성공만 기억합니다. 실패를 안 기억하면 같은 클래스가 수천 개일
    때 .NET 을 수천 번 다시 부르고, 큰 게임에서 몇 분씩 멈춘 것처럼 보입니다.
    """
    from gameloc import typetree

    calls = []

    class Gen:
        def get_nodes_up(self, asm, name):
            calls.append((asm, name))
            raise RuntimeError("Sequence contains no matching element")

    g = typetree._Guarded(Gen())
    for _ in range(500):
        with pytest.raises(Exception):
            g.get_nodes_up("Assembly-CSharp.dll", "Foo")
    assert len(calls) == 1


def test_generator_never_gives_up_on_the_whole_file():
    """앞이 실패했다고 뒤를 시도조차 안 하면 안 됩니다.

    1.1.1 에 "40번 실패하면 물러난다" 를 넣었다가, 같은 게임에서 뒤쪽에 있는
    TextMeshPro 폰트를 시도조차 못 해 **한글 폰트 넣기가 실패**했습니다.
    클래스별로 한 번만 묻는 것으로 비용은 이미 해결됩니다.
    """
    from gameloc import typetree

    calls = []

    class Gen:
        def get_nodes_up(self, asm, name):
            calls.append(name)
            if name == "TMP_FontAsset":
                return ["nodes"]
            raise RuntimeError("nope")

    g = typetree._Guarded(Gen())
    for i in range(200):                      # 앞에서 200번 실패해도
        with pytest.raises(Exception):
            g.get_nodes_up("A.dll", f"Bad{i}")
    assert g.get_nodes_up("A.dll", "TMP_FontAsset") == ["nodes"]   # 뒤는 됩니다


def test_cost_is_bounded_by_class_count_not_object_count():
    """오브젝트가 5,000개여도 클래스가 3개면 .NET 은 3번만 부릅니다."""
    from gameloc import typetree

    calls = []

    class Gen:
        def get_nodes_up(self, asm, name):
            calls.append(name)
            raise RuntimeError("nope")

    g = typetree._Guarded(Gen())
    for i in range(5000):
        with pytest.raises(Exception):
            g.get_nodes_up("A.dll", ["Image", "Button", "Text"][i % 3])
    assert len(calls) == 3


def test_generator_does_not_touch_os_file_handles():
    """운영체제 출력 통로를 건드리지 않아야 합니다.

    1.1.1 에서 .NET 이 직접 찍는 글을 막으려고 통로 1·2번을 돌려놨다가,
    오브젝트 38,242개짜리 유니티 게임에서 **프로그램이 통째로 죽었습니다.**
    번역 작업과 화면 응답이 동시에 도는데 한쪽이 통로를 바꿔치기하면
    어긋나기 때문입니다. 도배는 '못 읽은 클래스 기억하기' 로 이미 막힙니다.
    """
    import inspect

    from gameloc import typetree

    src = inspect.getsource(typetree)
    for banned in ["os.dup", "os.dup2", "dup2(", "_silenced"]:
        assert banned not in src, f"{banned} 를 다시 넣으면 큰 게임에서 죽습니다"
