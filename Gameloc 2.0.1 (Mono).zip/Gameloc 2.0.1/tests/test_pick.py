# SPDX-License-Identifier: GPL-3.0-or-later
"""사용자가 직접 고르는 길 — Ren'Py 대본, 티라노 system, 번역기 주소.

셋 다 **진짜 신고에서 나왔습니다.** 공통점이 하나 있습니다: 우리가 정한
규칙이 그 게임에는 안 맞았는데, 사용자가 그걸 뒤집을 방법이 없었습니다.
"""

import types
import zlib
from pathlib import Path

import pytest

from gameloc.engines import renpy, tyrano


# ── Ren'Py: 무엇이 있고 무엇이 왜 빠지는가 ───────────────────────────────
#
# "rpa 수동 추출을 넣어달라" 는 요청이 왔습니다. 그런데 그건 **자동이
# 실패했다는 뜻**입니다. 그래서 고르게 해 주기 전에, 못 읽은 것을 먼저
# 말해 줘야 합니다 — 예전에는 조용히 건너뛰었습니다.

@pytest.fixture
def game(tmp_path):
    g = tmp_path / "game"
    g.mkdir()
    (g / "script.rpy").write_text('label a:\n    "안녕"\n', "utf-8")
    return g


def test_plain_scripts_are_listed_and_used(game):
    got = renpy.survey(game)
    assert [x.label for x in got] == ["script.rpy"]
    assert got[0].ok and got[0].used


def test_a_compiled_twin_is_shown_but_not_read(game):
    """소스가 있으면 컴파일본은 안 읽습니다. 그래도 **보여는 줍니다.**

    소스가 옛날 것이고 컴파일본만 최신인 게임이 있습니다. 목록에서
    아예 숨기면 사용자가 그 사실을 알 길이 없습니다.
    """
    (game / "script.rpyc").write_bytes(b"RENPY RPC2....")
    got = {x.label: x for x in renpy.survey(game)}
    assert "script.rpyc" in got
    assert got["script.rpyc"].used is False
    assert ".rpy 가 있습니다" in got["script.rpyc"].skipped_for


def test_a_lone_compiled_script_is_read(game):
    (game / "other.rpyc").write_bytes(b"RENPY RPC2....")
    got = {x.label: x for x in renpy.survey(game)}
    assert got["other.rpyc"].used is True
    assert got["other.rpyc"].skipped_for == ""


def test_our_own_files_never_show_up(game):
    (game / "zzz_gameloc.rpy").write_text("# 우리 것", "utf-8")
    assert "zzz_gameloc.rpy" not in [x.label for x in renpy.survey(game)]


# ── 못 읽는 묶음을 조용히 넘기지 않기 ────────────────────────────────────

def test_a_broken_archive_says_why_in_plain_words(game):
    """예전에는 ``except: continue`` 로 조용히 넘겼습니다.

    그래서 사용자는 "왜 이 게임만 문장이 적지?" 를 알 수가 없었습니다.
    """
    (game / "archive.rpa").write_bytes(b"RPA-3.0 0000ffff 00000000\n" + b"\x00" * 40)
    got = {x.label: x for x in renpy.survey(game)}
    piece = got["archive.rpa"]
    assert piece.ok is False and piece.used is False
    assert piece.why
    for word in ("Error", "Traceback", "pickle", "zlib"):
        assert word not in piece.why


def test_something_that_is_not_an_archive_at_all(game):
    (game / "weird.rpa").write_bytes(b"NOT AN ARCHIVE")
    piece = {x.label: x for x in renpy.survey(game)}["weird.rpa"]
    assert piece.ok is False
    assert "묶음이 아닌" in piece.why


# ── 진짜 묶음 하나를 만들어서 ────────────────────────────────────────────

def _make_rpa(path: Path, files: dict[str, bytes]) -> None:
    """RPA-3.0 묶음 하나. 우리 읽기 코드와 짝을 맞춰 만듭니다."""
    import pickle

    key = 0x42424242
    body = bytearray()
    index = {}
    for name, data in files.items():
        off = 34 + len(body)             # 머리 한 줄(34바이트) 다음부터
        body += data
        index[name] = [[off ^ key, len(data) ^ key, b""]]
    raw = zlib.compress(pickle.dumps(index, protocol=2))
    head = b"RPA-3.0 %016x %08x\n" % (34 + len(body), key)
    assert len(head) == 34, len(head)
    path.write_bytes(head + bytes(body) + raw)


def test_a_real_archive_is_counted(game):
    _make_rpa(game / "scripts.rpa",
              {"a.rpy": b'label a:\n    "hi"\n', "b.png": b"\x89PNG"})
    piece = {x.label: x for x in renpy.survey(game)}["scripts.rpa"]
    assert piece.ok and piece.used and piece.inner == 1   # png 는 안 셉니다


def test_unpacking_puts_scripts_on_disk_and_leaves_the_game_alone(game, tmp_path):
    _make_rpa(game / "scripts.rpa",
              {"a.rpy": b'label a:\n    "hi"\n', "big.png": b"\x89PNG" * 100})
    before = sorted(p.name for p in game.rglob("*"))
    dest = tmp_path / "밖에"
    got = renpy.unpack_rpa(game / "scripts.rpa", dest)
    assert got == ["a.rpy"], "기본은 대본만 — 그림까지 풀면 몇 기가가 됩니다"
    assert (dest / "a.rpy").read_bytes().startswith(b"label a:")
    assert sorted(p.name for p in game.rglob("*")) == before


def test_unpacking_cannot_write_outside_the_folder(game, tmp_path):
    _make_rpa(game / "bad.rpa", {"../../밖.rpy": b'"x"'})
    dest = tmp_path / "안에"
    assert renpy.unpack_rpa(game / "bad.rpa", dest) == []
    assert not (tmp_path / "밖.rpy").exists()


# ── 사람이 고른 것이 우리 규칙을 이깁니다 ────────────────────────────────

def test_picking_reads_only_what_was_picked(game):
    (game / "other.rpy").write_text('label b:\n    "다른 것"\n', "utf-8")
    both = renpy.extract_entries(game, game.parent)
    only = renpy.extract_entries(game, game.parent, pick=["script.rpy"])
    assert len(both) > len(only)
    assert any("안녕" in t for t, _l in only)
    assert not any("다른 것" in t for t, _l in only)


def test_picking_a_compiled_twin_overrides_our_rule(game):
    """소스가 있어도 사람이 컴파일본을 고르면 그걸 읽어야 합니다.

    우리 규칙은 기본값일 뿐입니다. 일부러 고른 판단이 더 셉니다.
    """
    (game / "script.rpyc").write_bytes(b"RENPY RPC2 whatever")
    got = list(renpy._sources(game, ["script.rpyc"]))
    assert [k for _l, k, _d in got] == ["rpyc"]


def test_an_empty_pick_means_automatic(game):
    """빈 목록을 '아무것도 읽지 마' 로 읽으면 조용히 0개가 나옵니다."""
    assert len(renpy.extract_entries(game, game.parent, pick=[])) == \
        len(renpy.extract_entries(game, game.parent))


# ── 티라노: system 폴더 ──────────────────────────────────────────────────
#
# 신고: "system 안의 ks 파일은 추출이 안 되는 것 같은데 의도된 것인가요?"
# 의도한 것이 맞습니다. 그런데 그 판단이 게임에 따라 틀립니다.

@pytest.fixture
def ty(tmp_path):
    base = tmp_path / "G"
    (base / "data" / "scenario").mkdir(parents=True)
    (base / "data" / "system").mkdir()
    (base / "data" / "others").mkdir()
    # 티라노 대사는 **맨 줄**로 씁니다. 태그 속성이 아닙니다.
    (base / "data" / "scenario" / "first.ks").write_text(
        "*start\n본편 대사입니다.\n[p]\n", "utf-8")
    (base / "data" / "system" / "conf.ks").write_text(
        "*conf\n설정화면 문구입니다.\n[p]\n", "utf-8")
    (base / "data" / "others" / "doc.ks").write_text(
        "*doc\n개발메모입니다.\n[p]\n", "utf-8")
    return base


def test_system_is_skipped_by_default(ty):
    names = [p.name for p in tyrano.scenario_files(ty)]
    assert names == ["first.ks"]


def test_system_can_be_turned_on(ty):
    names = sorted(p.name for p in tyrano.scenario_files(ty, include_system=True))
    assert names == ["conf.ks", "first.ks"]


def test_others_stays_off_even_then(ty):
    """``others`` 는 플러그인 소스입니다. 켤 이유가 없습니다."""
    names = [p.name for p in tyrano.scenario_files(ty, include_system=True)]
    assert "doc.ks" not in names


def test_the_option_reaches_the_texts(ty):
    off = tyrano.extract_entries(ty, ty.parent)
    on = tyrano.extract_entries(ty, ty.parent, include_system=True)
    assert any("설정화면" in t for t, _l in on)
    assert not any("설정화면" in t for t, _l in off)


# ── 번역기 주소를 직접 넣기 ──────────────────────────────────────────────
#
# 사흘 사이에 NVIDIA NIM · LM Studio · Vertex AI 요청이 따로 왔습니다.
# 셋이 전부 같은 모양이라, 엔진 셋 대신 칸 셋을 둡니다.

def test_the_address_is_forgiving_about_how_much_you_paste():
    from gameloc import translate as mt

    for given in ("http://localhost:1234/v1",
                  "http://localhost:1234/v1/",
                  "http://localhost:1234",
                  "http://localhost:1234/v1/chat/completions"):
        p = mt.make_provider("custom", "", "m", given)
        assert p._url() == "http://localhost:1234/v1/chat/completions", given


def test_it_says_what_is_missing_instead_of_failing_oddly():
    from gameloc import translate as mt

    with pytest.raises(RuntimeError, match="주소를 넣어야"):
        mt.make_provider("custom", "", "m", "")._url()
    with pytest.raises(RuntimeError, match="모델 이름을 넣어야"):
        mt.make_provider("custom", "", "", "http://x/v1")._ask("a", "b")


def test_a_local_server_needs_no_key(monkeypatch):
    """LM Studio · Ollama 는 키가 없습니다. 빈 칸으로 막으면 안 됩니다."""
    from gameloc import translate as mt

    seen = {}

    def fake_post(url, data, headers, timeout=60):
        seen.update(url=url, headers=headers)
        return b'{"choices":[{"message":{"content":"1. \\uc548\\ub155"}}]}'

    monkeypatch.setattr(mt, "_post", fake_post)
    p = mt.make_provider("custom", "", "llama", "http://localhost:1234/v1")
    p._ask("시켜", "1. hi")
    assert "Authorization" not in seen["headers"]
    assert seen["url"] == "http://localhost:1234/v1/chat/completions"


def test_a_key_is_sent_when_there_is_one(monkeypatch):
    from gameloc import translate as mt

    seen = {}
    monkeypatch.setattr(mt, "_post", lambda u, d, h, timeout=60: (
        seen.update(h=h),
        b'{"choices":[{"message":{"content":"x"}}]}')[1])
    mt.make_provider("custom", "nvapi-123", "m",
                     "https://integrate.api.nvidia.com/v1")._ask("a", "b")
    assert seen["h"]["Authorization"] == "Bearer nvapi-123"


def test_a_reply_of_the_wrong_shape_is_shown_not_swallowed(monkeypatch):
    """남의 서버라 모양이 다를 수 있습니다. 뭉개면 사람이 원인을 못 찾습니다."""
    from gameloc import translate as mt

    monkeypatch.setattr(mt, "_post",
                        lambda *a, **k: b'{"error":{"message":"model not found"}}')
    with pytest.raises(RuntimeError, match="model not found"):
        mt.make_provider("custom", "", "m", "http://x/v1")._ask("a", "b")


def test_it_shows_up_in_the_engine_list():
    from gameloc import translate as mt

    ids = [d["id"] for d in mt.provider_list()]
    assert "custom" in ids
