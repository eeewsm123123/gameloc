"""플러그인 커맨드 인자 — 화면에는 대사로 보이지만 401 이 아닌 것들.

실제 게임에서 발견한 구조:
    {"code":357,"parameters":["BalloonMessage","showText","말풍선",
                              {"text":"\\c[21]主人公の名前\\C[0]を決めてください。", ...}]}
바닐라 대사(401)가 아니라 MZ 플러그인 커맨드의 인자입니다.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from gameloc.apply import apply as apply_translations
from gameloc.apply import restore
from gameloc.extract import extract
from gameloc.locate import find

PROMPT = "\\PS[2]\n\\c[21]主人公の名前\\C[0]を決めてください。"


def cmd(code, params):
    return {"code": code, "indent": 0, "parameters": params}


@pytest.fixture
def game(tmp_path: Path) -> Path:
    root = tmp_path / "Game"
    (root / "data").mkdir(parents=True)
    (root / "js").mkdir()
    (root / "js" / "rmmz_core.js").write_text("//", "utf-8")
    (root / "data" / "System.json").write_text(
        json.dumps({"gameTitle": "テスト"}, ensure_ascii=False,
                   separators=(",", ":")), "utf-8")
    (root / "data" / "Map001.json").write_text(json.dumps({
        "displayName": "自室",
        "events": [None, {"id": 1, "name": "EV001", "pages": [{"list": [
            cmd(357, ["BalloonMessage", "showText", "말풍선", {
                "text": PROMPT,
                "choices": '["はい","いいえ"]',
                "labelText": '["선택 안내"]',
                "actorId": "1", "x": "320", "file": "balloon.png",
            }]),
            cmd(356, ["TitlePlugin 開始"]),
            cmd(356, ["SomePlugin setFlag 3"]),
            cmd(0, []),
        ]}]}],
    }, ensure_ascii=False, separators=(",", ":")), "utf-8")
    return root


def _entry(proj, text):
    return next(e for e in proj.entries if e.text == text)


# ------------------------------------------------------------------- 추출
def test_mz_plugin_command_arg_is_extracted(game):
    proj = extract(game)
    e = _entry(proj, PROMPT)
    assert e.locations[0].ptr == "events[1].pages[0].list[0].parameters[3].text"
    assert "showText" in e.locations[0].asset


def test_nested_json_arg_reached_when_key_is_display(game):
    """중첩 JSON 안까지 도달하되, 키가 화면 문구일 때만 가져옵니다."""
    texts = {e.text for e in extract(game).entries}
    assert "선택 안내" in texts, "labels 안의 문자열까지 도달해야 한다"
    assert not {"はい", "いいえ"} & texts, "choices 는 심볼일 수 있어 손대지 않는다"


def test_non_text_args_are_skipped(game):
    texts = {e.text for e in extract(game).entries}
    for junk in ["1", "320", "balloon.png", "BalloonMessage", "showText"]:
        assert junk not in texts


def test_mv_plugin_command_only_when_it_has_japanese(game):
    texts = {e.text for e in extract(game).entries}
    assert "TitlePlugin 開始" in texts
    assert "SomePlugin setFlag 3" not in texts, "일본어 없는 명령은 코드로 본다"


# ------------------------------------------------------------------- 적용
def test_apply_plugin_command_args(game):
    proj = extract(game, languages=["ko"])
    _entry(proj, PROMPT).translations["ko"] = \
        "\\PS[2]\n\\c[21]주인공의 이름\\C[0]을 정해주세요."
    rep = apply_translations(proj, "ko")
    assert not rep.failures

    doc = json.loads((game / "data" / "Map001.json").read_text("utf-8"))
    args = doc["events"][1]["pages"][0]["list"][0]["parameters"][3]
    assert args["text"] == "\\PS[2]\n\\c[21]주인공의 이름\\C[0]을 정해주세요."
    assert json.loads(args["choices"]) == ["はい", "いいえ"], "심볼일 수 있어 그대로"
    assert args["x"] == "320" and args["file"] == "balloon.png"

    params = doc["events"][1]["pages"][0]["list"][0]["parameters"]
    assert params[0] == "BalloonMessage" and params[1] == "showText"
    assert len(doc["events"][1]["pages"][0]["list"]) == 4, "명령 개수 유지"

    restore(game)
    back = json.loads((game / "data" / "Map001.json").read_text("utf-8"))
    back_args = back["events"][1]["pages"][0]["list"][0]["parameters"][3]
    assert back_args["text"] == PROMPT


def test_find_reports_the_plugin_command_path(game):
    rep = find(game, "主人公の名前を決めてください。")
    assert rep.hits
    h = rep.hits[0]
    assert h.where == "events[1].pages[0].list[0].parameters[3].text"
    assert "제어문자 무시" in h.how
    assert h.covered


def test_find_says_in_list_after_extract(game):
    proj = extract(game)
    rep = find(game, "主人公の名前を決めてください。", proj)
    assert rep.in_project, "이제는 목록에 있어야 한다"
