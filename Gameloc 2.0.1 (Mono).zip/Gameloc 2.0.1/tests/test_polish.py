# SPDX-License-Identifier: GPL-3.0-or-later
"""계정 이름 지우기 · 태그 보호 · 사람 말 결과 · 파일 지목 · 다시 뽑기."""

import os
from pathlib import Path

import pytest

from gameloc import privacy
from gameloc.apply import ApplyReport


# ── 계정 이름 지우기 (백로그 1-B) ────────────────────────────────────────

@pytest.mark.parametrize("text", [
    r"폴더 : C:\Users\홍길동\Desktop\게임",
    r"C:/Users/홍길동/Desktop/게임",
    "/home/gildong/games/x",
    "/Users/gildong/games/x",
])
def test_home_paths_are_hidden(text, monkeypatch):
    monkeypatch.setenv("USERNAME", "홍길동")
    out = privacy.scrub(text)
    assert "홍길동" not in out and "gildong" not in out
    assert privacy.HIDDEN in out


def test_game_folder_name_survives(monkeypatch):
    """무슨 게임인지는 남아야 도울 수 있습니다."""
    monkeypatch.setenv("USERNAME", "홍길동")
    out = privacy.scrub(r"C:\Users\홍길동\Desktop\RJ406835\Data\level1")
    assert "RJ406835" in out and "level1" in out


def test_account_name_used_elsewhere_is_also_hidden(monkeypatch):
    monkeypatch.setenv("USERNAME", "홍길동")
    assert "홍길동" not in privacy.scrub(r"D:\보관\홍길동_백업\a.txt")


def test_short_or_generic_names_are_not_hunted(monkeypatch):
    """'root' 같은 이름까지 지우면 멀쩡한 글이 망가집니다."""
    monkeypatch.setenv("USERNAME", "root")
    monkeypatch.setenv("USER", "root")
    assert "gameroot" in privacy.scrub("gameroot 폴더")


def test_diagnostic_report_is_scrubbed(tmp_path, monkeypatch):
    from gameloc import peek

    monkeypatch.setenv("USERNAME", "홍길동")
    monkeypatch.setattr(peek, "_report",
                        lambda *a, **k: r"폴더 : C:\Users\홍길동\Desktop\g")
    assert "홍길동" not in peek.report(tmp_path)


# ── 결과 화면을 사람 말로 (백로그 12) ────────────────────────────────────

def test_failures_are_grouped_and_plainly_worded():
    rep = ApplyReport(lang="ko")
    rep.failures = [
        r"Data\level12: RuntimeError: Data\level12: path_id 7546 의 구조가 "
        r"어긋나 건너뜁니다 (문자열 개수가 35개 → 34개로 어긋났습니다)",
        r"Data\level8: RuntimeError: path_id 61104 의 구조가 어긋나 건너뜁니다",
        r"js\plugins\P.js: RuntimeError: 안전하지 않아 건너뜁니다 (따옴표)",
    ]
    out = rep.plain()
    assert len(out) == 2, out                    # 같은 것끼리 묶입니다
    joined = "\n".join(out)
    assert "RuntimeError" not in joined          # 개발자 말이 없습니다
    assert "path_id" not in joined               # 뜻 없는 숫자가 없습니다
    assert "level12, level8" in joined           # 파일은 모아서 한 줄
    assert "P.js" in joined


def test_plain_is_empty_when_nothing_failed():
    assert ApplyReport(lang="ko").plain() == []


def test_many_files_are_summarised():
    rep = ApplyReport(lang="ko")
    rep.failures = [f"Data/level{i}: ValueError: 잘못된 오프셋 224"
                    for i in range(20)]
    out = rep.plain()
    assert len(out) == 1 and "외 14개" in out[0]


# ── 태그 보호 (백로그 1) — 신고표를 그대로 시험으로 ──────────────────────

@pytest.mark.parametrize("text", [
    "{image=emo/happy.png}",
    "{color=#ff0000}",
    "{/color}",
    "{w=1.0}",
    "{font=gothic.ttf}",
    "{name}",
])
def test_braces_are_protected_whatever_is_inside(text):
    from gameloc import protect

    masked, codes = protect.mask(text)
    assert codes == [text], f"{text} 가 번역기에 그대로 갑니다"
    assert text not in masked


@pytest.mark.parametrize("text,piece", [
    ("배경은 img/pictures/教室.png 입니다", "img/pictures/教室.png"),
    ("bgm/theme.ogg 를 튼다", "bgm/theme.ogg"),
    ("파일 audio/se/click.wav 재생", "audio/se/click.wav"),
    ("폰트는 gothic.ttf 다", "gothic.ttf"),
])
def test_file_names_are_protected_mid_sentence(text, piece):
    """'번역 후 그림이 안 나온다' 가 가장 많던 신고입니다."""
    from gameloc import protect

    masked, codes = protect.mask(text)
    assert piece in codes
    assert piece not in masked


@pytest.mark.parametrize("text", ["\\C[3]", "\\N[1]", "%1", "<color=#fff>"])
def test_old_protections_still_work(text):
    from gameloc import protect

    assert protect.mask(text)[1] == [text]


def test_square_brackets_only_for_renpy():
    from gameloc import protect

    assert protect.mask("[player]님", engine="renpy")[1] == ["[player]"]
    assert protect.mask("선택지 [1] 번", engine="rpgmaker")[1] == []


def test_json_blobs_are_not_swallowed():
    """중괄호를 무조건 가리면 그 안의 대사를 영영 못 봅니다."""
    from gameloc import protect

    text = '{"nameHint":"主人公の名前を決めてください。"}'
    assert protect.mask(text)[1] == []


def test_masked_text_survives_a_round_trip():
    from gameloc import protect

    src = "{color=#f00}그가 img/a.png 를 봤다{/color}"
    masked, codes = protect.mask(src)
    assert protect.unmask(masked, codes) == src


# ── 파일 직접 지목 (백로그 5) ────────────────────────────────────────────

def test_text_file_is_recognised(tmp_path):
    from gameloc import pinpoint

    f = tmp_path / "a.json"
    f.write_text('{"a":"こんにちは"}', "utf-8")
    look = pinpoint.inspect(f)
    assert look.kind == "text" and look.can_read and look.can_write


def test_length_prefixed_binary_is_recognised(tmp_path):
    import struct

    from gameloc import pinpoint

    blob = b""
    for word in ("こんにちは", "さようなら", "ありがとう"):
        b = word.encode("utf-8")
        blob += struct.pack("<i", len(b)) + b + b"\x00" * (-len(b) % 4)
    f = tmp_path / "a.bin"
    f.write_bytes(blob)
    look = pinpoint.inspect(f)
    assert look.kind == "raw" and look.strings >= 3
    assert "こんにちは" in look.sample


def test_encrypted_file_says_so(tmp_path):
    from gameloc import pinpoint

    f = tmp_path / "a.pak"
    f.write_bytes(os.urandom(20000))
    look = pinpoint.inspect(f)
    assert look.kind == "unreadable"
    assert "암호화" in look.verdict()


def test_missing_file_says_so(tmp_path):
    from gameloc import pinpoint

    assert pinpoint.inspect(tmp_path / "없음").kind == "unreadable"


# ── 찾은 자리를 다시 뽑기로 잇기 (백로그 4) ──────────────────────────────

def test_suggest_turns_a_hit_into_a_next_step():
    from gameloc.locate import FindReport, Hit, suggest

    rep = FindReport(query="x")
    rep.hits = [Hit(file="js/plugins/A.js", kind="플러그인 소스",
                    covered=True, reason=""),
                Hit(file="Data/level7", kind="유니티 파일 안",
                    covered=True, reason="")]
    got = {s["option"] for s in suggest(rep)}
    assert got == {"js", "scenes"}


def test_suggest_says_nothing_when_it_is_already_in_the_list():
    from gameloc.locate import FindReport, Hit, suggest

    rep = FindReport(query="x", in_project=True)
    rep.hits = [Hit(file="js/plugins/A.js", kind="플러그인 소스",
                    covered=True, reason="")]
    assert suggest(rep) == []


# ── 두 번 눌러도 같은 결과 (백로그 1-C) ─────────────────────────────────

def test_apply_twice_gives_the_same_result(game):  # noqa: F811
    """전에는 두 번째에 파일이 통째로 실패했습니다."""
    from gameloc import extract as ex
    from gameloc.reapply import reapply

    proj = ex.extract(game, languages=["ko"], progress=lambda _s: None)
    for e in proj.entries:
        e.translations["ko"] = "[번역]" + e.text

    first = reapply(proj, "ko", game, progress=lambda _s: None)
    assert first.strings_written and not first.failures
    for _ in range(2):
        again = reapply(proj, "ko", game, progress=lambda _s: None)
        assert not again.failures, again.failures
        assert again.strings_written == first.strings_written


def test_editing_the_table_and_applying_again_works(game):  # noqa: F811
    """표를 고쳐 다시 넣는 것이 늘 하는 일입니다."""
    from gameloc import extract as ex
    from gameloc.reapply import reapply

    proj = ex.extract(game, languages=["ko"], progress=lambda _s: None)
    for e in proj.entries:
        e.translations["ko"] = "[번역]" + e.text
    reapply(proj, "ko", game, progress=lambda _s: None)

    for e in proj.entries:
        e.translations["ko"] = "[고침]" + e.text
    rep = reapply(proj, "ko", game, progress=lambda _s: None)
    assert not rep.failures
    assert any("[고침]" in f.read_text("utf-8") for f in game.rglob("*.json"))


def test_first_apply_takes_the_fast_path(game, monkeypatch):  # noqa: F811
    """처음에는 되돌릴 것도 밀린 자리도 없습니다. 다시 뽑지 않습니다."""
    from gameloc import extract as ex
    from gameloc import reapply as R

    proj = ex.extract(game, languages=["ko"], progress=lambda _s: None)
    for e in proj.entries:
        e.translations["ko"] = "[번역]" + e.text

    called = []
    monkeypatch.setattr(ex, "extract",
                        lambda *a, **k: called.append(1) or proj)
    R.reapply(proj, "ko", game, progress=lambda _s: None)
    assert not called


from test_plugins import game  # noqa: E402,F401


# ── 흐름: 뽑기 → 번역 → 적용 ─────────────────────────────────────────────

def _html() -> str:
    from gameloc import webui

    return (Path(webui.__file__).parent / "web" / "index.html").read_text("utf-8")


def test_one_click_button_is_gone():
    """뽑는 것과 넣는 것을 한 버튼에 묶으면 사용자가 표를 못 봅니다.

    기계번역은 초벌입니다. 적용 전에 반드시 눈으로 훑을 기회가 있어야
    합니다. 그래서 [문장 뽑기] → [자동번역] → [게임에 적용] 로 나눴습니다.
    """
    html = _html()
    assert "한 번에 번역하기" not in html
    assert "btnOneClick" not in html
    assert "/api/oneclick" not in html


def test_the_oneclick_endpoint_is_gone():
    from gameloc import webui

    src = Path(webui.__file__).read_text("utf-8")
    assert "api_oneclick" not in src
    assert "/api/oneclick" not in src


def test_the_three_steps_are_all_reachable():
    html = _html()
    for need in ("btnStart", "btnAuto", "btnApply"):
        assert need in html, need


# ── 막혔을 때 도구가 실제로 닿는가 ──────────────────────────────────────

def _stuck(engine, what):
    """엔진을 갈아 끼우고 [적용이 안 되었나요?] 를 눌러 봅니다."""
    import types

    from gameloc import webui

    old = webui.STATE.project
    webui.STATE.project = types.SimpleNamespace(engine=engine)
    try:
        return webui.api_stuck({"what": what})
    finally:
        webui.STATE.project = old


def test_font_button_only_where_fonts_can_be_changed():
    """할 수 없는 일을 버튼으로 내밀면 눌러 보고 실패만 겪습니다."""
    for engine in ("unity", "renpy"):
        assert any(a["do"] == "font" for a in _stuck(engine, "boxes")["actions"])
    for engine in ("rpgmaker", "tyrano"):
        out = _stuck(engine, "boxes")
        assert not any(a["do"] == "font" for a in out["actions"])
        assert out["actions"], "할 게 없다고만 하면 안 됩니다"
        assert any("컴퓨터 글꼴" in t for t in out["steps"])


def test_stuck_actions_do_not_click_buttons_on_another_screen():
    """첫 화면의 버튼을 대신 누르는 식이면 번역 화면에서는 아무 일도
    안 일어납니다. 실제로 그랬습니다."""
    html = _html()
    body = html.split("function doStuck", 1)[1].split("\n}", 1)[0]
    for wrong in ("$('#btnFont')", "$('#btnPeek')"):
        assert wrong not in body, f"{wrong} 를 누르는 식으로 되어 있습니다"
    assert "/api/font" in body and "/api/fonts" in body
    assert "/api/peek" in body


def test_peek_is_called_with_the_game_folder():
    """경로를 안 보내면 서버가 그대로 터집니다."""
    html = _html()
    assert "api('/api/peek', {})" not in html
    assert html.count("api('/api/peek', {path: S.path})") >= 2


def test_trouble_tools_are_not_buried_in_advanced_settings():
    """□□□ 를 본 사람이 [고급 설정] 을 열어 볼 이유가 없습니다."""
    html = _html()
    advanced = html.split('<div id="advanced"', 1)[1]
    assert 'id="troubleGroup"' not in advanced
    assert 'id="btnPeek"' in html and 'id="btnFont"' in html
    assert 'id="fontSel"' in html


# ── 결과 화면을 사람 말로 (백로그 A) ─────────────────────────────────────
#
# 예전 화면은 이랬습니다.
#   ✓ …\level7 (100)
#   ! …\level8: RuntimeError: …\level8: path_id 61104 의 구조가 어긋나 …
#   [ko] 파일 17개, 문자열 2855개 적용 | … 실패 2건
#     ! …\level8: RuntimeError: …   (같은 설명 통째로 다시)

def _rep(**kw):
    from gameloc.apply import ApplyReport

    return ApplyReport(lang="ko", **kw)


def test_the_conclusion_comes_first():
    out = _rep(files_written=17, strings_written=2855).report()
    assert out[0] == "끝났습니다 — 파일 17개에 2,855개를 넣었습니다."


def test_every_warning_says_so_what():
    """심각한지 무시해도 되는지를 사용자가 알 수 있어야 합니다."""
    out = "\n".join(_rep(
        files_written=17, strings_written=2855,
        failures=["Game_Data/level8: path_id 7546 의 구조가 어긋나 건너뜁니다",
                  "Game_Data/level12: path_id 61104 의 구조가 어긋나 건너뜁니다"],
    ).report())
    assert "→ 게임은 정상으로 돕니다" in out


def test_developer_words_never_reach_the_screen():
    out = "\n".join(_rep(
        strings_written=5,
        failures=["Game_Data/level8: RuntimeError: path_id 7546 의 구조가 어긋나 "
                  "건너뜁니다 (문자열 개수가 35개 → 34개로 어긋났습니다)"],
    ).report())
    for word in ("RuntimeError", "path_id", "Error:", "Traceback"):
        assert word not in out, word


def test_the_same_kind_is_explained_once():
    out = "\n".join(_rep(
        strings_written=5,
        failures=[f"Game_Data/level{i}: 구조가 어긋나 건너뜁니다"
                  for i in range(2, 10)],
    ).report())
    assert out.count("게임 파일 안이 예상과 달라") == 1
    assert "8군데는 손대지 않았습니다" in out


def test_empty_translations_get_a_next_step():
    out = "\n".join(_rep(strings_written=5, skipped_untranslated=173).report())
    assert "173개는 번역칸이 비어 있어" in out
    assert "[게임에 적용] 을 다시 누르면" in out


def test_nothing_landed_says_what_to_look_at():
    out = _rep().report()
    assert out[0] == "한 건도 넣지 못했습니다."
    assert len(out) > 1, "까닭이나 다음 수가 있어야 합니다"


def test_a_clean_run_stays_quiet():
    out = _rep(files_written=3, strings_written=40).report()
    assert out == ["끝났습니다 — 파일 3개에 40개를 넣었습니다."]


def test_the_file_name_is_not_doubled(tmp_path):
    """_patch_file 이 이미 이름을 붙이는데 바깥에서 또 붙였습니다."""
    from gameloc.apply import ApplyReport

    rep = ApplyReport(lang="ko", strings_written=1,
                      failures=["Game_Data/level8: Game_Data/level8: 구조가 어긋나"])
    out = "\n".join(rep.report())
    assert out.count("level8") == 1
