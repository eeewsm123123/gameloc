# SPDX-License-Identifier: GPL-3.0-or-later
"""여러 곳에 나눠 보내기 (이어달리기 · 동시에).

무료 한도는 **서비스마다 따로** 걸립니다. 그래서 이어 붙이면 더해집니다.
다만 나누는 방식에 따라 **말투가 섞이는** 문제가 생겨서, 그걸 어떻게
줄였는지도 여기서 못 박습니다.
"""

import types

import pytest

from gameloc import relay as rl
from gameloc import translate as mt


def entry(text, file="a.rpy", ko=""):
    loc = types.SimpleNamespace(file=file)
    return types.SimpleNamespace(text=text, locations=[loc],
                                 translations={"ko": ko} if ko else {},
                                 machine=[], id=text)


class _Fake(mt.Provider):
    """시키는 만큼만 하고 나머지는 손도 안 대는 가짜 번역기."""

    key_id = "fake"
    needs_key = False
    batch_size = 100
    workers = 1

    def __init__(self, label="가짜", cap=None, mark="A"):
        super().__init__("")
        self.label = label
        self.cap = cap                 # 이만큼만 하고 멈춥니다 (한도 흉내)
        self.mark = mark
        self.seen: list[str] = []

    def _translate(self, texts, src, dst):
        out = []
        for t in texts:
            if self.cap is not None and len(self.seen) >= self.cap:
                out.append("")          # 못 했다는 뜻 — 빈 값은 건너뜁니다
                continue
            self.seen.append(t)
            out.append(f"{self.mark}:{t}")
        return out


def legs_of(*providers):
    """가짜 번역기를 그대로 쓰는 다리들."""
    made = []
    for p in providers:
        leg = rl.Leg("fake")
        leg.make = lambda p=p: p
        made.append(leg)
    return made


# ── 이어달리기 ───────────────────────────────────────────────────────────

def test_the_second_engine_only_gets_what_is_left():
    """앞이 해 놓은 것을 뒤에서 또 하면 말투가 섞이고 시간도 두 배입니다."""
    ents = [entry(f"line {i}") for i in range(10)]
    a, b = _Fake("가", cap=4, mark="A"), _Fake("나", mark="B")
    rep = rl.relay(ents, legs_of(a, b))

    assert len(a.seen) == 4, "첫 엔진은 자기 한도까지만 해냅니다"
    assert len(b.seen) == 6, "뒤 엔진은 남은 것만 받습니다"
    assert not set(a.seen) & set(b.seen), "같은 줄을 두 번 번역하면 안 됩니다"
    assert rep.done == 10 and rep.failed == 0


def test_the_first_engine_keeps_its_own_work():
    """앞이 번역한 줄은 앞의 것으로 남아야 합니다."""
    ents = [entry(f"line {i}") for i in range(6)]
    rl.relay(ents, legs_of(_Fake("가", cap=3, mark="A"), _Fake("나", mark="B")))
    got = [e.translations["ko"] for e in ents]
    assert got[:3] == ["A:line 0", "A:line 1", "A:line 2"]
    assert all(x.startswith("B:") for x in got[3:])


def test_a_dead_engine_is_skipped_not_fatal():
    """키가 틀렸거나 주소가 없어도 나머지로 계속 가야 합니다."""
    bad = rl.Leg("fake")
    bad.make = lambda: (_ for _ in ()).throw(RuntimeError("키가 틀렸습니다"))
    good = _Fake("나", mark="B")
    ents = [entry("a"), entry("b")]
    rep = rl.relay(ents, [bad] + legs_of(good))
    assert rep.done == 2
    assert any("키가 틀렸습니다" in (s.note or "") for s in rep.stages)


def test_it_says_which_engine_did_how_much():
    """한도가 어디서 끝났는지 알아야 다음에 계획을 짭니다."""
    ents = [entry(f"l{i}") for i in range(8)]
    rep = rl.relay(ents, legs_of(_Fake("가", cap=5), _Fake("나")))
    lines = "\n".join(rep.plain())
    assert "가: 5건" in lines and "나: 3건" in lines


def test_an_engine_that_does_nothing_says_so():
    ents = [entry("a"), entry("b")]
    rep = rl.relay(ents, legs_of(_Fake("가", cap=0), _Fake("나")))
    assert any("한 건도 못 했습니다" in (s.note or "") for s in rep.stages)


def test_already_translated_lines_are_not_touched():
    ents = [entry("a", ko="손으로 번역함"), entry("b")]
    a = _Fake("가")
    rl.relay(ents, legs_of(a))
    assert a.seen == ["b"], "이미 채워진 줄은 건드리지 않습니다"
    assert ents[0].translations["ko"] == "손으로 번역함"


def test_nothing_left_means_later_engines_are_never_called():
    ents = [entry("a")]
    a, b = _Fake("가"), _Fake("나")
    rl.relay(ents, legs_of(a, b))
    assert a.seen == ["a"] and b.seen == []


# ── 동시에 보내기: 나누는 단위가 말투를 정합니다 ─────────────────────────

def test_one_file_never_gets_split_across_engines():
    """이게 이 기능의 핵심 규칙입니다.

    문장을 하나씩 번갈아 뿌리면 **한 대화 안에서** 사람 말투가 바뀝니다.
    한 장면은 한 곳이 통째로 맡아야 합니다.
    """
    ents = ([entry(f"a{i}", file="scene1.rpy") for i in range(10)]
            + [entry(f"b{i}", file="scene2.rpy") for i in range(10)])
    parts = rl._split(ents, 2)
    for part in parts:
        files = {e.locations[0].file for e in part}
        assert len(files) <= 1, "한 파일이 두 곳으로 갈라졌습니다"


def test_the_work_is_shared_out_evenly():
    ents = ([entry(f"a{i}", file="big.rpy") for i in range(30)]
            + [entry(f"b{i}", file="mid.rpy") for i in range(20)]
            + [entry(f"c{i}", file="small.rpy") for i in range(10)])
    parts = rl._split(ents, 3)
    sizes = sorted(len(x) for x in parts)
    assert sum(sizes) == 60
    assert sizes[-1] - sizes[0] <= 20, f"몫이 너무 치우쳤습니다: {sizes}"


def test_splitting_for_one_engine_keeps_everything_together():
    ents = [entry(f"a{i}", file=f"f{i}.rpy") for i in range(5)]
    assert rl._split(ents, 1) == [ents]


def test_every_line_lands_in_exactly_one_bucket():
    ents = [entry(f"a{i}", file=f"f{i % 4}.rpy") for i in range(23)]
    parts = rl._split(ents, 3)
    seen = [e for part in parts for e in part]
    assert len(seen) == 23 and len({id(e) for e in seen}) == 23


def test_spread_actually_uses_every_engine():
    ents = [entry(f"a{i}", file=f"f{i}.rpy") for i in range(12)]
    a, b, c = _Fake("가", mark="A"), _Fake("나", mark="B"), _Fake("다", mark="C")
    rep = rl.spread(ents, legs_of(a, b, c))
    assert a.seen and b.seen and c.seen
    assert len(a.seen) + len(b.seen) + len(c.seen) == 12
    assert rep.done == 12 and rep.failed == 0


def test_spread_survives_one_engine_being_unusable():
    bad = rl.Leg("fake")
    bad.make = lambda: (_ for _ in ()).throw(RuntimeError("주소 없음"))
    good = _Fake("나", mark="B")
    ents = [entry(f"a{i}", file=f"f{i}.rpy") for i in range(4)]
    rep = rl.spread(ents, [bad] + legs_of(good))
    assert rep.done == 4


# ── 갈래 고르기 ──────────────────────────────────────────────────────────

def test_the_mode_picks_the_road():
    ents = [entry(f"a{i}", file=f"f{i}.rpy") for i in range(6)]
    a, b = _Fake("가", mark="A"), _Fake("나", mark="B")
    rl.run(ents, legs_of(a, b), mode="relay")
    assert b.seen == [], "이어달리기는 앞이 다 하면 뒤를 안 부릅니다"

    ents2 = [entry(f"x{i}", file=f"f{i}.rpy") for i in range(6)]
    c, d = _Fake("다", mark="C"), _Fake("라", mark="D")
    rl.run(ents2, legs_of(c, d), mode="spread")
    assert c.seen and d.seen, "동시에 보내기는 둘 다 씁니다"


def test_an_unknown_mode_falls_back_to_the_safe_one():
    """모르는 값이 왔을 때 말투가 섞이는 쪽으로 가면 안 됩니다."""
    ents = [entry(f"a{i}", file=f"f{i}.rpy") for i in range(4)]
    a, b = _Fake("가"), _Fake("나")
    rl.run(ents, legs_of(a, b), mode="이상한값")
    assert b.seen == []


# ── 화면에서 부르는 길 ────────────────────────────────────────────────────

def test_the_screen_can_ask_for_several_engines(monkeypatch):
    """함수는 멀쩡한데 통로가 끊겨 있던 적이 오늘만 세 번입니다."""
    from gameloc import webui

    got = {}
    monkeypatch.setattr(rl, "run",
                        lambda ents, legs, **kw: got.update(
                            legs=legs, mode=kw.get("mode")) or rl.PlanReport())
    monkeypatch.setattr(webui.STATE, "project", types.SimpleNamespace(
        entries=[], languages=["ko"], engine="renpy"), raising=False)
    monkeypatch.setattr(webui.STATE, "save", lambda: None, raising=False)
    monkeypatch.setattr(webui.STATE, "start_job",
                        lambda _t, job: job(lambda _m: None), raising=False)
    webui.api_autotranslate({"lang": "ko", "mode": "spread", "legs": [
        {"provider": "deepl", "key": "k1"},
        {"provider": "custom", "base": "http://localhost:1234/v1",
         "model": "llama"}]})
    assert got["mode"] == "spread"
    assert [x.pid for x in got["legs"]] == ["deepl", "custom"]
    assert got["legs"][1].base == "http://localhost:1234/v1"


def test_one_engine_still_works_the_old_way(monkeypatch):
    from gameloc import webui

    got = {}
    monkeypatch.setattr(mt, "translate_entries",
                        lambda ents, prov, **kw: got.update(prov=prov)
                        or mt.Report())
    monkeypatch.setattr(webui.STATE, "project", types.SimpleNamespace(
        entries=[], languages=["ko"], engine="renpy"), raising=False)
    monkeypatch.setattr(webui.STATE, "save", lambda: None, raising=False)
    monkeypatch.setattr(webui.STATE, "start_job",
                        lambda _t, job: job(lambda _m: None), raising=False)
    webui.api_autotranslate({"lang": "ko", "provider": "google"})
    assert got["prov"].key_id == "google"
