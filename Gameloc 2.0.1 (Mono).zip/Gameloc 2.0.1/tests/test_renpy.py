"""Ren'Py: 소스·묶음·컴파일본에서 대사를 뽑고, 원본을 안 건드리고 얹기."""

from __future__ import annotations

import io
import json
import pickle
import struct
import zlib
from pathlib import Path

import pytest

from gameloc import apply as apply_mod
from gameloc import extract as extract_mod
from gameloc.detect import detect
from gameloc.engines import renpy

SCRIPT = '''\
# 첫 줄은 주석입니다
define e = Character("エリー")

label start:
    e "こんにちは、世界。"
    "誰かがドアを叩いた。"          # 이 주석은 무시돼야 합니다
    e "「引用符」も大丈夫。" (what_color="#f00")
    e "改行\\nもある。"

    menu:
        "どうする？"
        "открыть дверь":
            jump door
        "何もしない" if flag:
            jump idle

    $ x = _("設定")
    "{w=0.5}"
    "images/bg.png"
    return
'''


def make_game(tmp_path: Path) -> Path:
    root = tmp_path / "MyVN"
    game = root / "game"
    game.mkdir(parents=True)
    (root / "renpy").mkdir()
    (root / "renpy" / "__init__.py").write_text(
        "version_tuple = (8, 1, 3, vc_version)\n", "utf-8")
    (game / "script.rpy").write_text(SCRIPT, "utf-8")
    return root


# ------------------------------------------------------------------ 판별

def test_detect(tmp_path):
    root = make_game(tmp_path)
    info = detect(root)
    assert info.engine == "renpy"
    assert info.rp_game == root / "game"
    assert info.unity_version == "8.1.3"
    assert "Ren'Py 8.1.3" in info.summary()


def test_detect_one_folder_deeper(tmp_path):
    root = make_game(tmp_path)
    outer = tmp_path / "download"
    outer.mkdir()
    root.rename(outer / "MyVN")
    assert renpy.is_renpy(outer) == outer / "MyVN" / "game"


# ------------------------------------------------------------------ .rpy 파싱

def test_rpy_texts():
    got = renpy.rpy_texts(SCRIPT)
    kinds = dict((t, k) for k, t in got)

    assert kinds["こんにちは、世界。"] == "say"
    assert kinds["誰かがドアを叩いた。"] == "say"
    assert kinds["「引用符」も大丈夫。"] == "say"
    assert kinds["改行\nもある。"] == "say"          # \n 이 진짜 줄바꿈으로
    assert kinds["どうする？"] == "say"      # 메뉴 머리말은 대사처럼 나옵니다
    assert kinds["открыть дверь"] == "menu"
    assert kinds["何もしない"] == "menu"
    assert kinds["設定"] == "string"

    texts = [t for _k, t in got]
    assert not any("주석" in t for t in texts)


def test_filenames_and_tag_only_are_dropped(tmp_path):
    root = make_game(tmp_path)
    texts = [t for t, _l in renpy.extract_entries(root / "game", root)]
    assert "images/bg.png" not in texts        # 파일 이름
    assert "{w=0.5}" not in texts              # 태그만 있는 줄
    assert "こんにちは、世界。" in texts


def test_comment_inside_string_survives():
    got = renpy.rpy_texts('    e "값은 #1 입니다"\n')
    assert got == [("say", "값은 #1 입니다")]


def test_existing_translation_block_ignored():
    src = 'translate korean strings:\n    old "A"\n    new "B"\n'
    assert renpy.rpy_texts(src) == []


# ------------------------------------------------------------------ .rpa 묶음

def _make_rpa(path: Path, files: dict[str, bytes], key: int = 0xDEADBEEF,
              protocol: int = 2):
    body, index = b"", {}
    header = b"RPA-3.0 %016x %08x\n" % (0, key)
    offset = len(header)
    for name, data in files.items():
        index[name] = [(offset ^ key, len(data) ^ key, b"")]
        body += data
        offset += len(data)
    header = b"RPA-3.0 %016x %08x\n" % (len(header) + len(body), key)
    path.write_bytes(header + body
                     + zlib.compress(pickle.dumps(index, protocol=protocol)))


@pytest.mark.parametrize("protocol", [2, 3, 4, 5])
def test_rpa_roundtrip(tmp_path, protocol):
    """진짜 Ren'Py 는 목차를 protocol 2 로 굳힙니다 — 그러면 빈 바이트열 하나에도
    ``__builtin__.bytes`` 를 만들라는 지시가 들어갑니다."""
    arc = tmp_path / f"archive{protocol}.rpa"
    _make_rpa(arc, {"a.rpy": b"hello", "b/c.rpy": "안녕".encode("utf-8")},
              protocol=protocol)
    index = renpy.rpa_index(arc)
    assert set(index) == {"a.rpy", "b/c.rpy"}
    assert renpy.rpa_read(arc, index["a.rpy"]) == b"hello"
    assert renpy.rpa_read(arc, index["b/c.rpy"]).decode("utf-8") == "안녕"


def test_rpa_refuses_to_build_objects(tmp_path):
    def write(path: Path, obj):
        head = b"RPA-3.0 %016x %08x\n"
        head = head % (len(head % (0, 0)), 0)
        path.write_bytes(head + zlib.compress(pickle.dumps(obj)))

    ok = tmp_path / "ok.rpa"
    write(ok, {"x": [(0, 0, b"")]})
    assert set(renpy.rpa_index(ok)) == {"x"}       # 평범한 목차는 읽힙니다

    bad = tmp_path / "bad.rpa"
    write(bad, Path("x"))                          # 클래스를 만들라는 지시
    with pytest.raises(pickle.UnpicklingError):
        renpy.rpa_index(bad)

    worse = tmp_path / "worse.rpa"
    worse.write_bytes(
        b"RPA-3.0 %016x %08x\n" % (34, 0)
        + zlib.compress(b"c__builtin__\neval\n(S'1+1'\ntR."))
    with pytest.raises(pickle.UnpicklingError):
        renpy.rpa_index(worse)


def test_rpa_is_scanned(tmp_path):
    root = make_game(tmp_path)
    (root / "game" / "script.rpy").unlink()
    _make_rpa(root / "game" / "archive.rpa",
              {"inner.rpy": SCRIPT.encode("utf-8")})
    raw = renpy.extract_entries(root / "game", root)
    assert "こんにちは、世界。" in [t for t, _l in raw]
    assert any("archive.rpa:inner.rpy" in l.file for _t, l in raw)


# ------------------------------------------------------------------ .rpyc

def _make_rpyc(lines: list[str]) -> bytes:
    """진짜 .rpyc 와 같은 모양 — 상태 dict 에 'what' 키가 들어 있는 pickle."""
    ast = [{"who": "e", "what": t, "linenumber": i} for i, t in enumerate(lines)]
    payload = zlib.compress(pickle.dumps(ast))
    head = renpy.RPYC2_MAGIC
    start = len(head) + 12 * 2
    return (head + struct.pack("<III", 1, start, len(payload))
            + struct.pack("<III", 0, 0, 0) + payload)


def test_rpyc_texts():
    data = _make_rpyc(["おはよう。", "行こうか。"])
    assert renpy.rpyc_texts(data) == ["おはよう。", "行こうか。"]


def test_rpyc_old_style():
    payload = zlib.compress(pickle.dumps([{"what": "ただの一行"}]))
    assert renpy.rpyc_texts(payload) == ["ただの一行"]


def test_rpyc_garbage_is_quiet():
    assert renpy.rpyc_texts(b"not a rpyc at all") == []


def test_rpyc_only_when_no_source(tmp_path):
    root = make_game(tmp_path)
    game = root / "game"
    (game / "script.rpyc").write_bytes(_make_rpyc(["컴파일본만 있는 대사"]))
    texts = [t for t, _l in renpy.extract_entries(game, root)]
    # script.rpy 가 있으므로 같은 이름의 .rpyc 는 건너뜁니다
    assert "컴파일본만 있는 대사" not in texts

    (game / "script.rpy").unlink()
    texts = [t for t, _l in renpy.extract_entries(game, root)]
    assert "컴파일본만 있는 대사" in texts


# ------------------------------------------------------------------ 얹기

def test_apply_writes_two_files_and_touches_nothing_else(tmp_path):
    root = make_game(tmp_path)
    before = (root / "game" / "script.rpy").read_bytes()

    proj = extract_mod.extract(root)
    assert proj.engine == "renpy"
    for e in proj.entries:
        e.translations["ko"] = "[번역] " + e.text

    rep = apply_mod.apply(proj, "ko")
    assert rep.files_written == 2
    assert not rep.failures

    # 원본은 한 바이트도 안 바뀝니다
    assert (root / "game" / "script.rpy").read_bytes() == before

    pack = json.loads((root / "game" / renpy.PACK_JSON).read_text("utf-8"))
    assert pack["こんにちは、世界。"] == "[번역] こんにちは、世界。"
    assert pack["どうする？"].startswith("[번역]")

    hook = (root / "game" / renpy.HOOK_RPY).read_text("utf-8")
    assert "config.say_menu_text_filter" in hook
    assert "config.replace_text" in hook
    assert renpy.PACK_JSON in hook


def test_restore_deletes_what_we_added(tmp_path):
    root = make_game(tmp_path)
    proj = extract_mod.extract(root)
    proj.entries[0].translations["ko"] = "번역"
    apply_mod.apply(proj, "ko")

    game = root / "game"
    (game / (renpy.HOOK_RPY + "c")).write_bytes(b"stale")   # 엔진이 만든 캐시
    assert (game / renpy.PACK_JSON).exists()

    apply_mod.restore(root)
    assert not (game / renpy.PACK_JSON).exists()
    assert not (game / renpy.HOOK_RPY).exists()
    assert not (game / (renpy.HOOK_RPY + "c")).exists()
    assert (game / "script.rpy").exists()


def test_dry_run_writes_nothing(tmp_path):
    root = make_game(tmp_path)
    proj = extract_mod.extract(root)
    proj.entries[0].translations["ko"] = "번역"
    rep = apply_mod.apply(proj, "ko", dry_run=True)
    assert rep.strings_written == 1
    assert not (root / "game" / renpy.PACK_JSON).exists()


def test_hook_python_is_valid(tmp_path):
    """후크 안의 파이썬이 문법적으로 맞는지 (init python 블록만 떼어내서)."""
    src = renpy.hook_source()
    body = src.split("init 1789 python:", 1)[1]
    dedented = "\n".join(ln[4:] if ln.startswith("    ") else ln
                         for ln in body.split("\n"))
    compile("config = type('c', (), {})()\n" + dedented, "<hook>", "exec")
