"""Ren'Py 한글 글꼴 넣기 — 원본을 안 건드리고, 실제로 글꼴이 바뀌는지."""

from __future__ import annotations

import textwrap
import types
from pathlib import Path

from gameloc import apply as apply_mod
from gameloc import font as font_mod
from gameloc import peek as peek_mod
from gameloc.detect import detect
from gameloc.engines import renpy

from test_renpy import make_game  # noqa: F401


def _fake_ttf(tmp_path: Path) -> Path:
    p = tmp_path / "한글글꼴.ttf"
    p.write_bytes(b"\x00\x01\x00\x00" + b"FAKEFONT" * 8)
    return p


def _game_with_fonts(tmp_path: Path) -> Path:
    root = make_game(tmp_path)
    game = root / "game"
    fonts = game / "gui" / "font"
    fonts.mkdir(parents=True)
    (fonts / "SourceHanSans.otf").write_bytes(b"\x00\x01\x00\x00fake")
    (game / "gui.rpy").write_text(
        'init python:\n'
        '    gui.text_font = "gui/font/SourceHanSans.otf"\n'
        '    gui.name_text_font = "DejaVuSans.ttf"\n', "utf-8")
    return root


# ------------------------------------------------------------ 글꼴 이름 모으기

def test_font_names_come_from_files_and_scripts(tmp_path):
    game = _game_with_fonts(tmp_path) / "game"
    names = renpy.font_names(game)
    assert "gui/font/SourceHanSans.otf" in names
    assert "DejaVuSans.ttf" in names          # 스크립트 + Ren'Py 기본값


def test_our_own_font_is_never_listed_as_a_source(tmp_path):
    game = _game_with_fonts(tmp_path) / "game"
    (game / (renpy.FONT_BASE + ".ttf")).write_bytes(b"\x00\x01\x00\x00")
    assert not any(renpy.FONT_BASE in n for n in renpy.font_names(game))


# ------------------------------------------------------------ 넣기

def test_fix_adds_two_files_and_touches_nothing_else(tmp_path):
    root = _game_with_fonts(tmp_path)
    before = {p: p.read_bytes() for p in root.rglob("*") if p.is_file()}

    rep = font_mod.fix(root, ttf=_fake_ttf(tmp_path))
    assert rep.engine == "renpy"
    assert len(rep.changed_files) == 2
    assert "한글 글꼴" in rep.summary()

    game = root / "game"
    assert (game / "gameloc_korean.ttf").is_file()
    assert (game / renpy.FONT_RPY).is_file()
    for p, data in before.items():
        assert p.read_bytes() == data, f"원본이 바뀌었습니다: {p}"


def test_restore_removes_the_font_again(tmp_path):
    root = _game_with_fonts(tmp_path)
    font_mod.fix(root, ttf=_fake_ttf(tmp_path))
    apply_mod.restore(root)

    game = root / "game"
    assert not (game / "gameloc_korean.ttf").exists()
    assert not (game / renpy.FONT_RPY).exists()
    assert (game / "gui" / "font" / "SourceHanSans.otf").is_file()


def test_dry_run_writes_nothing(tmp_path):
    root = _game_with_fonts(tmp_path)
    rep = font_mod.fix(root, ttf=_fake_ttf(tmp_path), dry_run=True)
    assert rep.patched
    assert not rep.changed_files
    assert not (root / "game" / "gameloc_korean.ttf").exists()


def test_wrong_file_type_is_refused(tmp_path):
    root = _game_with_fonts(tmp_path)
    bad = tmp_path / "그림.png"
    bad.write_bytes(b"\x89PNG")
    rep = font_mod.fix(root, ttf=bad)
    assert not rep.changed_files
    assert any(".ttf" in n for n in rep.notes)


# ------------------------------------------------------------ 후크가 진짜 도는지

class FakeStyle:
    font = None


def run_font_hook(game: Path):
    """Ren'Py 처럼 후크를 실행하고 config/style 을 돌려줍니다."""
    source = (game / renpy.FONT_RPY).read_text("utf-8")
    body = textwrap.dedent(source.split("init 1790 python:", 1)[1])
    config = types.SimpleNamespace(font_replacement_map={})
    style = types.SimpleNamespace(default=FakeStyle())
    exec(compile(body, str(game / renpy.FONT_RPY), "exec"),   # noqa: S102
         {"config": config, "style": style})
    return config, style


def test_hook_actually_redirects_every_font(tmp_path):
    root = _game_with_fonts(tmp_path)
    font_mod.fix(root, ttf=_fake_ttf(tmp_path))
    config, style = run_font_hook(root / "game")

    assert style.default.font == "gameloc_korean.ttf"
    for name in ("gui/font/SourceHanSans.otf", "DejaVuSans.ttf"):
        for bold in (False, True):
            for italic in (False, True):
                got = config.font_replacement_map[(name, bold, italic)]
                assert got == ("gameloc_korean.ttf", bold, italic)


def test_hook_leaves_unknown_fonts_alone(tmp_path):
    root = _game_with_fonts(tmp_path)
    font_mod.fix(root, ttf=_fake_ttf(tmp_path))
    config, _style = run_font_hook(root / "game")
    assert ("전혀 모르는 글꼴.ttf", False, False) not in config.font_replacement_map


# ------------------------------------------------------------ 들여다보기

def test_peek_reports_a_renpy_game(tmp_path):
    root = _game_with_fonts(tmp_path)
    text = peek_mod.report(root)
    assert "유니티" not in text.split("\n")[3]
    assert "game 폴더" in text
    assert "원문" in text and "글꼴" in text
    assert "아직 한글 글꼴을 넣지 않았습니다" in text


def test_peek_notices_the_font_after_fixing(tmp_path):
    root = _game_with_fonts(tmp_path)
    font_mod.fix(root, ttf=_fake_ttf(tmp_path))
    text = peek_mod.report(root)
    assert "한글 글꼴이 들어가 있습니다" in text
    assert renpy.FONT_RPY in text


def test_peek_shows_translation_status(tmp_path):
    from gameloc import extract as extract_mod

    root = _game_with_fonts(tmp_path)
    assert "아직 번역을 넣지 않았습니다" in peek_mod.report(root)

    proj = extract_mod.extract(root)
    for e in proj.entries:
        e.translations["ko"] = "《한》" + e.text
    apply_mod.apply(proj, "ko")
    text = peek_mod.report(root)
    assert "문장" in text
    assert renpy.HOOK_RPY in text


def test_detect_still_says_renpy(tmp_path):
    root = _game_with_fonts(tmp_path)
    font_mod.fix(root, ttf=_fake_ttf(tmp_path))
    assert detect(root).engine == "renpy"
