"""후크가 **실제로 글자를 바꾸는지** — Ren'Py 런타임을 흉내내 돌려봅니다.

문법이 맞는지만 보는 건 부족합니다. Ren'Py 가 하는 일을 최소한으로 흉내내서
(``config`` 객체, ``renpy.file``, init python 블록 실행) 대사 한 줄을 실제로
필터에 통과시켜 봅니다.
"""

from __future__ import annotations

import io
import json
import textwrap
import types
from pathlib import Path

import pytest

from gameloc import apply as apply_mod
from gameloc import extract as extract_mod
from gameloc.engines import renpy

from test_renpy import make_game  # noqa: F401


class FakeConfig:
    """Ren'Py 의 config. 두 자리는 기본이 None 입니다."""

    say_menu_text_filter = None
    replace_text = None


def run_hook(game: Path):
    """``game/`` 에 놓인 후크를 Ren'Py 처럼 실행하고 config 를 돌려줍니다."""
    source = (game / renpy.HOOK_RPY).read_text("utf-8")
    body = source.split("init 1789 python:", 1)[1]
    body = textwrap.dedent(body)

    fake_renpy = types.SimpleNamespace(
        file=lambda name: io.BytesIO((game / name).read_bytes()))
    config = FakeConfig()
    env = {"config": config, "renpy": fake_renpy}
    exec(compile(body, str(game / renpy.HOOK_RPY), "exec"), env)  # noqa: S102
    return config


def _applied(tmp_path: Path, mapping: dict[str, str]) -> Path:
    root = make_game(tmp_path)
    proj = extract_mod.extract(root)
    for e in proj.entries:
        if e.text in mapping:
            e.translations["ko"] = mapping[e.text]
    apply_mod.apply(proj, "ko")
    return root / "game"


def test_dialogue_is_actually_replaced(tmp_path):
    game = _applied(tmp_path, {"こんにちは、世界。": "안녕, 세계."})
    config = run_hook(game)

    assert config.say_menu_text_filter("こんにちは、世界。") == "안녕, 세계."
    assert config.replace_text("こんにちは、世界。") == "안녕, 세계."


def test_unknown_line_passes_through_unchanged(tmp_path):
    """사전에 없으면 원문 그대로. 이게 게임이 안 죽는 이유입니다."""
    game = _applied(tmp_path, {"こんにちは、世界。": "안녕, 세계."})
    config = run_hook(game)

    assert config.say_menu_text_filter("まったく知らない台詞") == "まったく知らない台詞"
    assert config.replace_text("") == ""


def test_surrounding_whitespace_still_matches(tmp_path):
    game = _applied(tmp_path, {"こんにちは、世界。": "안녕, 세계."})
    config = run_hook(game)
    assert config.replace_text("  こんにちは、世界。 ") == "  안녕, 세계. "


def test_existing_filter_is_chained_not_clobbered(tmp_path):
    """게임이나 다른 모드가 이미 필터를 쓰고 있으면 그걸 먼저 돌립니다."""
    game = _applied(tmp_path, {"こんにちは、世界。": "안녕, 세계."})
    source = (game / renpy.HOOK_RPY).read_text("utf-8")
    body = textwrap.dedent(source.split("init 1789 python:", 1)[1])

    config = FakeConfig()
    # 원래 있던 필터가 대문자 자리표시자를 진짜 대사로 바꿔준다고 칩시다
    config.say_menu_text_filter = lambda s: s.replace("[GREET]", "こんにちは、世界。")
    fake_renpy = types.SimpleNamespace(
        file=lambda name: io.BytesIO((game / name).read_bytes()))
    exec(compile(body, "<hook>", "exec"),                      # noqa: S102
         {"config": config, "renpy": fake_renpy})

    # 앞 필터가 먼저 돌고, 그 결과를 우리가 번역합니다
    assert config.say_menu_text_filter("[GREET]") == "안녕, 세계."


def test_missing_json_does_not_break_the_game(tmp_path):
    """사전 파일이 지워져도 후크가 예외를 던지면 안 됩니다."""
    game = _applied(tmp_path, {"こんにちは、世界。": "안녕, 세계."})
    (game / renpy.PACK_JSON).unlink()

    config = run_hook(game)
    assert config.say_menu_text_filter("こんにちは、世界。") == "こんにちは、世界。"


def test_broken_json_does_not_break_the_game(tmp_path):
    game = _applied(tmp_path, {"こんにちは、世界。": "안녕, 세계."})
    (game / renpy.PACK_JSON).write_text("{ 깨진 파일", "utf-8")

    config = run_hook(game)
    assert config.say_menu_text_filter("아무거나") == "아무거나"


def test_tags_and_interpolation_survive(tmp_path):
    """{b} 태그나 [name] 치환은 필터 전에 들어오므로 그대로 넘겨야 합니다."""
    root = make_game(tmp_path)
    (root / "game" / "extra.rpy").write_text(
        '    e "{b}[player]{/b}さん、おかえり。"\n', "utf-8")

    proj = extract_mod.extract(root)
    texts = [e.text for e in proj.entries]
    assert "{b}[player]{/b}さん、おかえり。" in texts

    for e in proj.entries:
        if e.text == "{b}[player]{/b}さん、おかえり。":
            e.translations["ko"] = "{b}[player]{/b}님, 어서 오세요."
    apply_mod.apply(proj, "ko")

    config = run_hook(root / "game")
    out = config.say_menu_text_filter("{b}[player]{/b}さん、おかえり。")
    assert out == "{b}[player]{/b}님, 어서 오세요."


def test_json_is_valid_utf8_json(tmp_path):
    game = _applied(tmp_path, {"こんにちは、世界。": "안녕, 세계."})
    data = json.loads((game / renpy.PACK_JSON).read_text("utf-8"))
    assert data["こんにちは、世界。"] == "안녕, 세계."
