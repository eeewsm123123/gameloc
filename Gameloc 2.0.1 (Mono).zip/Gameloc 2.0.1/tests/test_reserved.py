"""게임이 '이름으로 찾는' 문자열은 번역하면 안 된다.

실제로 두 번 게임을 죽인 사고:
    'マ海の家_波_木の揺れ' is unknown model.   ← 밑줄 이어붙인 이름
    Animation not found: 웨이브                ← ウェーブ. 평범한 가타카나 낱말

두 번째가 핵심입니다. `ウェーブ` 는 모양만으로는 대사와 구별할 방법이 없습니다.
그래서 모양이 아니라 **쓰임새**로 가립니다 — 게임 안에서 이름으로 참조되는 문자열을
미리 모아 두고, 그 목록에 있으면 번역 대상에서 뺍니다.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from gameloc.apply import apply as apply_translations
from gameloc.engines import rpgmaker
from gameloc.extract import extract

ANIM = "ウェーブ"
MODEL = "海の家_波_木の揺れ"


def cmd(code, params):
    return {"code": code, "indent": 0, "parameters": params}


@pytest.fixture
def game(tmp_path: Path) -> Path:
    root = tmp_path / "Game"
    (root / "data").mkdir(parents=True)
    (root / "js").mkdir()
    (root / "js" / "rmmz_core.js").write_text("//", "utf-8")

    def w(name, obj):
        (root / "data" / name).write_text(
            json.dumps(obj, ensure_ascii=False, separators=(",", ":")), "utf-8")

    # 애니메이션 정의 — 여기 이름을 플러그인이 참조합니다
    w("Animations.json", [None, {"id": 1, "name": ANIM},
                          {"id": 2, "name": "きらきら"}])
    w("Tilesets.json", [None, {"id": 1, "name": "海辺"}])
    w("System.json", {"gameTitle": "ウミノイエ",
                      "switches": ["", "海の家_開店"],
                      "terms": {"basic": ["レベル"]}})
    # 대사와, 애니메이션을 이름으로 부르는 플러그인 커맨드
    w("Map001.json", {"displayName": "浜辺", "events": [None, {
        "id": 1, "name": "波のイベント", "pages": [{"list": [
            cmd(357, ["AnimPlugin", "play", "재생",
                      {"fx": ANIM, "text": "波が押し寄せる。"}]),
            cmd(401, ["きれいな海だ。"]),
            cmd(0, []),
        ]}]}]})
    (root / "js" / "plugins.js").write_text(
        "var $plugins =\n[\n"
        '{"name":"LiveModel","status":true,"parameters":'
        f'{{"models":"[\\"{MODEL}\\"]","prompt":"モデルを選んでください。"}}}}\n];\n',
        "utf-8")
    return root


# ------------------------------------------------------------------- 색인
def test_index_collects_reference_names(game):
    ids = rpgmaker.collect_identifiers(game)
    assert ANIM in ids, "애니메이션 이름"
    assert "きらきら" in ids
    assert "海辺" in ids, "타일셋 이름"
    assert "海の家_開店" in ids, "스위치 이름"
    assert "波のイベント" in ids, "이벤트 이름"
    assert MODEL in ids, "플러그인 struct 이름"


def test_index_leaves_real_text_alone(game):
    ids = rpgmaker.collect_identifiers(game)
    assert "波が押し寄せる。" not in ids
    assert "きれいな海だ。" not in ids
    assert "モデルを選んでください。" not in ids


# ------------------------------------------------------------------- 추출
def test_animation_reference_is_not_extracted(game):
    """이번 사고의 핵심.

    인자 키가 `fx` 라 키 이름 목록으로는 못 거릅니다. 오직 '이 문자열은
    Animations.json 에 이름으로 등록돼 있다' 는 사실만이 이걸 막습니다.
    """
    proj = extract(game)
    texts = {e.text for e in proj.entries}
    assert ANIM not in texts, f"{ANIM} 를 번역하면 'Animation not found' 로 죽는다"
    assert MODEL not in texts
    assert "波が押し寄せる。" in texts, "같은 인자 객체의 진짜 대사는 살아 있어야 한다"
    assert "きれいな海だ。" in texts
    assert "モデルを選んでください。" in texts


def test_stats_report_the_index(game):
    proj = extract(game)
    assert proj.stats["identifiers_indexed"] > 0
    assert ANIM in proj.identifiers, "색인은 프로젝트에 저장돼 적용 때 다시 쓰인다"
    assert MODEL in proj.identifiers, "플러그인이 이름으로 쓰는 값도 색인에 든다"


# ------------------------------------------------------------------- 적용
def test_apply_blocks_reserved_name_from_old_project(game):
    """예전 목록에 남아 있어도 적용 단계에서 막는다."""
    proj = extract(game, languages=["ko"])
    from gameloc.model import Entry, Location
    proj.entries.append(Entry(
        id="zz", text=ANIM,
        locations=[Location(file="data/Map001.json", kind="loose", fmt="json",
                            ptr="events[1].pages[0].list[0].parameters[3].fx")],
        translations={"ko": "웨이브"}))
    for e in proj.entries:
        if e.text == "波が押し寄せる。":
            e.translations["ko"] = "파도가 밀려온다."

    rep = apply_translations(proj, "ko")
    doc = json.loads((game / "data" / "Map001.json").read_text("utf-8"))
    args = doc["events"][1]["pages"][0]["list"][0]["parameters"][3]
    assert args["fx"] == ANIM, "애니메이션 이름은 원문 그대로여야 한다"
    assert args["text"] == "파도가 밀려온다.", "대사는 반영돼야 한다"
    assert any(ANIM in r for r in rep.risky)
    assert "이름으로 참조" in " ".join(rep.risky)


# ==========================================================================
# 세 번 연속으로 게임을 죽인 것들을 한 자리에 모아둔 회귀 테스트.
# 이 파일이 통과하는 한 같은 방식으로는 다시 안 죽습니다.
# ==========================================================================
CRASHES = [
    ("海の家_波_木の揺れ", "'…' is unknown model — 밑줄 이어붙인 모델 이름"),
    ("ウェーブ", "Animation not found — 평범한 가타카나 낱말인 애니메이션 이름"),
    ("海の家2マップ", "'…' is unknown model — 플러그인이 등록한 모델 이름"),
]


@pytest.fixture
def crash_game(tmp_path: Path) -> Path:
    root = tmp_path / "Game"
    (root / "data").mkdir(parents=True)
    (root / "js").mkdir()
    (root / "js" / "rmmz_core.js").write_text("//", "utf-8")

    def w(name, obj):
        (root / "data" / name).write_text(
            json.dumps(obj, ensure_ascii=False, separators=(",", ":")), "utf-8")

    w("System.json", {"gameTitle": "ウミノイエ", "terms": {"basic": ["レベル"]}})
    w("Animations.json", [None, {"id": 1, "name": "ウェーブ"}])
    w("MapInfos.json", [None, {"id": 1, "name": "海の家2マップ"}])
    w("Map001.json", {"displayName": "浜辺", "events": [None, {
        "id": 1, "name": "EV001", "pages": [{"list": [
            cmd(357, ["AnimPlugin", "play", "재생",
                      {"fx": "ウェーブ", "モデル": "海の家2マップ",
                       "text": "波が押し寄せる。"}]),
            cmd(401, ["きれいな海だ。"]),
            cmd(0, []),
        ]}]}]})
    (root / "js" / "plugins.js").write_text(
        "var $plugins =\n[\n"
        '{"name":"LiveModel","status":true,"parameters":'
        '{"models":"[\\"海の家2マップ\\",\\"海の家_波_木の揺れ\\"]",'
        '"prompt":"モデルを選んでください。"}},\n'
        '{"name":"TitleMenu","status":true,"parameters":'
        '{"commands":"[\\"はじめから\\",\\"つづきから\\",\\"終了\\"]",'
        '"helpText":"방향키로 선택하세요."}}\n];\n', "utf-8")
    return root


@pytest.mark.parametrize("text,why", CRASHES)
def test_every_crash_string_stays_out(crash_game, text, why):
    assert text not in {e.text for e in extract(crash_game).entries}, why


def test_title_menu_commands_are_left_alone(crash_game):
    """메뉴 항목을 번역했더니 메뉴가 통째로 사라진 적이 있습니다."""
    texts = {e.text for e in extract(crash_game).entries}
    assert not {"はじめから", "つづきから", "終了"} & texts


def test_real_dialogue_still_comes_through(crash_game):
    texts = {e.text for e in extract(crash_game).entries}
    assert "波が押し寄せる。" in texts, "위험한 인자와 같은 객체에 있어도 대사는 살아야 한다"
    assert "きれいな海だ。" in texts
    assert "モデルを選んでください。" in texts
    assert "방향키로 선택하세요." in texts, "helpText 는 화면 문구"


@pytest.mark.parametrize("text,why", CRASHES)
def test_apply_blocks_them_even_from_a_stale_project(crash_game, text, why):
    """예전 버전으로 만든 목록(색인 없음)을 그대로 적용해도 막혀야 한다."""
    from gameloc.model import Entry, Location, Project
    proj = Project(game_root=str(crash_game), engine="rpgmaker", languages=["ko"],
                   identifiers=[],          # 예전 버전에는 색인이 없었다
                   entries=[Entry(
                       id="x", text=text,
                       locations=[Location(file="data/Map001.json", kind="loose",
                                           fmt="json", ptr="displayName")],
                       translations={"ko": "번역됨"})])
    rep = apply_translations(proj, "ko")
    assert rep.strings_written == 0, why
    assert rep.risky, "왜 건너뛰었는지 알려줘야 한다"
    doc = json.loads((crash_game / "data" / "Map001.json").read_text("utf-8"))
    assert doc["displayName"] == "浜辺"
