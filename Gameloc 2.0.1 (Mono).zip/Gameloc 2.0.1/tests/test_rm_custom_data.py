# SPDX-License-Identifier: GPL-3.0-or-later
"""RPG Maker: 게임이 **직접 만든** 데이터 파일에서도 대사를 가져오는가.

실제 신고에서 나온 시험입니다. 어떤 게임은 줄거리를 RPG Maker 파일이 아니라
자기가 만든 파일에 담습니다.

    data/ScenarioText.csv       대사 1454줄
    data/MiniScenarioText.csv   대사 1181줄

전에는 이걸 안 읽어서 메뉴·아이템만 번역되고 줄거리는 통째로 원문이었는데,
화면에는 "1215개 적용" 이라고 찍혀서 무엇이 빠졌는지 알 수가 없었습니다.
"""

import csv
import io
import json

import pytest

from gameloc.engines import rpgmaker
from gameloc.extract import extract
from gameloc.apply import apply as apply_translations

SCENARIO = (
    "scene_id,cmd,speaker,text,asset,memo\r\n"
    "s1,talk_start,,,,Confirmed source: レオン / order=1\r\n"
    "s1,text,レオン,中から声が聞こえる……,,Confirmed source: レオン / order=2\r\n"
    "s1,show_stand,,,elena_avoidant_r,Confirmed source: レオン / order=3\r\n"
    "s1,text,エレナ,「少し、お話をしてもよろしいですか」,,Confirmed source: レオン / order=4\r\n"
)


@pytest.fixture()
def rm(tmp_path):
    game = tmp_path / "G"
    (game / "data").mkdir(parents=True)
    (game / "js" / "plugins").mkdir(parents=True)
    (game / "js" / "rmmz_core.js").write_text("//", "utf-8")
    (game / "data" / "System.json").write_text(
        json.dumps({"gameTitle": "테스트"}), "utf-8")
    (game / "data" / "ScenarioText.csv").write_text(SCENARIO, "utf-8")
    (game / "data" / "TraceConversations.json").write_text(
        json.dumps({"lines": ["同じ客の名を、何度も見かける。"]},
                   ensure_ascii=False), "utf-8")
    return game


# ── 어떤 파일을 '우리가 모르는 것' 으로 볼 것인가 ─────────────────────────

def test_standard_rpgmaker_files_are_not_treated_as_custom(rm):
    base = rpgmaker.is_rpgmaker(rm)
    for name in ["Actors.json", "Map001.json", "Map0012.json", "System.json",
                 "CommonEvents.json", "MapInfos.json", "Animations.json"]:
        (base / "data" / name).write_text("{}", "utf-8")
    got = {p.name for p in rpgmaker.custom_data_files(base)}
    assert "Actors.json" not in got
    assert "Map001.json" not in got and "Map0012.json" not in got
    assert "System.json" not in got
    assert got == {"ScenarioText.csv", "TraceConversations.json"}


# ── 대사가 실제로 나오는가 ────────────────────────────────────────────────

def test_custom_csv_dialogue_is_extracted(rm):
    proj = extract(rm)
    texts = {e.text for e in proj.entries}
    assert "中から声が聞こえる……" in texts
    assert "「少し、お話をしてもよろしいですか」" in texts
    assert "同じ客の名を、何度も見かける。" in texts      # 커스텀 json 도


def test_machinery_columns_are_not_extracted(rm):
    """cmd·asset 같은 구조 칸은 대사가 아닙니다."""
    proj = extract(rm)
    texts = {e.text for e in proj.entries}
    for junk in ["talk_start", "show_stand", "elena_avoidant_r", "s1"]:
        assert junk not in texts


def test_memo_column_is_skipped(rm):
    """만든 사람이 자기 보라고 적은 칸까지 번역하면 절반이 쓸모없어집니다."""
    proj = extract(rm)
    assert not any("Confirmed source" in e.text for e in proj.entries)
    assert proj.stats.get("note_cells_skipped", 0) >= 3


# ── 넣은 뒤에도 파일이 멀쩡한가 ───────────────────────────────────────────

def test_apply_keeps_the_csv_shape(rm):
    before = list(csv.reader(io.StringIO(
        (rm / "data" / "ScenarioText.csv").read_text("utf-8"))))

    proj = extract(rm)
    for e in proj.entries:
        e.translations["ko"] = "[한]" + e.text
    rep = apply_translations(proj, "ko", game_root=rm)
    assert not rep.failures

    after = list(csv.reader(io.StringIO(
        (rm / "data" / "ScenarioText.csv").read_text("utf-8"))))
    assert len(after) == len(before)                  # 줄 수 그대로
    assert after[0] == before[0]                      # 열 이름 그대로
    for a, b in zip(before, after):
        assert len(a) == len(b)                       # 칸 수 그대로
        assert a[1] == b[1]                           # cmd 는 안 건드림
        assert a[5] == b[5]                           # memo 도 안 건드림
    assert after[2][3].startswith("[한]")             # 대사는 바뀜


def test_apply_keeps_the_json_parseable(rm):
    proj = extract(rm)
    for e in proj.entries:
        e.translations["ko"] = "[한]" + e.text
    apply_translations(proj, "ko", game_root=rm)
    doc = json.loads((rm / "data" / "TraceConversations.json").read_text("utf-8"))
    assert doc["lines"][0].startswith("[한]")


def test_report_says_how_many_came_from_custom_files(rm):
    """어디서 나왔는지 보여야 '왜 줄거리가 안 나오지' 를 스스로 알 수 있습니다."""
    lines = []
    proj = extract(rm, progress=lines.append)
    assert proj.stats["rm_custom_files"] == 2
    assert proj.stats["rm_custom_strings"] > 0
    assert any("이 게임이 직접 만든 파일" in ln for ln in lines)


# ── 플러그인 js 안에 숨은 대사를 알려주는가 ───────────────────────────────

PLUGIN_WITH_STORY = """\
//=============================================================================
// InnScenarioFlow.js
//=============================================================================
(() => {
  "use strict";
  const NAMES = { leon: 'レオン', mira: 'ミラ' };
  const RE = /レオン|ミラ/g;                 // 정규식은 문자열이 아닙니다
  // 주석 안의 日本語 도 아닙니다
  const LINES = [
    '昨日とは違う名が宿帳にあった。エレナは確かめる前から、鍵を手にしていた。',
    '「昨夜は少し話し込んでしまったの。待たせていたら、ごめんなさい」',
    '客室の前を通ると、中からエレナの小さな声が聞こえた。',
  ];
  const DEBUG = `未処理: ${pending.map((x) => x.id)}`;   // 치환 템플릿 = 코드
  const PATH = 'img/pictures/教室.png';                  // 경로
  console.log(NAMES, RE, LINES, DEBUG, PATH);
})();
"""


@pytest.fixture()
def rm_with_plugin(rm):
    (rm / "js" / "plugins" / "InnScenarioFlow.js").write_text(
        PLUGIN_WITH_STORY, "utf-8")
    return rm


def test_hidden_js_dialogue_is_counted(rm_with_plugin):
    base = rpgmaker.is_rpgmaker(rm_with_plugin)
    n = rpgmaker.count_js_dialogue(base)
    assert n == 3          # 대사 3줄만. 이름·정규식·주석·템플릿·경로는 제외


def test_user_is_told_when_js_holds_dialogue(rm_with_plugin):
    """안 켰더라도 '여기 대사가 있다' 는 알려 줘야 합니다.

    아무 말 없이 빠지면 그럴듯한 숫자만 뜨고, 사용자는 무엇이 빠졌는지
    알 방법이 없습니다.
    """
    lines = []
    proj = extract(rm_with_plugin, progress=lines.append)
    assert proj.stats["rm_js_lurking"] == 3
    joined = "\n".join(lines)
    assert "플러그인 js" in joined
    assert "플러그인 js 파일까지" in joined      # 켜야 할 곳을 짚어 줍니다


def test_no_nagging_when_js_is_clean(rm):
    """플러그인에 대사가 없으면 아무 말도 안 합니다."""
    (rm / "js" / "plugins" / "Plain.js").write_text(
        "(() => { const a = 'hello'; console.log(a); })();", "utf-8")
    lines = []
    proj = extract(rm, progress=lines.append)
    assert proj.stats.get("rm_js_lurking", 0) == 0
    assert not any("플러그인 js 안에" in ln for ln in lines)


def test_no_nagging_when_the_option_is_on(rm_with_plugin):
    lines = []
    proj = extract(rm_with_plugin, include_js=True, progress=lines.append)
    assert not any("안 가져옵니다" in ln for ln in lines)
    assert any(e.text.startswith("昨日とは違う名") for e in proj.entries)
