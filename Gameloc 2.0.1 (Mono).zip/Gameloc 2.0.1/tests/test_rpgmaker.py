"""RPG Maker MV/MZ: extract -> sheet -> apply -> restore against a fixture
game laid out exactly like a deployed NW.js build."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from gameloc.apply import apply as apply_translations
from gameloc.apply import restore
from gameloc.detect import detect
from gameloc.extract import extract
from gameloc.sheet import read_workbook, merge_into_project, write_workbook


def cmd(code, params, indent=0):
    return {"code": code, "indent": indent, "parameters": params}


@pytest.fixture
def rmgame(tmp_path: Path) -> Path:
    root = tmp_path / "Game"
    (root / "data").mkdir(parents=True)
    (root / "js").mkdir()
    (root / "js" / "rmmz_core.js").write_text("// core", "utf-8")
    (root / "package.json").write_text('{"name":"game","main":"index.html"}', "utf-8")

    def w(name, obj):
        # deployed data files are compact, single-line JSON
        (root / "data" / name).write_text(
            json.dumps(obj, ensure_ascii=False, separators=(",", ":")), "utf-8")

    w("System.json", {
        "gameTitle": "深夜の図書館",
        "currencyUnit": "ゴールド",
        "locale": "ja_JP",
        "switches": ["", "イベント済み"],          # internal, must be skipped
        "armorTypes": ["", "軽装", "重装"],
        "terms": {
            "basic": ["レベル", "Lv", "HP"],
            "commands": ["戦う", "逃げる", None],
            "params": ["最大HP", "攻撃力"],
            "messages": {
                "actionFailure": "%1には効かなかった！",
                "actorDamage": "%1は %2 のダメージを受けた！",
            },
        },
    })
    w("Actors.json", [None, {
        "id": 1, "name": "ユキ", "nickname": "見習い司書",
        "profile": "本が好きな少女。", "note": "<顔:Actor1>",
        "characterName": "Actor1", "faceName": "Actor1",
    }])
    w("Items.json", [None, {
        "id": 1, "name": "回復薬", "description": "HPを50回復する。",
        "iconIndex": 176, "note": "",
    }])
    w("CommonEvents.json", [None, {
        "id": 1, "name": "オープニング", "list": [
            cmd(101, ["Actor1", 0, 0, 2]),
            cmd(401, ["ようこそ、図書館へ。"]),
            cmd(401, ["ここでは静かにしてくださいね。"]),
            cmd(102, [["はい", "いいえ"], 1]),
            cmd(401, ["……そうですか。"]),
            cmd(108, ["編集者メモ：ここは後で直す"]),
            cmd(355, ["$gameSwitches.setValue(1, true)"]),
            cmd(0, []),
        ],
    }])
    w("Map001.json", {
        "displayName": "図書館 １階",
        "note": "",
        "events": [None, {
            "id": 1, "name": "EV001", "x": 5, "y": 6,
            "pages": [{"list": [
                cmd(401, ["棚には古い本が並んでいる。"]),
                cmd(0, []),
            ]}],
        }],
    })
    w("MapInfos.json", [None, {"id": 1, "name": "MAP001", "parentId": 0}])
    return root


def test_detect(rmgame):
    info = detect(rmgame)
    assert info.engine == "rpgmaker"
    assert info.rm_variant == "MZ"
    assert "RPG Maker MZ" in info.summary()


def test_detect_mv_www_layout(tmp_path):
    root = tmp_path / "MVGame"
    (root / "www" / "data").mkdir(parents=True)
    (root / "www" / "js").mkdir()
    (root / "www" / "js" / "rpg_core.js").write_text("//", "utf-8")
    (root / "www" / "data" / "System.json").write_text('{"gameTitle":"テスト"}', "utf-8")
    info = detect(root)
    assert info.engine == "rpgmaker" and info.rm_variant == "MV"
    assert info.rm_base == root / "www"


def test_extract_whitelist(rmgame):
    proj = extract(rmgame)
    texts = {e.text for e in proj.entries}

    # kept
    assert "深夜の図書館" in texts
    assert "ゴールド" in texts
    assert "見習い司書" in texts
    assert "HPを50回復する。" in texts
    assert "%1は %2 のダメージを受けた！" in texts
    assert "図書館 １階" in texts
    assert "はい" in texts and "いいえ" in texts
    assert "棚には古い本が並んでいる。" in texts

    # skipped: internals, script, comment, note, MapInfos
    assert "ja_JP" not in texts
    assert "イベント済み" not in texts              # switch name
    assert "Actor1" not in texts                    # face/character file
    assert "<顔:Actor1>" not in texts               # note, off by default
    assert "編集者メモ：ここは後で直す" not in texts  # comment (108)
    assert not any("gameSwitches" in t for t in texts)   # script (355)
    assert "MAP001" not in texts                    # MapInfos.json


def test_notes_opt_in(rmgame):
    assert "<顔:Actor1>" in {e.text for e in extract(rmgame, include_notes=True).entries}


def test_consecutive_lines_merge(rmgame):
    proj = extract(rmgame)
    merged = next(e for e in proj.entries if e.text.startswith("ようこそ"))
    assert merged.text == "ようこそ、図書館へ。\nここでは静かにしてくださいね。"
    assert len(merged.locations[0].span) == 2
    # the choice sits between the two runs, so "……そうですか。" stays separate
    assert "……そうですか。" in {e.text for e in proj.entries}


def test_roundtrip_and_restore(rmgame, tmp_path):
    work = tmp_path / "loc"
    work.mkdir()
    proj = extract(rmgame, languages=["ko"])
    proj.save(work / "project.json")
    write_workbook(proj, work / "translation.xlsx")

    table = {
        "深夜の図書館": "심야의 도서관",
        "ようこそ、図書館へ。\nここでは静かにしてくださいね。":
            "도서관에 오신 걸 환영해요.\n여기서는 조용히 해주세요.",
        "はい": "예",
        "いいえ": "아니오",
        "HPを50回復する。": "HP를 50 회복한다.",
        "図書館 １階": "도서관 1층",
        "%1は %2 のダメージを受けた！": "%1은(는) %2 의 피해를 입었다!",
        "棚には古い本が並んでいる。": "선반에는 낡은 책들이 늘어서 있다.",
    }
    from openpyxl import load_workbook
    wb = load_workbook(work / "translation.xlsx")
    ws = wb["번역"]
    h = [c.value for c in ws[1]]
    src, ko = h.index("원문") + 1, h.index("ko") + 1
    hit = 0
    for r in range(2, ws.max_row + 1):
        v = ws.cell(r, src).value
        if v in table:
            ws.cell(r, ko).value = table[v]
            hit += 1
    assert hit == len(table), "엑셀에 원문이 그대로 실려 있어야 함"
    wb.save(work / "translation.xlsx")

    edits, _ = read_workbook(work / "translation.xlsx")
    merge_into_project(proj, edits)
    rep = apply_translations(proj, "ko")
    assert not rep.failures

    ce = json.loads((rmgame / "data" / "CommonEvents.json").read_text("utf-8"))
    lst = ce[1]["list"]
    assert lst[1]["parameters"][0] == "도서관에 오신 걸 환영해요."
    assert lst[2]["parameters"][0] == "여기서는 조용히 해주세요."
    assert lst[3]["parameters"][0] == ["예", "아니오"]
    assert lst[4]["parameters"][0] == "……そうですか。"        # untranslated, intact
    assert lst[5]["parameters"][0] == "編集者メモ：ここは後で直す"
    assert lst[6]["parameters"][0] == "$gameSwitches.setValue(1, true)"
    assert lst[0] == {"code": 101, "indent": 0, "parameters": ["Actor1", 0, 0, 2]}
    assert len(lst) == 8, "명령 개수가 변하면 안 됨"

    sysd = json.loads((rmgame / "data" / "System.json").read_text("utf-8"))
    assert sysd["gameTitle"] == "심야의 도서관"
    assert sysd["terms"]["messages"]["actorDamage"] == "%1은(는) %2 의 피해를 입었다!"
    assert sysd["terms"]["commands"] == ["戦う", "逃げる", None]   # null survives

    mp = json.loads((rmgame / "data" / "Map001.json").read_text("utf-8"))
    assert mp["displayName"] == "도서관 1층"
    assert mp["events"][1]["pages"][0]["list"][0]["parameters"][0] == \
        "선반에는 낡은 책들이 늘어서 있다."
    assert mp["events"][1]["x"] == 5

    # files stay compact
    assert "\n" not in (rmgame / "data" / "System.json").read_text("utf-8")

    restore(rmgame)
    assert json.loads((rmgame / "data" / "System.json").read_text("utf-8"))["gameTitle"] \
        == "深夜の図書館"


def test_longer_translation_folds_into_last_slot(rmgame):
    proj = extract(rmgame, languages=["ko"])
    e = next(x for x in proj.entries if x.text.startswith("ようこそ"))
    e.translations["ko"] = "한 줄\n두 줄\n세 줄"      # 3 lines into 2 slots
    apply_translations(proj, "ko")
    lst = json.loads((rmgame / "data" / "CommonEvents.json").read_text("utf-8"))[1]["list"]
    assert lst[1]["parameters"][0] == "한 줄"
    assert lst[2]["parameters"][0] == "두 줄\n세 줄"
    assert len(lst) == 8


def test_shorter_translation_blanks_trailing_slot(rmgame):
    proj = extract(rmgame, languages=["ko"])
    e = next(x for x in proj.entries if x.text.startswith("ようこそ"))
    e.translations["ko"] = "한 줄로 끝"
    apply_translations(proj, "ko")
    lst = json.loads((rmgame / "data" / "CommonEvents.json").read_text("utf-8"))[1]["list"]
    assert lst[1]["parameters"][0] == "한 줄로 끝"
    assert lst[2]["parameters"][0] == ""
    assert len(lst) == 8
