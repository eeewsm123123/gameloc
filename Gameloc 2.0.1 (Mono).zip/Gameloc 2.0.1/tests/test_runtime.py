# SPDX-License-Identifier: GPL-3.0-or-later
"""유니티 마지막 수단 — 그리는 순간 바꿔치기.

게임 파일을 고쳐도 게임이 그 자리를 안 볼 때 씁니다. 남의 프로그램
(BepInEx · XUnity)을 게임 폴더에 넣는 일이라, **넣은 것만 지워서 원래대로
돌아가는지**가 가장 중요합니다.
"""

import types
import zipfile

import pytest

from gameloc import runtime


def entry(text, ko=""):
    e = types.SimpleNamespace(text=text, translations={})
    if ko:
        e.translations["ko"] = ko
    return e


def proj(*entries, src="ja"):
    return types.SimpleNamespace(entries=list(entries), source_lang=src,
                                 languages=["ko"])


def mkzip(path, files):
    with zipfile.ZipFile(path, "w") as z:
        for name, body in files.items():
            z.writestr(name, body)
    return path


# ── 번역표 ───────────────────────────────────────────────────────────────

def test_table_is_original_equals_translation():
    text, kept, _ = runtime.make_table(proj(entry("説明", "설명")), "ko")
    assert text == "説明=설명\n" and kept == 1


def test_real_newlines_are_escaped():
    """한 줄에 한 쌍이라, 진짜 줄바꿈이 들어가면 파일이 깨집니다."""
    text, _, _ = runtime.make_table(proj(entry("가\n나", "다\n라")), "ko")
    assert text.strip() == "가\\n나=다\\n라"
    assert text.count("\n") == 1


def test_untranslated_and_identical_are_left_out():
    text, kept, _ = runtime.make_table(
        proj(entry("A"), entry("B", "B"), entry("C", "다")), "ko")
    assert kept == 1 and text.strip() == "C=다"


def test_equals_sign_in_original_is_skipped():
    """첫 '=' 에서 갈리므로 원문에 '=' 가 있으면 엉뚱한 데서 잘립니다."""
    _text, kept, skipped = runtime.make_table(
        proj(entry("HP=100", "체력=100")), "ko")
    assert (kept, skipped) == (0, 1)


def test_literal_backslash_n_is_skipped():
    """글자 그대로 \\n 이 든 원문은 진짜 줄바꿈과 구분할 수 없습니다.

    잘못 맞느니 빠지는 편이 낫습니다.
    """
    _text, kept, skipped = runtime.make_table(
        proj(entry("가\\n나", "다")), "ko")
    assert (kept, skipped) == (0, 1)


def test_same_original_is_written_once():
    text, kept, _ = runtime.make_table(
        proj(entry("説明", "설명"), entry("説明", "설명")), "ko")
    assert kept == 1 and text.count("説明") == 1


# ── 설정 ─────────────────────────────────────────────────────────────────

def test_online_translator_is_switched_off():
    """이게 딜레이가 없는 이유입니다. 물어볼 데가 없어야 합니다."""
    cfg = runtime.make_config("ja", "ko")
    assert "Endpoint=\n" in cfg
    assert "Language=ko" in cfg and "FromLanguage=ja" in cfg


def test_auto_source_language_is_left_blank_not_guessed_as_japanese():
    """'자동' 은 **모른다**는 뜻입니다. 일본어라는 뜻이 아닙니다.

    여기서 일본어로 박아 버리면 영어 게임에서는 플러그인이 원문을
    아예 거들떠보지 않습니다 — 번역표를 다 깔고도 한 줄도 안 바뀝니다.
    무슨 말인지는 install() 이 번역표를 보고 알아냅니다.
    """
    assert "FromLanguage=\n" in runtime.make_config("auto", "ko")
    assert "FromLanguage=\n" in runtime.make_config("", "ko")


# ── 무엇이 필요한가 ──────────────────────────────────────────────────────

def info(engine="unity", backend="IL2CPP", root=None):
    return types.SimpleNamespace(engine=engine, scripting_backend=backend,
                                 unity_version="2022.3.62f2",
                                 root=root or "/없음")


def test_il2cpp_and_mono_get_different_builds(tmp_path):
    a = runtime.plan(info(backend="IL2CPP", root=tmp_path))
    b = runtime.plan(info(backend="Mono", root=tmp_path))
    assert "IL2CPP" in a.bepinex_hint and "IL2CPP" in a.xunity_hint
    assert "IL2CPP" not in b.bepinex_hint
    assert a.where != b.where


def test_il2cpp_says_what_it_cannot_do():
    p = runtime.plan(info(backend="IL2CPP"))
    assert any("시원찮" in n for n in p.notes)


def test_antivirus_is_warned_about_up_front():
    """눌러 보고 놀라게 두면 안 됩니다."""
    p = runtime.plan(info())
    assert any("백신" in n for n in p.notes)


@pytest.mark.parametrize("engine", ["rpgmaker", "renpy", "tyrano"])
def test_other_engines_are_refused(engine):
    p = runtime.plan(info(engine=engine))
    assert not p.ok() and any("유니티" in n for n in p.notes)


def test_unknown_backend_is_refused():
    assert not runtime.plan(info(backend="")).ok()


# ── 넣고 지우기 ──────────────────────────────────────────────────────────

@pytest.fixture
def game(tmp_path):
    g = tmp_path / "Game"
    (g / "Game_Data").mkdir(parents=True)
    (g / "Game.exe").write_bytes(b"MZ" + b"\x00" * 200)
    (g / "Game_Data" / "resources.assets").write_bytes(b"ORIGINAL")
    return g


@pytest.fixture
def zips(tmp_path):
    a = mkzip(tmp_path / "bep.zip",
              {"winhttp.dll": "x", "BepInEx/core/BepInEx.dll": "y"})
    b = mkzip(tmp_path / "xu.zip",
              {"BepInEx/plugins/XUnity.AutoTranslator/x.dll": "z"})
    return a, b


def test_install_puts_the_table_where_the_plugin_actually_reads(game, zips):
    """자리를 틀리면 조용히 무시됩니다 — 실제로 그렇게 됐습니다.

    게임 폴더 맨 위나 ``AutoTranslator/`` 아래에 써 두면 플러그인은 그것을
    못 보고 기본값(인터넷 번역기 켜짐)으로 돕니다.
    """
    bep, xu = zips
    before = (game / "Game_Data" / "resources.assets").read_bytes()
    out = runtime.install(game, bep, xu, proj(entry("説明", "설명")), "ko",
                          with_font=False)
    assert out["lines"] == 1
    assert (game / "winhttp.dll").is_file()
    assert (game / "BepInEx" / "Translation" / "ko" / "Text"
            / runtime.TABLE).is_file()
    assert (game / "BepInEx" / "config" / "AutoTranslatorConfig.ini").is_file()
    assert not (game / "AutoTranslator").exists()
    assert not (game / "AutoTranslatorConfig.ini").exists()
    assert (game / "Game_Data" / "resources.assets").read_bytes() == before


def test_install_also_puts_the_korean_font_in(game, zips, monkeypatch):
    """글만 바꾸고 글꼴을 안 넣으면 화면에는 □□□ 만 남습니다.

    사용자가 두 번 손대야 했고, 한쪽을 되돌리면 다른 쪽까지 날아갔습니다.
    """
    called = {}

    def fake_fix(root, *, ttf=None, progress=lambda _m: None, **kw):
        called["root"] = root
        progress("  · 글꼴 넣는 중")
        return types.SimpleNamespace(patched=["Arial"], summary=lambda: "됐습니다")

    monkeypatch.setattr("gameloc.font.fix", fake_fix)
    bep, xu = zips
    out = runtime.install(game, bep, xu, proj(entry("説明", "설명")), "ko")
    assert called["root"] == game
    assert out["fonts"] == 1


def test_font_trouble_does_not_lose_the_translation(game, zips, monkeypatch):
    """글꼴에서 넘어져도 번역표는 이미 깔려 있어야 합니다."""
    def boom(*_a, **_k):
        raise RuntimeError("글꼴 없음")

    monkeypatch.setattr("gameloc.font.fix", boom)
    bep, xu = zips
    said = []
    out = runtime.install(game, bep, xu, proj(entry("説明", "설명")), "ko",
                          progress=said.append)
    assert out["lines"] == 1 and out["fonts"] == 0
    assert (game / "BepInEx" / "Translation" / "ko" / "Text"
            / runtime.TABLE).is_file()
    assert "글꼴은 못 넣었습니다" in "\n".join(said)


def test_uninstall_puts_everything_back(game, zips):
    bep, xu = zips
    kept = sorted(p.name for p in game.rglob("*") if p.is_file())
    runtime.install(game, bep, xu, proj(entry("説明", "설명")), "ko")
    assert runtime.installed(game)
    runtime.uninstall(game)
    assert not runtime.installed(game)
    assert sorted(p.name for p in game.rglob("*") if p.is_file()) == kept
    assert not (game / "BepInEx").exists()


def test_install_refuses_when_nothing_is_translated(game, zips):
    bep, xu = zips
    with pytest.raises(RuntimeError, match="번역된 문장이 없"):
        runtime.install(game, bep, xu, proj(entry("説明")), "ko")


def test_zip_cannot_write_outside_the_game_folder(game, tmp_path):
    """악의든 실수든, 압축이 바깥으로 나가면 안 됩니다."""
    bad = mkzip(tmp_path / "bad.zip", {"../../밖에.txt": "x", "안에.txt": "y"})
    ok = mkzip(tmp_path / "ok.zip", {"b.txt": "z"})
    runtime.install(game, bad, ok, proj(entry("説明", "설명")), "ko")
    assert (game / "안에.txt").is_file()
    assert not (tmp_path / "밖에.txt").exists()
    assert not (game.parent / "밖에.txt").exists()


def test_existing_config_gets_our_three_lines(game, zips):
    """예전에는 있으면 그냥 뒀습니다. 그래서 우리 설정이 영영 안 먹었습니다.

    플러그인이 첫 실행 때 자기 설정을 만들어 두기 때문입니다 — 인터넷
    번역기가 켜진 채로 돌아 중국어가 영어로 바뀌었습니다.
    """
    bep, xu = zips
    cfg = game / runtime.CONFIG
    cfg.parent.mkdir(parents=True)
    cfg.write_text("[Service]\nEndpoint=GoogleTranslateV2\n\n"
                   "[General]\nLanguage=en\nFromLanguage=ja\n\n"
                   "[Behaviour]\nMaxCharactersPerTranslation=200\n", "utf-8")
    runtime.install(game, bep, xu, proj(entry("説明", "설명")), "ko",
                    src_lang="zh-CN", with_font=False)
    got = cfg.read_text("utf-8")
    assert "Endpoint=\n" in got                      # 인터넷 번역기 꺼짐
    assert "Language=ko" in got
    assert "FromLanguage=zh-CN" in got
    assert "MaxCharactersPerTranslation=200" in got  # 남의 설정은 그대로


# ── 원문이 무슨 말인가 ───────────────────────────────────────────────────
#
# 예전에는 '자동' 이면 무조건 일본어로 박았습니다. 영어 게임이든 중국어
# 게임이든요. 플러그인은 원문이 그 말처럼 안 생기면 손을 안 대기 때문에,
# 번역표를 다 깔아 놓고도 한 줄도 안 바뀝니다.

@pytest.mark.parametrize("text,want", [
    ("ゲームを終了しますか", "ja"),
    ("退出游戏吗", "zh-CN"),
    ("Are you sure you want to quit?", "en"),
    ("Вы уверены", "ru"),
    ("정말 나가시겠습니까", "ko"),
])
def test_guess_lang_reads_the_letters(text, want):
    assert runtime.guess_lang([text])[0] == want


def test_kana_wins_over_han():
    """일본어에는 한자가 잔뜩 있습니다. 가나 한 줌이 판을 가릅니다."""
    assert runtime.guess_lang(["新しい冒険の始まり、勇者の物語"])[0] == "ja"


def test_a_stray_letter_does_not_flip_the_verdict():
    assert runtime.guess_lang(["退出游戏吗" * 40 + "ト"])[0] == "zh-CN"


def test_a_table_with_several_languages_says_so(): 
    """유니티 Localization 게임은 번역표에 여러 말이 다 들어 있습니다.

    실제로 Liar's Bar 에서 러시아어 표가 섞여 있어 ``ru`` 로 잡혔고,
    그 바람에 나머지 말이 전부 번역이 안 됐습니다. 하나를 고를 수 없으면
    비워 두고 플러그인이 알아서 하게 두는 편이 낫습니다.
    """
    code, why = runtime.guess_lang(
        ["Are you sure you want to quit the game right now",
         "Вы уверены что хотите выйти из игры прямо сейчас",
         "确定要退出游戏吗现在就退出吗真的要走吗真的吗"])
    # 비워 두면 플러그인이 일본어로 칩니다(기본값이 ja). 손 놓는 것이
    # 제일 나쁩니다 — 제일 많은 것을 고르되 섞였다고 알립니다.
    assert code and code != "ja"
    assert "섞여" in why


def test_guess_lang_admits_when_there_are_no_letters_at_all():
    assert runtime.guess_lang(["123 !!! ---"]) == ("", "")
    assert runtime.guess_lang([]) == ("", "")


def test_install_uses_the_language_it_read_not_japanese(game, zips):
    bep, xu = zips
    said = []
    runtime.install(game, bep, xu, proj(entry("退出游戏吗", "게임 종료"), src="auto"),
                    "ko", src_lang="auto", with_font=False, progress=said.append)
    got = (game / runtime.CONFIG).read_text("utf-8")
    assert "FromLanguage=zh-CN" in got
    assert "중국어" in "\n".join(said)


def test_stated_source_language_wins_over_guessing(game, zips):
    bep, xu = zips
    runtime.install(game, bep, xu, proj(entry("退出游戏吗", "게임 종료")), "ko",
                    src_lang="ja", with_font=False)
    assert "FromLanguage=ja" in (game / runtime.CONFIG).read_text("utf-8")


def test_patch_config_touches_only_the_three_keys():
    text = ("[Service]\nEndpoint=GoogleTranslateV2\nFallbackEndpoint=\n\n"
            "[General]\nLanguage=en\nFromLanguage=ja\n"
            "[Files]\nDirectory=Translation\\{Lang}\\Text\n")
    got = runtime.patch_config(text, "ja", "ko")
    assert got.splitlines() == [
        "[Service]", "Endpoint=", "FallbackEndpoint=", "",
        "[General]", "Language=ko", "FromLanguage=ja",
        "[Files]", "Directory=Translation\\{Lang}\\Text"]


def test_patch_config_adds_keys_that_were_missing():
    got = runtime.patch_config("[General]\nLanguage=en\n", "ja", "ko")
    assert "Language=ko" in got
    assert "Endpoint=" in got and "FromLanguage=ja" in got


def test_uninstall_without_install_says_so(game):
    assert runtime.uninstall(game) == 0


def test_restore_also_removes_what_we_installed(game, zips, monkeypatch):
    """'원래대로' 를 눌렀는데 남의 DLL 이 남아 있으면 원래대로가 아닙니다."""
    from gameloc import webui

    bep, xu = zips
    runtime.install(game, bep, xu, proj(entry("説明", "설명")), "ko")

    box = {}
    monkeypatch.setattr(webui.STATE, "game", game, raising=False)
    monkeypatch.setattr(webui.STATE, "start_job",
                        lambda _t, job: box.update(out=job(lambda _m: None)))
    webui.api_restore()
    assert box["out"]["runtime_removed"] > 0
    assert not (game / "BepInEx").exists()
    assert not runtime.installed(game)


# ── 폴더만 주면 알아서 찾기 ──────────────────────────────────────────────

def _folder(tmp_path, *names):
    d = tmp_path / "받은것"
    d.mkdir(exist_ok=True)
    for n in names:
        (d / n).write_bytes(b"PK\x03\x04")
    return d


IL2 = "BepInEx-Unity.IL2CPP-win-x64-6.0.0-be.785.zip"
MONO = "BepInEx-Unity.Mono-win-x64-6.0.0-be.785.zip"
XU_IL2 = "XUnity.AutoTranslator-BepInEx-IL2CPP-5.6.1.zip"
XU_MONO = "XUnity.AutoTranslator-BepInEx-5.6.1.zip"


def test_folder_is_enough(tmp_path):
    """사람에게 파일 이름을 치게 하면 안 됩니다."""
    d = _folder(tmp_path, IL2, XU_IL2)
    bep, xu, notes = runtime.find_zips(d, runtime.plan(info()))
    assert bep.name == IL2 and xu.name == XU_IL2 and not notes


def test_the_eleven_lookalikes_are_filtered_out(tmp_path):
    """XUnity 는 이름이 비슷한 것이 11개입니다."""
    d = _folder(tmp_path, IL2, XU_IL2,
                "XUnity.AutoTranslator-MelonMod-IL2CPP-5.6.1.zip",
                "XUnity.AutoTranslator-Developer-IL2CPP-5.6.1.zip",
                "XUnity.ResourceRedirector-BepInEx-IL2CPP-2.1.0.zip",
                "XUnity.AutoTranslator-IPA-5.6.1.zip")
    _bep, xu, _n = runtime.find_zips(d, runtime.plan(info()))
    assert xu.name == XU_IL2


def test_mono_build_for_an_il2cpp_game_is_explained(tmp_path):
    """넣어도 아무 일이 안 일어나는데, 이유를 모르면 영영 헤맵니다."""
    d = _folder(tmp_path, MONO, XU_MONO)
    bep, xu, notes = runtime.find_zips(d, runtime.plan(info(backend="IL2CPP")))
    assert bep is None and xu is None
    said = "\n".join(notes)
    assert said.startswith("이 게임은 IL2CPP 입니다.")
    assert "받아 두신 것은 Mono 용입니다" in said
    assert "Unity.IL2CPP" in said and "BepInEx-IL2CPP" in said


def test_il2cpp_build_for_a_mono_game_is_explained(tmp_path):
    d = _folder(tmp_path, IL2, XU_IL2)
    bep, xu, notes = runtime.find_zips(d, runtime.plan(info(backend="Mono")))
    assert bep is None and xu is None
    said = "\n".join(notes)
    assert said.startswith("이 게임은 Mono 입니다.")
    assert "Unity.Mono" in said


def test_mono_game_finds_the_mono_pair(tmp_path):
    d = _folder(tmp_path, MONO, XU_MONO)
    bep, xu, _n = runtime.find_zips(d, runtime.plan(info(backend="Mono")))
    assert bep.name == MONO and xu.name == XU_MONO


def test_a_single_zip_path_still_works(tmp_path):
    """폴더가 아니라 파일을 주셔도 받습니다."""
    d = _folder(tmp_path, IL2)
    bep, _xu, _n = runtime.find_zips(d / IL2, runtime.plan(info()))
    assert bep.name == IL2


def test_empty_folder_says_what_to_get(tmp_path):
    """아무것도 없으면 '없다' 가 아니라 '무엇을 받으라' 고 해야 합니다."""
    d = _folder(tmp_path)
    bep, xu, notes = runtime.find_zips(d, runtime.plan(info()))
    said = "\n".join(notes)
    assert bep is None and xu is None
    assert "이 게임은 IL2CPP 입니다." in said
    assert runtime.XUNITY_RELEASES in said
    assert "받아 두신 것은" not in said, "받은 게 없는데 받았다고 하면 안 됩니다"


def test_the_screen_asks_for_a_folder_not_a_file_name():
    """폴더를 넣어 '파일을 못 찾았다' 만 보게 됐습니다."""
    from gameloc import webui

    html = (Path(webui.__file__).parent / "web" / "index.html").read_text("utf-8")
    body = html.split("async function runtimeFlow", 1)[1].split("\n}", 1)[0]
    assert "bepinex:" not in body and "xunity:" not in body
    assert "folder:" in body


from pathlib import Path  # noqa: E402


def test_the_important_line_comes_first(tmp_path):
    """'이 게임은 Mono 입니다' 가 글 더미에 묻혀 안 보였습니다."""
    d = _folder(tmp_path, IL2, XU_IL2)
    _b, _x, notes = runtime.find_zips(d, runtime.plan(info(backend="Mono")))
    assert notes[0] == "이 게임은 Mono 입니다."
    assert len(notes) > 5, "여러 줄로 나뉘어야 읽힙니다"


def test_the_links_are_in_the_message(tmp_path):
    """어디서 받는지 다시 물어보게 만들면 안 됩니다."""
    d = _folder(tmp_path, IL2, XU_IL2)
    said = "\n".join(runtime.find_zips(d, runtime.plan(info(backend="Mono")))[2])
    assert runtime.BEPINEX_MONO in said
    assert runtime.XUNITY_RELEASES in said


def test_half_right_is_said_so(tmp_path):
    d = _folder(tmp_path, IL2, XU_MONO)
    _b, _x, notes = runtime.find_zips(d, runtime.plan(info(backend="IL2CPP")))
    assert any("하나는 맞습니다" in n for n in notes)


def test_errors_are_shown_in_a_readable_place():
    """여러 줄짜리 안내가 토스트에서는 한 줄로 뭉개집니다."""
    from gameloc import webui

    html = (Path(webui.__file__).parent / "web" / "index.html").read_text("utf-8")
    body = html.split("async function runtimeFlow", 1)[1].split("\n}\n", 1)[0]
    assert "toast(e.message" not in body.split("api('/api/runtime/install'", 1)[1]


def test_already_patched_game_is_not_told_to_undo(game, zips):
    """[게임에 적용] 과 덮어씌우기는 같이 써도 됩니다 — 오히려 같이 써야 합니다."""
    from gameloc.apply import BACKUP_DIR

    bep, xu = zips
    (game / BACKUP_DIR).mkdir()
    said = []
    runtime.install(game, bep, xu, proj(entry("説明", "설명")), "ko",
                    progress=said.append)
    joined = "\n".join(said)
    # 예전에는 여기서 [원래대로] 를 권했습니다. 그런데 그것을 누르면
    # 덮어씌우기까지 걷어냅니다 — 사용자를 제자리로 돌려보내는 안내였습니다.
    assert "[원래대로] 를 눌러" not in joined
    assert "번역표 1줄을 깔았습니다" in joined
    assert "[원래대로]" in joined


def test_no_such_warning_on_a_clean_game(game, zips):
    bep, xu = zips
    said = []
    runtime.install(game, bep, xu, proj(entry("説明", "설명")), "ko",
                    progress=said.append)
    assert "이미 [게임에 적용]" not in "\n".join(said)


# ── 화면에서 부르는 길 ────────────────────────────────────────────────────
#
# 여기를 아무 테스트도 지나지 않아서 NameError 를 그대로 내보냈습니다.
# 사용자가 [마지막 수단 넣기] 를 눌렀을 때 빈 창과 빨간 글씨만 봤습니다.

@pytest.fixture
def wired(game, zips, tmp_path, monkeypatch):
    from gameloc import webui

    bep, xu = zips
    where = tmp_path / "받은것"
    where.mkdir()
    # 이름이 이 게임(IL2CPP · 64비트)과 맞아야 골라집니다.
    (where / "BepInEx-Unity.IL2CPP-win-x64-6.0.0-be.785.zip").write_bytes(
        bep.read_bytes())
    (where / "XUnity.AutoTranslator-BepInEx-IL2CPP-5.6.1.zip").write_bytes(
        xu.read_bytes())

    box = {}
    monkeypatch.setattr(webui.STATE, "game", game, raising=False)
    monkeypatch.setattr(webui.STATE, "project",
                        proj(entry("退出游戏吗", "게임 종료"), src="auto"),
                        raising=False)
    monkeypatch.setattr(webui.STATE, "start_job",
                        lambda _t, job: box.update(out=job(box.setdefault(
                            "log", []).append)), raising=False)
    monkeypatch.setattr("gameloc.font.fix", lambda *_a, **_k: types.SimpleNamespace(
        patched=[], summary=lambda: "글꼴 없음"))
    monkeypatch.setattr(webui, "detect",
                        lambda _p: info(root=game), raising=False)
    monkeypatch.setattr("gameloc.detect.detect", lambda _p: info(root=game))
    return webui, box, str(where)


def test_install_from_the_screen_actually_runs(wired):
    """빈 창 대신 진짜 일이 일어나야 합니다."""
    webui, box, where = wired
    webui.api_runtime_install({"folder": where, "lang": "ko", "from": "zh-CN"})
    assert box["out"]["lines"] == 1
    cfg = (webui.STATE.game / runtime.CONFIG).read_text("utf-8")
    assert "FromLanguage=zh-CN" in cfg          # 화면에서 준 값이 그대로
    assert "Language=ko" in cfg and "Endpoint=\n" in cfg


def test_the_screen_gets_a_language_guess_to_show(wired):
    webui, _box, _where = wired
    j = webui.api_runtime_plan()
    assert j["from"] == "zh-CN"
    assert "중국어" in j["why"]


# ── 같이 넣어 배포하기 ────────────────────────────────────────────────────
#
# BepInEx 의 IL2CPP 판은 정식 릴리스가 아니라 빌드 서버의 번호별
# 빌드입니다. 그 주소는 새 빌드가 나오면 사라집니다. 그래서 자동으로
# 받아 오는 것보다, 시험해 본 그 빌드를 지고 다니는 편이 튼튼합니다.

def test_the_tested_pair_ships_with_us():
    bep, xu = runtime.bundled_for(runtime.plan(info(backend="IL2CPP")))
    assert bep and xu, "IL2CPP 64비트 짝이 같이 들어 있어야 합니다"
    assert "il2cpp" in bep.name.lower() and "x64" in bep.name.lower()
    assert "xunity" in xu.name.lower() and "il2cpp" in xu.name.lower()


def test_a_pair_we_do_not_carry_is_not_faked():
    """2.0.1 부터 Mono 판도 지고 다닙니다.

    2.0 에서는 여기가 ``assert not (bep and xu)`` 였습니다 — Mono 짝이
    없었으니까요. 이제는 있으므로 **제대로 된 것**이 오는지를 봅니다.
    있다고만 하고 엉뚱한 것을 주면 깔려도 게임이 안 켜집니다.
    """
    bep, xu = runtime.bundled_for(runtime.plan(info(backend="Mono")))
    assert bep and xu
    assert "il2cpp" not in bep.name.lower(), "Mono 게임에 IL2CPP 판을 줬습니다"
    assert "il2cpp" not in xu.name.lower(), "Mono 게임에 IL2CPP 판을 줬습니다"


def test_bundled_install_needs_no_folder(wired, monkeypatch):
    """받아 오라는 말을 아예 안 해야 합니다."""
    webui, box, _where = wired
    webui.api_runtime_install({"lang": "ko", "from": "zh-CN"})
    assert box["out"]["lines"] == 1
    assert "같이 들어 있는 것을 씁니다" in "\n".join(box["log"])


def test_the_screen_is_told_the_pair_is_already_here(wired):
    webui, _box, _where = wired
    assert webui.api_runtime_plan()["bundled"] is True


# ── Mono 짝을 같이 넣기 (2.0.1) ──────────────────────────────────────────
#
# 2.0 까지는 번들에 IL2CPP 짝만 있었습니다. Mono 게임(Fungus 로 만든
# 동인 게임이 대개 이쪽입니다)에서 [마지막 수단] 을 누르면 "직접 받아
# 오세요" 로 빠졌습니다.

def _bundled():
    from gameloc import runtime
    return runtime.BUNDLED


def test_the_bundle_now_carries_a_mono_pair_too():
    from gameloc import runtime

    names = [p.name.lower() for p in _bundled().glob("*.zip")]
    assert any("bepinex_win_x64" in n for n in names), "Mono 64비트 BepInEx 가 없습니다"
    assert any("xunity" in n and "il2cpp" not in n for n in names), \
        "Mono 판 XUnity 가 없습니다"
    assert any("il2cpp" in n for n in names), "IL2CPP 짝이 사라졌습니다"


@pytest.mark.parametrize("backend,bits,want_bep,want_xu", [
    ("Mono", 64, "bepinex_win_x64", "xunity.autotranslator-bepinex-5"),
    ("Mono", 32, "bepinex_win_x86", "xunity.autotranslator-bepinex-5"),
    ("IL2CPP", 64, "il2cpp", "il2cpp"),
])
def test_each_kind_of_game_gets_its_own_pair(backend, bits, want_bep, want_xu):
    from gameloc import runtime

    need = runtime.Need(backend=backend, unity="2021.3.0f1", bits=bits)
    bep, xu, notes = runtime.find_zips(_bundled(), need)
    assert bep and want_bep in bep.name.lower(), f"{backend} x{bits}: {bep}"
    assert xu and want_xu in xu.name.lower(), f"{backend} x{bits}: {xu}"
    assert notes == [], f"맞는 짝을 찾고도 잔소리를 합니다: {notes}"


def test_thirty_two_bit_is_spelled_x86_not_x32():
    """**이것 때문에 32비트 게임에 64비트 판을 골라 줬습니다.**

    예전 코드는 ``f"x{need.bits}"`` 로 찾았습니다. 64비트는 ``x64`` 라서
    우연히 맞았고, 32비트는 ``x32`` 를 찾는데 세상에 그런 이름이 없습니다.
    그래서 아무거나(대개 x64) 골라 줬고, 깔려도 게임이 그냥 안 켜집니다.
    """
    from gameloc import runtime

    assert runtime._bits_in("bepinex_win_x86_5.4.23.3.zip") == 32
    assert runtime._bits_in("bepinex_win_x64_5.4.23.3.zip") == 64
    assert runtime._bits_in("bepinex-unity.il2cpp-win-x64-6.0.0.zip") == 64
    assert runtime._bits_in("xunity.autotranslator-bepinex-5.6.1.zip") == 0


def test_only_the_wrong_bits_present_says_which_to_get(tmp_path):
    """폴더에 파일이 뻔히 보이는데 '없다' 고만 하면 영영 헤맵니다."""
    from gameloc import runtime

    (tmp_path / "BepInEx_win_x86_5.4.23.3.zip").write_bytes(b"PK\x03\x04")
    (tmp_path / "XUnity.AutoTranslator-BepInEx-5.6.1.zip").write_bytes(b"PK\x03\x04")
    need = runtime.Need(backend="Mono", unity="2021.3.0f1", bits=64)
    bep, _xu, notes = runtime.find_zips(tmp_path, need)
    assert bep is None
    said = " ".join(notes)
    assert "32비트" in said and "64비트" in said and "win_x64" in said


def test_a_mono_game_no_longer_needs_a_download():
    """이 시험이 깨지면 Mono 게임 사용자가 다시 깃허브로 보내집니다."""
    from gameloc import runtime

    need = runtime.Need(backend="Mono", unity="6000.3.18f1", bits=64)
    bep, xu = runtime.bundled_for(need)
    assert bep is not None and xu is not None
