"""스크립트 안의 따옴표 문자열은 값이지 대사가 아닙니다.

이 게임들은 진행 상태를 일본어 낱말로 저장하고 그걸 비교합니다:

    $gameVariables.setValue(255, '達成')
    if ($gameVariables.value(255) === '達成')

이걸 번역해 넣으면 **게임이 죽지 않습니다.** 대신 조건이 영영 안 맞아서
이벤트가 조용히 멈춥니다. 죽는 것보다 찾기 어려운 고장입니다.
"""

from __future__ import annotations

import json
from pathlib import Path

from gameloc import apply as apply_mod
from gameloc import extract as extract_mod
from gameloc.engines import rpgmaker


def make_game(tmp_path: Path) -> Path:
    root = tmp_path / "Game"
    data, js = root / "data", root / "js"
    data.mkdir(parents=True)
    js.mkdir()
    (js / "plugins.js").write_text("var $plugins =\n[\n];\n", "utf-8")

    (data / "System.json").write_text(json.dumps({
        "gameTitle": "テスト", "switches": ["", "スイッチ1"],
        "variables": ["", "変数1"], "terms": {"messages": {}},
    }, ensure_ascii=False), "utf-8")

    (data / "CommonEvents.json").write_text(json.dumps([None, {
        "id": 1, "name": "進行", "list": [
            # 대사 — 번역돼야 합니다
            {"code": 401, "parameters": ["おはよう。"]},
            # 변수에 상태값을 넣는 스크립트 — 번역되면 안 됩니다
            {"code": 355, "parameters": ["$gameVariables.setValue(255, '達成');"]},
            {"code": 655, "parameters": ["$gameVariables.setValue(301, \"未経験\");"]},
            # 조건 분기(스크립트) — 비교값도 번역되면 안 됩니다
            {"code": 111, "parameters": [
                12, "$gameVariables.value(255) === '達成'"]},
            {"code": 401, "parameters": ["条件を満たした。"]},
            {"code": 412, "parameters": []},
            # 변수 조작(스크립트)
            {"code": 122, "parameters": [82, 82, 0, 4, "'海の家2マップ'"]},
            {"code": 0, "parameters": []},
        ],
    }], ensure_ascii=False), "utf-8")
    return root


LOGIC = {"達成", "未経験", "海の家2マップ"}


def test_script_literals_are_pulled_out():
    got = rpgmaker.script_literals("$gameVariables.setValue(255, '達成');")
    assert got == {"達成"}
    assert rpgmaker.script_literals('a("x") + b(\'y\') + `z`') == {"x", "y", "z"}
    assert rpgmaker.script_literals("say('It\\'s me')") == {"It's me"}
    assert rpgmaker.script_literals("noStringsHere(1, 2)") == set()


def test_script_texts_picks_the_right_parameter():
    assert rpgmaker.script_texts({"code": 355, "parameters": ["a()"]}) == ["a()"]
    assert rpgmaker.script_texts({"code": 655, "parameters": ["b()"]}) == ["b()"]
    # 조건 분기는 0번 인자가 12 일 때만 스크립트입니다
    assert rpgmaker.script_texts({"code": 111, "parameters": [12, "c()"]}) == ["c()"]
    assert rpgmaker.script_texts({"code": 111, "parameters": [0, 1, 0]}) == []
    # 변수 조작은 3번 인자가 4 일 때만
    assert rpgmaker.script_texts(
        {"code": 122, "parameters": [1, 1, 0, 4, "d()"]}) == ["d()"]
    assert rpgmaker.script_texts(
        {"code": 122, "parameters": [1, 1, 0, 0, 5]}) == []


def test_logic_values_are_indexed(tmp_path):
    root = make_game(tmp_path)
    ids = rpgmaker.collect_identifiers(root)
    assert LOGIC <= ids


def test_logic_values_never_reach_the_translator(tmp_path):
    root = make_game(tmp_path)
    proj = extract_mod.extract(root)
    texts = {e.text for e in proj.entries}

    assert "おはよう。" in texts                     # 대사는 나오고
    assert "条件を満たした。" in texts
    assert not (LOGIC & texts), f"값이 목록에 섞였습니다: {LOGIC & texts}"
    assert LOGIC <= set(proj.identifiers)


def test_old_project_with_logic_values_is_still_blocked(tmp_path):
    """예전 버전으로 뽑아 둔 목록에 값이 섞여 있어도 적용 때 막습니다."""
    root = make_game(tmp_path)
    proj = extract_mod.extract(root)
    proj.identifiers = []                            # 예전 목록에는 없었다고 치고

    from gameloc.model import Entry, Location
    proj.entries.append(Entry(
        id="x", text="達成",
        locations=[Location(file="data/CommonEvents.json", kind="loose",
                            fmt="json", ptr="[1].list[1].parameters[0]")],
        translations={"ko": "달성"}))
    for e in proj.entries:
        e.translations.setdefault("ko", "[한] " + e.text)

    rep = apply_mod.apply(proj, "ko")
    assert any("達成" in r for r in rep.risky), rep.risky

    doc = json.loads((root / "data" / "CommonEvents.json").read_text("utf-8"))
    body = json.dumps(doc, ensure_ascii=False)
    for value in LOGIC:
        assert value in body, f"{value} 가 게임 파일에서 바뀌었습니다"
    assert "[한] おはよう。" in body                  # 대사는 정상 적용


# --------------------------------------------------------------------------
# 실제로 겪은 고장: 선택지 글자를 그대로 비교하는 플러그인
# --------------------------------------------------------------------------
def make_choice_game(tmp_path: Path) -> Path:
    """플러그인이 '마지막에 고른 선택지 글자' 를 기억했다가 비교하는 게임.

        선택지:  「はい」 「いいえ」
        스크립트: if (PLUGIN.getLastClickedChoice() === 'はい') ...

    선택지만 번역하면 화면에는 「예」가 뜨고 플러그인은 '예' 를 기억하는데,
    비교는 여전히 'はい' 라서 **영영 안 맞습니다.** 게임은 안 죽고, 그냥
    그 이벤트에서 멈춥니다.
    """
    root = make_game(tmp_path)
    (root / "data" / "Map001.json").write_text(json.dumps({
        "events": [None, {"id": 1, "name": "ドア", "pages": [{"list": [
            {"code": 401, "parameters": ["中に入る？"]},
            {"code": 102, "parameters": [["はい", "いいえ"], 1, 0, 2, 0]},
            {"code": 355, "parameters": ["PLUGIN.resetLastClickedChoice();"]},
            {"code": 111, "parameters": [
                12, "PLUGIN.getLastClickedChoice() === 'はい'"]},
            {"code": 401, "parameters": ["ドアが開いた。"]},
            {"code": 412, "parameters": []},
            {"code": 0, "parameters": []},
        ]}]},
        ]}, ensure_ascii=False), "utf-8")
    return root


def test_choice_compared_by_text_is_left_alone(tmp_path):
    root = make_choice_game(tmp_path)
    proj = extract_mod.extract(root)
    texts = {e.text for e in proj.entries}

    assert "中に入る？" in texts                      # 대사는 번역 대상
    assert "ドアが開いた。" in texts
    assert "はい" not in texts, "스크립트가 글자 그대로 비교하는 선택지입니다"
    assert "いいえ" in texts, "비교에 안 쓰이는 선택지는 그대로 번역합니다"


def test_the_event_still_advances_after_applying(tmp_path):
    """번역을 넣은 뒤에도 비교 양쪽이 여전히 같은 글자여야 합니다."""
    root = make_choice_game(tmp_path)
    proj = extract_mod.extract(root)
    for e in proj.entries:
        e.translations["ko"] = "[한] " + e.text
    apply_mod.apply(proj, "ko")

    doc = json.loads((root / "data" / "Map001.json").read_text("utf-8"))
    page = doc["events"][1]["pages"][0]["list"]
    choices = page[1]["parameters"][0]
    script = page[3]["parameters"][1]

    assert choices[0] == "はい", "비교에 쓰이는 선택지가 바뀌었습니다"
    assert "'はい'" in script
    assert choices[0] in script, "선택지와 비교값이 여전히 같은 글자"
    assert page[0]["parameters"][0].startswith("[한] ")   # 대사는 번역됨


# --------------------------------------------------------------------------
# 비교문이 data 가 아니라 플러그인 소스에 들어 있는 경우
# --------------------------------------------------------------------------
def make_plugin_source_game(tmp_path: Path) -> Path:
    root = make_game(tmp_path)
    plugdir = root / "js" / "plugins"
    plugdir.mkdir(parents=True)
    (plugdir / "TimeMode.js").write_text('''\
//=============================================================================
// TimeMode.js
//=============================================================================
(function() {
    const MODE = { "日中": 0, "夕方": 1, "夜間": 2 };

    Game_System.prototype.applyTimeMode = function(label) {
        if (label === '日中') { this._bright = true; }
        return MODE[label];
    };
    // 영어는 대사와 겹칠 일이 없으니 그냥 둡니다
    Game_System.prototype.mode = function() { return "default"; };
})();
''', "utf-8")

    (root / "data" / "Map002.json").write_text(json.dumps({
        "events": [None, {"id": 1, "name": "時計", "pages": [{"list": [
            {"code": 401, "parameters": ["今は昼だ。"]},
            {"code": 102, "parameters": [["日中", "夕方", "夜間"], 1, 0, 2, 0]},
            {"code": 0, "parameters": []},
        ]}]},
        ]}, ensure_ascii=False), "utf-8")
    return root


def test_literals_from_plugin_source_are_protected(tmp_path):
    root = make_plugin_source_game(tmp_path)
    proj = extract_mod.extract(root)
    texts = {e.text for e in proj.entries}

    assert "今は昼だ。" in texts                       # 대사는 번역
    for value in ("日中", "夕方", "夜間"):
        assert value not in texts, f"{value} 는 플러그인이 글자로 비교합니다"
    assert "default" not in proj.identifiers, "영어 문자열까지 막지는 않습니다"


def test_opting_into_js_translation_unlocks_them(tmp_path):
    """'플러그인 js 파일까지' 를 켠 사용자는 직접 번역하겠다는 뜻입니다."""
    root = make_plugin_source_game(tmp_path)
    proj = extract_mod.extract(root, include_js=True)
    texts = {e.text for e in proj.entries}
    assert "日中" in texts

    for e in proj.entries:
        e.translations["ko"] = {"日中": "낮", "夕方": "저녁", "夜間": "밤"}.get(
            e.text, "[한] " + e.text)
    rep = apply_mod.apply(proj, "ko")

    js = (root / "js" / "plugins" / "TimeMode.js").read_text("utf-8")
    assert '"낮"' in js and "'낮'" in js, "양쪽 다 바뀌어야 짝이 맞습니다"
    doc = json.loads((root / "data" / "Map002.json").read_text("utf-8"))
    assert doc["events"][1]["pages"][0]["list"][1]["parameters"][0][0] == "낮"
    assert not rep.failures
