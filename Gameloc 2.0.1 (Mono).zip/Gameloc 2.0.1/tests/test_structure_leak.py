"""설정 파일의 **구조**가 번역 대상이 되면 안 됩니다.

실제로 겪은 사고: 유니티 TextAsset 에 든 JSON 이 살짝 어긋나 있어서 파서가
줄 단위로 떨어뜨렸고, 그 결과 목록에 이런 게 올라왔습니다:

    "バージョン": {

번역기가 이걸 ``"버전": {`` 으로 바꿔 놓으면 게임은 ``バージョン`` 키를 영영
못 찾습니다. 게임이 죽지도 않아서 원인을 찾기 어렵습니다.
"""

from __future__ import annotations

import json

import pytest

from gameloc import containers, heuristics

BROKEN_JSON = """\
{
  // 주석이 있어 표준 JSON 으로는 안 읽힙니다
  "バージョン": {
    "major": 1,
    "説明": "はじまりの物語",
  },
  "アイテム": [
    "薬草",
  ],
}
"""

GOOD_JSON = json.dumps(
    {"バージョン": {"説明": "はじまりの物語"}, "アイテム": ["薬草"]},
    ensure_ascii=False, indent=2)


# ------------------------------------------------------------- 형식 판별

def test_broken_json_is_left_alone():
    fmt = containers.sniff(BROKEN_JSON, "nv-constants")
    assert fmt == "opaque", "줄 단위로 쪼개면 구조가 번역됩니다"
    assert list(containers.explode(BROKEN_JSON, fmt, "nv-constants")) == []
    assert containers.implode(BROKEN_JSON, fmt, {}, "nv-constants") == BROKEN_JSON


def test_good_json_still_gives_values_only():
    fmt = containers.sniff(GOOD_JSON, "nv-constants")
    assert fmt == "json"
    got = [v for _p, v in containers.explode(GOOD_JSON, fmt, "nv-constants")]
    assert got == ["はじまりの物語", "薬草"], "값만 나와야 합니다"
    assert not any(":" in v for v in got)


def test_json_file_extension_that_fails_to_parse():
    assert containers.sniff("{ 이건 JSON 이 아님", "config.json") == "opaque"


def test_plain_text_still_goes_line_by_line():
    text = "こんにちは。\nさようなら。\n"
    assert containers.sniff(text, "dialogue.txt") == "lines"


# ------------------------------------------------------------- 점수

@pytest.mark.parametrize("line", [
    '"バージョン": {',
    '  "アイテム": [',
    '},',
    '  }',
    '[',
    '"説明": "はじまりの物語",',
    "'名前': {",
    "</div>",
])
def test_structure_lines_score_zero(line):
    assert heuristics.score(line) == 0.0, f"{line!r} 이 번역 대상이 되었습니다"


@pytest.mark.parametrize("line", [
    "はじまりの物語",
    "こんにちは、世界。",
    "「引用符」も大丈夫。",
    "Start Game",
    "彼は言った：「行こう」",
])
def test_real_dialogue_still_scores(line):
    assert heuristics.score(line) >= 0.45, f"{line!r} 이 걸러졌습니다"


def test_line_mode_file_full_of_structure_yields_nothing_useful():
    """혹시 줄 모드로 떨어지더라도 구조는 안 잡힙니다."""
    text = BROKEN_JSON.replace("{", "").replace("}", "")   # 앞글자를 없애 줄 모드로
    fmt = containers.sniff(text, "weird.txt")
    assert fmt == "lines"
    kept = [v for _p, v in containers.explode(text, fmt, "weird.txt")
            if heuristics.score(v) >= 0.45]
    assert all(":" not in v or v.strip().startswith("//") is False for v in kept)
    for junk in ('"バージョン": ', '"アイテム": ['):
        assert junk not in kept
