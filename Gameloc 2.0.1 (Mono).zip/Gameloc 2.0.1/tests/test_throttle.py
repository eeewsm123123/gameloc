# SPDX-License-Identifier: GPL-3.0-or-later
"""번역 서버가 '너무 빨리 부른다' 며 막을 때 (HTTP 429)."""

import json
import threading
import types
import urllib.error

import pytest

from gameloc import translate as T
from gameloc import throttle


def busy(code=429, retry_after=None):
    hdrs = {}
    if retry_after is not None:
        hdrs["Retry-After"] = str(retry_after)
    return urllib.error.HTTPError("u", code, "Too Many Requests",
                                  types.SimpleNamespace(get=hdrs.get), None)


# ── 무엇이 '기다릴 오류' 인가 ──────────────────────────────────────────────

def test_429_is_a_wait():
    assert throttle.busy_for(busy()) == 0.0
    assert throttle.is_busy(busy())


def test_server_can_say_how_long():
    assert throttle.busy_for(busy(retry_after=30)) == 30.0


@pytest.mark.parametrize("code", [500, 502, 503, 504, 529])
def test_server_hiccups_are_also_waits(code):
    assert throttle.is_busy(busy(code))


@pytest.mark.parametrize("code", [400, 401, 403, 404])
def test_wrong_key_is_not_a_wait(code):
    """키가 틀린 것은 기다린다고 나아지지 않습니다. 바로 알려야 합니다."""
    assert throttle.busy_for(busy(code)) is None


def test_ordinary_errors_are_not_waits():
    assert throttle.busy_for(ValueError("x")) is None
    assert throttle.busy_for(TimeoutError()) is None


def test_zero_seconds_is_still_a_wait():
    """'막혔지만 몇 초인지 안 알려줬다' 를 '안 막혔다' 로 보면 안 됩니다."""
    assert throttle.busy_for(busy()) is not None


# ── 브레이크 ─────────────────────────────────────────────────────────────

def test_waiting_gets_longer_each_time():
    b = throttle.Brake(scale=1.0)
    got = [b.hit() for _ in range(6)]
    assert got == [5, 15, 40, 90, 180, 180]


def test_server_wish_wins_when_longer():
    b = throttle.Brake(scale=1.0)
    assert b.hit(said=60) == 60          # 5초보다 길면 그 말을 따릅니다


def test_gap_grows_and_shrinks():
    b = throttle.Brake(scale=0)
    b.hit(); assert b.gap == throttle.GAP_FIRST
    b.hit(); assert b.gap == throttle.GAP_FIRST * 2
    for _ in range(throttle.EASE_AFTER):
        b.eased()
    assert b.gap == throttle.GAP_FIRST


def test_everyone_stops_together():
    """한 갈래가 막히면 나머지도 섭니다. 막힌 문을 더 두드리면 안 됩니다."""
    b = throttle.Brake(scale=0.01)
    b.hit()
    started = threading.Event()
    done = threading.Event()

    def other():
        started.set()
        b.wait()
        done.set()

    t = threading.Thread(target=other, daemon=True)
    t.start()
    started.wait(1)
    assert not done.is_set(), "다른 갈래가 안 멈췄습니다"
    assert done.wait(5), "쉬는 시간이 지났는데 안 갑니다"


def test_stop_button_breaks_the_wait():
    b = throttle.Brake(scale=1.0)
    b.hit()                               # 5초 대기
    b.wait(should_stop=lambda: True)      # 즉시 돌아와야 합니다


# ── 실제 번역 흐름 ───────────────────────────────────────────────────────

class Entry:
    def __init__(self, text):
        self.text = text
        self.translations = {}
        self.machine = []


class Flaky(T.Provider):
    """처음 몇 번은 429 를 뱉고 그 뒤로는 제대로 답하는 서버."""

    label = "테스트"
    batch_size = 1
    workers = 1
    retry_delay = 0
    wait_scale = 0                        # 검사에서는 실제로 안 기다립니다

    def __init__(self, fails):
        super().__init__()
        self.left = fails
        self.calls = 0

    def _translate(self, texts, src, dst):
        self.calls += 1
        if self.left > 0:
            self.left -= 1
            raise busy()
        return ["번역:" + t for t in texts]


def test_recovers_after_being_blocked():
    """막혔다고 번역이 통째로 날아가면 안 됩니다."""
    entries = [Entry("あ"), Entry("い"), Entry("う")]
    rep = T.translate_entries(entries, Flaky(fails=3), dst="ko")
    assert rep.done == 3, rep.problems
    assert rep.failed == 0
    assert rep.throttled == 3
    assert all(e.translations["ko"].startswith("번역:") for e in entries)


def test_summary_mentions_the_waiting():
    entries = [Entry("あ")]
    rep = T.translate_entries(entries, Flaky(fails=2), dst="ko")
    assert "막아" in rep.summary()


def test_gives_up_politely_when_it_never_clears():
    entries = [Entry("あ")]
    rep = T.translate_entries(entries, Flaky(fails=999), dst="ko")
    assert rep.done == 0 and rep.failed == 1
    assert "조금 뒤에 다시" in rep.problems[0]
    assert "429" not in rep.problems[0], "사람이 읽을 말이어야 합니다"


def test_tries_many_more_times_than_before():
    """전에는 세 번 만에 포기했습니다. 그래서 통째로 실패했습니다."""
    p = Flaky(fails=999)
    T.translate_entries([Entry("あ")], p, dst="ko")
    assert p.calls > 3


class Broken(T.Provider):
    label = "테스트"
    batch_size = 1
    workers = 1
    retry_delay = 0
    wait_scale = 0

    def __init__(self, exc):
        super().__init__()
        self.exc = exc
        self.calls = 0

    def _translate(self, texts, src, dst):
        self.calls += 1
        raise self.exc


def test_wrong_key_does_not_retry_forever():
    """키가 틀렸으면 오래 붙들지 말고 바로 알려야 합니다."""
    p = Broken(busy(401))
    rep = T.translate_entries([Entry("あ")], p, dst="ko")
    assert p.calls == 3
    assert "API 키" in rep.problems[0]


def test_stop_button_works_while_blocked():
    p = Flaky(fails=999)
    rep = T.translate_entries([Entry("あ")], p, dst="ko",
                              should_stop=lambda: p.calls >= 2)
    assert p.calls <= 3
    assert rep.done == 0


# ── 새로 붙인 번역기들 ───────────────────────────────────────────────────

@pytest.fixture
def caught(monkeypatch):
    """실제로 부르지 않고, 어디로 무엇을 보내려 했는지만 봅니다."""
    box = {}

    def fake(url, data, headers, timeout=60):
        box.update(url=url, data=data, headers=headers)
        if "openai" in url:
            return b'{"choices":[{"message":{"content":"[\\"\\uac00\\"]"}}]}'
        if "generativelanguage" in url:
            return (b'{"candidates":[{"content":{"parts":'
                    b'[{"text":"[\\"\\uac00\\"]"}]}}]}')
        return b'{"message":{"result":{"translatedText":"\\uac00"}}}'

    monkeypatch.setattr(T, "_post", fake)
    return box


@pytest.mark.parametrize("pid,key,host,header", [
    ("openai", "sk-x", "api.openai.com", "Authorization"),
    ("gemini", "AIza-x", "generativelanguage.googleapis.com", "x-goog-api-key"),
    ("papago", "ID:SECRET", "naveropenapi.apigw.ntruss.com",
     "X-NCP-APIGW-API-KEY-ID"),
])
def test_new_engines_send_the_key_the_right_way(caught, pid, key, host, header):
    out = T.make_provider(pid, key)._translate(["あ"], "ja", "ko")
    assert out == ["가"]
    assert host in caught["url"]
    assert header in caught["headers"]


def test_every_engine_is_offered_in_the_list():
    ids = {p["id"] for p in T.provider_list()}
    assert {"google", "deepl", "claude", "openai", "gemini", "papago"} <= ids


def test_papago_needs_two_keys():
    with pytest.raises(RuntimeError, match="쌍점"):
        T.make_provider("papago", "키하나만")


def test_papago_refuses_languages_it_does_not_know(caught):
    """부르기 전에 막아야 합니다. 보내 봐야 400 만 돌아옵니다."""
    with pytest.raises(RuntimeError, match="모릅니다"):
        T.make_provider("papago", "A:B")._translate(["x"], "auto", "ko")
    assert not caught, "부르지 말았어야 합니다"


def test_papago_understands_common_language_spellings():
    p = T.make_provider("papago", "A:B")
    assert p._lang("zh") == "zh-CN"
    assert p._lang("jp") == "ja"


def test_llm_engines_get_the_glossary(caught):
    class E:
        def __init__(self, t):
            self.text, self.translations, self.machine = t, {}, []

    p = T.make_provider("gemini", "k")
    p.wait_scale = 0
    T.translate_entries([E("あ")], p, dst="ko", glossary={"魔王": "마왕"})
    body = json.loads(caught["data"])
    assert "마왕" in body["systemInstruction"]["parts"][0]["text"]


# ── 모델 이름이 죽었을 때 (실제로 겪은 사고) ─────────────────────────────

def test_dead_model_is_explained_not_dumped():
    """gemini-2.0-flash 가 종료되자 사용자는 'HTTP Error 404' 만 봤습니다."""
    why = T._why(busy(404))
    assert "404" not in why
    assert "모델" in why


def test_gemini_asks_the_key_which_models_it_can_use(monkeypatch):
    """이름을 코드에 박아 두면 언젠가 반드시 죽습니다."""
    g = T.make_provider("gemini", "k")
    monkeypatch.setattr(g, "available",
                        lambda: ["models-x", "gemini-9.9-flash", "gemini-9.9-pro"])
    assert g._model() == "gemini-9.9-flash"


def test_gemini_falls_back_when_it_cannot_ask(monkeypatch):
    g = T.make_provider("gemini", "k")
    monkeypatch.setattr(g, "available", lambda: [])
    assert g._model() == T.GeminiAPI.KNOWN[0]


def test_gemini_honours_a_model_the_user_typed(monkeypatch):
    g = T.make_provider("gemini", "k", "내가고른모델")
    monkeypatch.setattr(g, "available", lambda: ["gemini-9.9-flash"])
    assert g._model() == "내가고른모델"


def test_gemini_skips_image_and_preview_models(monkeypatch):
    g = T.make_provider("gemini", "k")
    monkeypatch.setattr(g, "available",
                        lambda: ["gemini-9-flash-image", "gemini-9-flash-preview",
                                 "gemini-9-flash"])
    assert g._model() == "gemini-9-flash"


# ── 구글 무료를 처음부터 천천히 ─────────────────────────────────────────

def test_google_free_eases_in_but_keeps_its_old_speed():
    """살살 시작하되 **원래 속도를 잃으면 안 됩니다.**

    틈을 고정했다가 10만 문장짜리 게임이 2.8시간에서 9.7시간이 될
    뻔했습니다. 일꾼 수는 1.2.0 부터 10만 문장을 넘긴 값입니다.
    """
    g = T.make_provider("google")
    assert 0 < g.start_gap <= 0.25
    assert g.workers == 3


def test_brake_starts_at_the_given_gap():
    b = throttle.Brake(scale=0, gap=0.4)
    assert b.gap == 0.4


def test_easing_goes_all_the_way_back_to_full_speed():
    """서버가 괜찮다는데 우리가 굳이 기다릴 이유가 없습니다.

    이 틈을 붙들고 있으면 큰 게임이 몇 시간씩 더 걸립니다.
    """
    b = throttle.Brake(scale=0, gap=0.2)
    for _ in range(throttle.EASE_AFTER):
        b.eased()
    assert b.gap == 0.0

    b.hit()
    assert b.gap > 0
    for _ in range(throttle.EASE_AFTER * 6):
        b.eased()
    assert b.gap == 0.0, "막힌 뒤에도 결국 제 속도로 돌아와야 합니다"


def test_the_waiting_message_does_not_read_like_a_failure():
    """'막았습니다' 는 사고처럼 읽혀 버그로 신고가 들어왔습니다."""
    msgs = []
    T.translate_entries([Entry("あ")], Flaky(fails=1), dst="ko",
                        progress=msgs.append)
    said = "\n".join(msgs)
    assert "쉬어 갑니다" in said
    assert "그대로 두시면" in said


# ── 구글에 묶어 보내기 ───────────────────────────────────────────────────

def _google(monkeypatch, replies):
    """구글 대신 대답하는 가짜. 부른 횟수와 보낸 것을 기록합니다."""
    calls = []

    def fake(url, timeout=30):
        import urllib.parse as up
        qs = up.parse_qs(up.urlparse(url).query)
        sent = qs.get("q", [])
        calls.append(sent)
        return json.dumps(replies(sent)).encode("utf-8")

    monkeypatch.setattr(T, "_get", fake)
    return calls


def one_each(sent):
    """정상 응답 — 보낸 개수만큼 돌려줍니다."""
    return [[[["ko:" + t, t, None, None, 10]]] for t in sent]


def test_many_sentences_go_in_one_call(monkeypatch):
    """3,295번 부르던 것을 165번으로 줄이는 것이 요점입니다."""
    calls = _google(monkeypatch, one_each)
    out = T.make_provider("google")._translate(["A", "B", "C"], "ja", "ko")
    assert out == ["ko:A", "ko:B", "ko:C"]
    assert len(calls) == 1, "묶어서 한 번에 보내야 합니다"


def test_a_single_sentence_still_works(monkeypatch):
    _google(monkeypatch, lambda sent: [[["ko:" + sent[0], sent[0]]]])
    assert T.make_provider("google")._translate(["A"], "ja", "ko") == ["ko:A"]


def test_wrong_count_falls_back_to_one_at_a_time(monkeypatch):
    """짝이 어긋난 번역을 넣느니 느린 편이 낫습니다."""
    def merged(sent):
        # 구글이 세 문장을 하나로 합쳐 돌려준 상황
        if len(sent) > 1:
            return [[["합쳐짐", "".join(sent)]]]
        return [[["ko:" + sent[0], sent[0]]]]

    calls = _google(monkeypatch, merged)
    g = T.make_provider("google")
    out = g._translate(["A", "B", "C"], "ja", "ko")
    assert out == ["ko:A", "ko:B", "ko:C"], "어긋나면 하나씩 다시 보내야 합니다"
    assert len(calls) == 4          # 묶어서 한 번 + 하나씩 세 번
    assert g.batched is False


def test_never_returns_a_mismatched_pairing(monkeypatch):
    """이게 이 기능에서 제일 위험한 지점입니다."""
    def shuffled(sent):
        if len(sent) > 1:
            # 두 개만 돌려줍니다 — 그대로 쓰면 짝이 밀립니다
            return [[["ko:" + sent[0], sent[0]]]], [[["ko:" + sent[1], sent[1]]]]
        return [[["ko:" + sent[0], sent[0]]]]

    _google(monkeypatch, lambda s: list(shuffled(s)))
    out = T.make_provider("google")._translate(["A", "B", "C"], "ja", "ko")
    assert out == ["ko:A", "ko:B", "ko:C"]


def test_batching_cuts_the_number_of_calls_a_lot(monkeypatch):
    calls = _google(monkeypatch, one_each)

    class E:
        def __init__(s, t):
            s.text, s.translations, s.machine = t, {}, []

    p = T.make_provider("google")
    p.wait_scale = 0
    rep = T.translate_entries([E(f"문장{i}") for i in range(200)], p, dst="ko")
    assert rep.done == 200
    assert len(calls) <= 200 // 10, f"호출이 {len(calls)}번이나 됩니다"


def test_empty_result_means_we_misread_the_shape(monkeypatch):
    """개수만 맞고 내용을 잘못 읽으면 빈 칸이 나옵니다.

    응답 모양을 짐작해서 읽는 것이라, 이 그물이 없으면 빈 번역이
    조용히 들어갑니다.
    """
    def blanks(sent):
        if len(sent) > 1:
            return [[[["", t]]] for t in sent]      # 개수는 맞지만 다 빈 칸
        return [[["ko:" + sent[0], sent[0]]]]

    calls = _google(monkeypatch, blanks)
    out = T.make_provider("google")._translate(["A", "B"], "ja", "ko")
    assert out == ["ko:A", "ko:B"]
    assert len(calls) == 3          # 묶어서 한 번 + 하나씩 두 번


# ── 속도 세 단계 ─────────────────────────────────────────────────────────
#
# 왜 고르게 하는가 — IP 사정이 사람마다 다릅니다. 공유기·회사망·VPN 을
# 쓰면 남이 이미 써 버린 몫까지 같이 걸립니다.

def test_the_three_speeds_are_ordered_and_named():
    from gameloc import throttle

    gaps = [throttle.SPEEDS[k]["gap"] for k in ("safe", "normal", "fast")]
    assert gaps == sorted(gaps, reverse=True), "안전할수록 틈이 커야 합니다"
    for k in ("safe", "normal", "fast"):
        s = throttle.SPEEDS[k]
        assert s["label"] and s["why"] and s["workers"] >= 1


def test_an_unknown_speed_falls_back_to_normal():
    from gameloc import throttle

    for junk in ("", "  ", "turbo", None):
        assert throttle.speed_of(junk) is throttle.SPEEDS["normal"]


def test_fast_is_not_much_faster_than_normal():
    """이 사실이 화면에 보여야 사람이 '빠르게' 를 함부로 안 고릅니다."""
    from gameloc import throttle

    n = throttle.guess_seconds(3295, 20, "normal")
    f = throttle.guess_seconds(3295, 20, "fast")
    s = throttle.guess_seconds(3295, 20, "safe")
    assert s > n > f > 0
    assert f > n / 2, "빠르게가 보통의 두 배 넘게 빠르면 안 됩니다 — 그건 거짓말입니다"
    # 3,295문장에서 '빠르게' 가 아끼는 것은 15초 남짓입니다. 막힘은
    # 5초·15초·40초… 로 커지니 **두 번만 막혀도 아낀 것이 사라집니다.**
    assert (n - f) < throttle.WAITS[0] + throttle.WAITS[1]


def test_the_guess_is_zero_when_there_is_nothing_to_do():
    from gameloc import throttle

    assert throttle.guess_seconds(0, 20, "fast") == 0.0
    assert throttle.guess_seconds(10, 0, "fast") == 0.0


# ── 스스로 한 단계 내려가기 ──────────────────────────────────────────────

def test_slowing_down_raises_the_floor_for_good():
    from gameloc import throttle

    b = throttle.Brake(scale=0, gap=0.0)
    assert b.slow_down(0.2) is True
    assert b.gap >= 0.2
    # 잘 풀려도 이제는 바닥 밑으로 안 내려갑니다.
    for _ in range(throttle.EASE_AFTER * 6):
        b.eased()
    assert b.gap >= 0.2, "내려간 뒤에는 다시 전속력으로 돌아가면 안 됩니다"


def test_slowing_down_twice_changes_nothing():
    from gameloc import throttle

    b = throttle.Brake(scale=0, gap=0.0)
    assert b.slow_down(0.2) is True
    assert b.slow_down(0.2) is False
    assert b.slow_down(0.1) is False


def test_a_normal_run_still_eases_all_the_way_to_full_speed():
    """바닥을 올리는 것은 내려간 경우뿐입니다. 평소는 그대로여야 합니다."""
    from gameloc import throttle

    b = throttle.Brake(scale=0, gap=0.2)
    b.hit()
    for _ in range(throttle.EASE_AFTER * 8):
        b.eased()
    assert b.gap == 0.0


def test_the_screen_actually_passes_the_speed_through(monkeypatch):
    """함수는 멀쩡한데 그리로 가는 통로가 끊겨 있던 적이 오늘만 두 번입니다."""
    import types

    from gameloc import translate as mt
    from gameloc import webui

    got = {}

    def fake(entries, provider, **kw):
        got.update(kw)
        return types.SimpleNamespace(done=0, failed=0, skipped=0, problems=[],
                                     summary=lambda: "ok")

    monkeypatch.setattr(mt, "translate_entries", fake)
    monkeypatch.setattr(webui.STATE, "project", types.SimpleNamespace(
        entries=[], languages=["ko"], engine="unity"), raising=False)
    monkeypatch.setattr(webui.STATE, "save", lambda: None, raising=False)
    monkeypatch.setattr(webui.STATE, "start_job",
                        lambda _t, job: job(lambda _m: None), raising=False)
    webui.api_autotranslate({"provider": "google", "lang": "ko", "speed": "fast"})
    assert got.get("speed") == "fast"


def test_a_keyed_engine_ignores_the_speed():
    """키를 쓰는 곳은 IP 가 아니라 키로 셈합니다. 손댈 이유가 없습니다."""
    import types

    from gameloc import translate as mt

    p = mt.make_provider("deepl", "key-1234")
    before = p.workers
    said = []
    mt.translate_entries([], p, speed="fast", progress=said.append)
    assert p.workers == before
    assert not any("속도:" in m for m in said)


# ── Gemini: 없는 모델 하나로 4만 건을 통째로 날리지 않기 ─────────────────
#
# 실제 신고: 45,129건이 [20/45129] [40/45129] … 하고 **같은 404 를 2,257번**
# 냈습니다. 게다가 "최신판으로 올리세요" 라고 했는데 그분은 최신판이었습니다.
#
# 원인이 셋 겹쳤습니다.
#   ① 목록을 못 물어보면 KNOWN[0] 을 썼는데, 그게 제가 지어낸 이름이었습니다
#   ② 한 번 고른 이름을 끝까지 물고 늘어졌습니다 (self._picked)
#   ③ 404 를 받아도 다음 이름으로 안 갈아탔습니다

def _gem(monkeypatch, models, dead=(), calls=None):
    from gameloc import translate as mt

    g = mt.GeminiAPI("key-1")
    monkeypatch.setattr(g, "available", lambda: list(models))

    def fake_post(url, data, headers, timeout=60):
        name = url.rsplit("/models/", 1)[-1].split(":")[0]
        if calls is not None:
            calls.append(name)
        if name in dead:
            raise mt.urllib.error.HTTPError(url, 404, "Not Found", {}, None)
        return b'{"candidates":[{"content":{"parts":[{"text":"ok"}]}}]}'

    monkeypatch.setattr(mt, "_post", fake_post)
    return g


def test_a_dead_model_is_dropped_and_the_next_one_is_tried(monkeypatch):
    calls = []
    # 짧은 flash 이름이 먼저 골라집니다 — 값싸고 빠른 것을 앞에 두니까요.
    g = _gem(monkeypatch, ["gemini-x-flash", "gemini-2.5-flash"],
             dead=["gemini-x-flash"], calls=calls)
    assert g._ask("시켜", "1. hi") == "ok"
    assert calls == ["gemini-x-flash", "gemini-2.5-flash"]


def test_the_dead_one_is_never_tried_again(monkeypatch):
    """예전에는 4만 건이 **같은** 없는 이름으로 갔습니다."""
    calls = []
    g = _gem(monkeypatch, ["gemini-x-flash", "gemini-2.5-flash"],
             dead=["gemini-x-flash"], calls=calls)
    for _ in range(5):
        g._ask("시켜", "1. hi")
    assert calls.count("gemini-x-flash") == 1, "죽은 이름을 또 부르면 안 됩니다"


def test_the_key_list_beats_our_hardcoded_names(monkeypatch):
    """코드에 박은 이름은 언젠가 반드시 죽습니다. 키에게 물은 것이 우선."""
    calls = []
    g = _gem(monkeypatch, ["gemini-9.9-flash"], calls=calls)
    g._ask("a", "b")
    assert calls[0] == "gemini-9.9-flash"


def test_we_never_ship_a_name_we_made_up():
    """지어낸 이름을 대비책으로 두면, 목록을 못 물어본 사람이 전부 죽습니다."""
    from gameloc import translate as mt

    # 구글이 **별칭으로 유지하는** 이름만 둡니다. 별칭은 실제 모델이
    # 바뀌어도 따라갑니다.
    assert mt.GeminiAPI.KNOWN[0].endswith("-latest")


def test_it_refuses_up_front_instead_of_failing_45000_times(monkeypatch):
    """4만 건을 다 실패하고 알려주는 것은 알려주는 게 아닙니다."""
    from gameloc import translate as mt

    g = mt.GeminiAPI("key-1")
    monkeypatch.setattr(g, "available", lambda: [])
    monkeypatch.setattr(mt.GeminiAPI, "KNOWN", ())
    with pytest.raises(RuntimeError, match="하나도 못 찾았습니다"):
        g.check()


def test_the_message_does_not_tell_a_current_user_to_update(monkeypatch):
    from gameloc import translate as mt

    say = mt._why(mt.urllib.error.HTTPError("u", 404, "Not Found", {}, None))
    assert "최신판" not in say, "최신판을 쓰는 사람에게 할 말이 아닙니다"
    assert "키" in say
