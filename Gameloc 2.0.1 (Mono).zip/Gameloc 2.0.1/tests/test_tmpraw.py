# SPDX-License-Identifier: GPL-3.0-or-later
"""굳어 있는(Static) TextMeshPro 폰트를 푸는 일."""

import struct

import pytest

from gameloc import tmpraw


def _s(text: str) -> bytes:
    b = text.encode("utf-8")
    return struct.pack("<i", len(b)) + b + b"\x00" * (-len(b) % 4)


def build(name="Rajdhani-Bold SDF", version="1.1.0",
          guid="09f5f6f2c59fdf2449740899f95946b9",
          src_file=0, src_path=0, mode=tmpraw.STATIC, tail=64) -> bytes:
    """진짜 파일과 같은 모양의 폰트 앞머리를 만듭니다."""
    out = bytearray()
    out += struct.pack("<iq", 0, 0)          # m_GameObject
    out += struct.pack("<i", 1)              # m_Enabled
    out += struct.pack("<iq", 0, 1234)       # m_Script
    out += _s(name)
    out += struct.pack("<i", 0x12345678)     # hashCode
    out += struct.pack("<iq", 0, 44)         # material
    out += struct.pack("<i", 0x2468ACE0)     # materialHashCode
    out += _s(version)
    out += _s(guid)
    out += struct.pack("<iq", src_file, src_path)
    out += struct.pack("<i", mode)
    out += b"\xAB" * tail                    # 글자표·그림판 — 손대면 안 됩니다
    return bytes(out)


# ── 읽기 ─────────────────────────────────────────────────────────────────

def test_reads_a_real_shaped_font():
    h = tmpraw.read_head(build())
    assert h is not None
    assert (h.name, h.version, h.mode) == ("Rajdhani-Bold SDF", "1.1.0", 0)
    assert h.needs_help()


def test_dynamic_with_source_needs_no_help():
    h = tmpraw.read_head(build(src_path=663, mode=tmpraw.DYNAMIC))
    assert h is not None and not h.needs_help()


def test_static_with_source_needs_no_help():
    """원본이 있으면 이미 없는 글자를 만들 수 있습니다."""
    h = tmpraw.read_head(build(src_path=663, mode=tmpraw.STATIC))
    assert h is not None and not h.needs_help()


def test_empty_guid_is_allowed():
    assert tmpraw.read_head(build(guid="")) is not None


# ── 폰트가 아닌 것을 폰트로 착각하지 않기 ──────────────────────────────────

@pytest.mark.parametrize("kw", [
    {"version": "hello"},                      # 판 번호 자리가 글자
    {"guid": "not-a-guid-at-all"},             # 지문이 16진수가 아님
    {"mode": 7},                               # 방식 값이 범위 밖
    {"name": ""},                              # 이름이 없음
])
def test_rejects_things_that_are_not_fonts(kw):
    assert tmpraw.read_head(build(**kw)) is None


def test_rejects_random_bytes():
    assert tmpraw.read_head(b"\x00" * 200) is None
    assert tmpraw.read_head(bytes(range(256)) * 4) is None


def test_rejects_too_short():
    assert tmpraw.read_head(build()[:40]) is None


# ── 고치기 ───────────────────────────────────────────────────────────────

def test_retarget_sets_both_values():
    raw = build()
    h = tmpraw.read_head(raw)
    out = tmpraw.retarget(raw, h, 663)
    h2 = tmpraw.read_head(out)
    assert (h2.src_file, h2.src_path, h2.mode) == (0, 663, tmpraw.DYNAMIC)


def test_retarget_does_not_change_length():
    raw = build()
    out = tmpraw.retarget(raw, tmpraw.read_head(raw), 663)
    assert len(out) == len(raw)


def test_retarget_leaves_everything_else_alone():
    """16바이트만 달라야 합니다. 글자표·그림판은 그대로."""
    raw = build()
    h = tmpraw.read_head(raw)
    out = tmpraw.retarget(raw, h, 663)
    diff = [i for i, (a, b) in enumerate(zip(raw, out)) if a != b]
    assert diff, "아무것도 안 바뀌었습니다"
    assert min(diff) >= h.off_src
    assert max(diff) < h.off_mode + 4
    assert raw[h.off_mode + 4:] == out[h.off_mode + 4:]
    assert raw[:h.off_src] == out[:h.off_src]


def test_retarget_refuses_empty_target():
    raw = build()
    with pytest.raises(ValueError):
        tmpraw.retarget(raw, tmpraw.read_head(raw), 0)


def test_retarget_result_reads_back():
    """고친 뒤 스스로 다시 읽어 확인합니다."""
    raw = build(name="MSYH SDF")
    out = tmpraw.retarget(raw, tmpraw.read_head(raw), 999)
    h = tmpraw.read_head(out)
    assert h.name == "MSYH SDF" and h.src_path == 999


# ── 이어붙이기 ───────────────────────────────────────────────────────────

def test_emoji_fonts_are_left_alone():
    """이모지·아이콘 모음은 글자 폰트가 아니라 건드리지 않습니다."""
    from gameloc import font

    for name in ("EmojiOne", "Icon SDF", "SymbolFont", "Sprite Asset"):
        assert any(w in name.lower() for w in font._NOT_TEXT), name
    assert not any(w in "Rajdhani-Bold SDF".lower() for w in font._NOT_TEXT)
