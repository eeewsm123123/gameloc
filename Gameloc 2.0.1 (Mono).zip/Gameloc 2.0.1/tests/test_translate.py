"""자동 번역: 제어문자 보호와 엔진 공통 로직.

실제 번역 서비스는 부르지 않습니다. 가짜 엔진으로 '번역기가 할 법한 짓'을
재현해서, 그럴 때 우리 쪽이 어떻게 대응하는지를 검증합니다.
"""

from __future__ import annotations

import pytest

from gameloc import protect, translate as mt
from gameloc.model import Entry


# ------------------------------------------------------------ 제어문자 보호
@pytest.mark.parametrize("text", [
    r"\N[1]は %1 のダメージを受けた！",
    r"\C[3]警告\C[0]：\V[12] ゴールド足りません。",
    r"こんにちは\.\|それでは\!",
    "다음 줄로\n이어지는 대사",
    "<color=#ff0000>붉은 글씨</color>",
    "코드가 하나도 없는 평범한 문장입니다.",
])
def test_mask_unmask_identity(text):
    masked, codes = protect.mask(text)
    assert protect.unmask(masked, codes) == text


def test_codes_are_hidden_from_translator():
    masked, codes = protect.mask(r"\N[1]は %1 のダメージ")
    assert "\\N[1]" not in masked and "%1" not in masked
    assert len(codes) == 2
    assert "⟦0⟧" in masked and "⟦1⟧" in masked


def test_verify_catches_dropped_token():
    src = r"\N[1]は %1 のダメージ"
    masked, codes = protect.mask(src)
    broken = "⟦0⟧는 피해를 입었다"          # ⟦1⟧ 을 번역기가 삼킴
    assert protect.verify(broken, codes) is not None
    out, problem = protect.roundtrip(src, broken, codes)
    assert problem and out == src, "깨졌으면 원문을 그대로 남겨야 한다"


def test_verify_allows_reordering():
    src = r"%1は %2 のダメージを受けた"
    masked, codes = protect.mask(src)
    ok = "⟦1⟧ 만큼 ⟦0⟧이(가) 피해를 입었다"   # 어순 바뀜 = 정상
    assert protect.verify(ok, codes) is None
    out, problem = protect.roundtrip(src, ok, codes)
    assert problem is None
    assert out == "%2 만큼 %1이(가) 피해를 입었다"


def test_glossary():
    g = protect.parse_glossary("ユキ=유키\n図書館 = 도서관\n# 주석\n빈줄무시")
    assert g == {"ユキ": "유키", "図書館": "도서관"}
    assert protect.apply_glossary("ユキは図書館にいる", g) == "유키は도서관にいる"


def test_glossary_longest_first():
    g = protect.parse_glossary("回復薬=회복약\n上級回復薬=상급 회복약")
    assert protect.apply_glossary("上級回復薬", g) == "상급 회복약"


# ------------------------------------------------------------ 가짜 엔진
class Fake(mt.Provider):
    key_id = "fake"
    label = "테스트용"
    batch_size = 3
    workers = 2
    retry_delay = 0

    def __init__(self, behaviour="ok"):
        super().__init__()
        self.behaviour = behaviour
        self.calls = 0
        self.seen: list[str] = []

    def _translate(self, texts, src, dst):
        self.calls += 1
        self.seen += texts
        if self.behaviour == "boom":
            raise RuntimeError("서버 오류")
        if self.behaviour == "eat_codes":
            return [protect.TOKEN_RE.sub("", t) for t in texts]
        if self.behaviour == "echo":
            return list(texts)
        return ["[번역]" + t for t in texts]


def ents(*texts):
    return [Entry(id=f"e{i}", text=t) for i, t in enumerate(texts)]


def test_happy_path():
    e = ents("Hello", "World")
    rep = mt.translate_entries(e, Fake(), dst="ko")
    assert rep.done == 2 and rep.failed == 0
    assert e[0].translations["ko"] == "[번역]Hello"
    assert e[0].machine == ["ko"], "기계번역 표시가 붙어야 한다"


def test_dedup_calls_once_per_unique_string():
    f = Fake()
    e = ents("같은 말", "같은 말", "다른 말", "같은 말")
    rep = mt.translate_entries(e, f, dst="ko")
    assert len(f.seen) == 2, "같은 문장은 한 번만 보낸다"
    assert rep.done == 4, "결과는 네 항목 모두에 채워진다"


def test_batching():
    f = Fake()
    mt.translate_entries(ents(*[f"줄{i}" for i in range(7)]), f, dst="ko")
    assert f.calls == 3        # batch_size=3 -> 3+3+1


def test_control_codes_survive_round_trip():
    f = Fake()
    e = ents(r"\N[1]は %1 のダメージ")
    mt.translate_entries(e, f, dst="ko")
    out = e[0].translations["ko"]
    assert "\\N[1]" in out and "%1" in out
    assert "⟦" not in out
    assert "⟦0⟧" in f.seen[0], "엔진에는 토큰 상태로 나가야 한다"


def test_broken_codes_are_not_written():
    e = ents(r"\N[1]は %1 のダメージ")
    rep = mt.translate_entries(e, Fake("eat_codes"), dst="ko")
    assert rep.failed == 1 and rep.done == 0
    assert "ko" not in e[0].translations, "깨진 번역은 넣지 않는다"
    assert rep.problems and "제어문자" in rep.problems[0]


def test_failure_is_reported_not_raised():
    e = ents("아무거나")
    rep = mt.translate_entries(e, Fake("boom"), dst="ko")
    assert rep.failed == 1
    assert "RuntimeError" in rep.problems[0]
    assert "ko" not in e[0].translations


def test_unchanged_output_counts_as_skipped():
    e = ents("Already Korean")
    rep = mt.translate_entries(e, Fake("echo"), dst="ko")
    assert rep.skipped == 1 and rep.done == 0


def test_glossary_applied_after_translation():
    e = ents("ユキ")
    mt.translate_entries(e, Fake(), dst="ko", glossary={"[번역]ユキ": "유키"})
    assert e[0].translations["ko"] == "유키"


def test_writes_into_named_language_column():
    e = ents("Hi")
    mt.translate_entries(e, Fake(), dst="ko", lang_col="ko2")
    assert e[0].translations == {"ko2": "[번역]Hi"}
    assert e[0].machine == ["ko2"]


def test_manual_edit_clears_machine_flag():
    from gameloc.sheet import merge_into_project
    from gameloc.model import Project
    e = ents("Hi")
    mt.translate_entries(e, Fake(), dst="ko")
    p = Project(game_root="/x", languages=["ko"], entries=e)
    merge_into_project(p, {"e0": {"ko": "사람이 고친 번역"}})
    assert e[0].machine == [], "손으로 고치면 검토 대기가 풀려야 한다"


def test_registry_has_the_three_engines():
    ids = {p["id"] for p in mt.provider_list()}
    assert {"google", "deepl", "claude"} <= ids
    deepl = next(p for p in mt.provider_list() if p["id"] == "deepl")
    assert deepl["needsKey"] is True
    google = next(p for p in mt.provider_list() if p["id"] == "google")
    assert google["needsKey"] is False


def test_key_is_required_before_any_network_call():
    with pytest.raises(RuntimeError, match="API 키"):
        mt.make_provider("deepl", "")
