"""TyranoScript: 태그를 건드리지 않고 대사만 갈아끼우기."""

from __future__ import annotations

from pathlib import Path

from gameloc import apply as apply_mod
from gameloc import extract as extract_mod
from gameloc.detect import detect
from gameloc.engines import tyrano

SCENE = '''\
;このシーンは導入です
*start
[cm]
[bg storage="room.jpg" time=1000]
[chara_new name="ユリ" id="yuri" storage="yuri.png"]
#ユリ
おはよう。[l][r]今日はいい天気だね。[p]
[ptext text="第一章" x=100 y=50]
[glink text="はい" target="*yes" size=20]
[glink text="いいえ" target="*no"]
@jump storage="next.ks"
[plugin name=alreadyreadskip_ex]
'''


def make_game(tmp_path: Path) -> Path:
    root = tmp_path / "MyVN"
    data = root / "data" / "scenario"
    data.mkdir(parents=True)
    (root / "tyrano").mkdir()
    (root / "tyrano" / "tyrano.js").write_text(
        "var tyrano = { version: '5.13b' };\n", "utf-8")
    (root / "index.html").write_text("<html></html>", "utf-8")
    (data / "first.ks").write_text(SCENE, "utf-8")

    # 개발자용 문서 — 화면에 안 나오므로 절대 잡히면 안 됩니다
    doc = root / "data" / "others" / "plugin" / "alreadyreadskip_ex"
    doc.mkdir(parents=True)
    (doc / "readme.txt").write_text(
        "【ティラノスクリプトで一文単位で既読判定するプラグイン】\n"
        "■使い方\nその後、first.ksとかに以下のように記述してください。\n", "utf-8")
    (doc / "init.ks").write_text('[plugin name="alreadyreadskip_ex"]\n', "utf-8")
    return root


# ------------------------------------------------------------------ 판별

def test_detect(tmp_path):
    root = make_game(tmp_path)
    info = detect(root)
    assert info.engine == "tyrano"
    assert info.ty_base == root
    assert info.unity_version == "5.13b"
    assert "TyranoScript 5.13b" in info.summary()


def test_plugin_docs_are_not_scenario_files(tmp_path):
    root = make_game(tmp_path)
    files = [str(p.relative_to(root)) for p in tyrano.scenario_files(root)]
    assert files == ["data/scenario/first.ks"]


# ------------------------------------------------------------------ 줄 해석

def test_line_kinds():
    kinds = lambda s: [k for k, _ in tyrano.parse_line(s)]  # noqa: E731
    assert kinds(";주석") == ["comment"]
    assert kinds("*start") == ["label"]
    assert kinds("@jump storage=\"a.ks\"") == ["tag"]
    assert kinds("#ユリ") == ["name"]
    assert kinds("[bg storage=\"a.jpg\"]") == ["tag"]
    assert kinds("おはよう。[l][r]またね。[p]") == [
        "text", "tag", "tag", "text", "tag"]


def test_what_gets_picked_up():
    got = {t: k for _p, k, t in tyrano.iter_texts(SCENE)}

    assert got["おはよう。"] == "대사"
    assert got["今日はいい天気だね。"] == "대사"
    assert got["ユリ"] in ("이름", "항목")        # #ユリ 와 chara_new name=
    assert got["第一章"] == "항목"
    assert got["はい"] == "항목"
    assert got["いいえ"] == "항목"

    # 식별자는 절대 안 잡힙니다
    for junk in ("room.jpg", "yuri", "yuri.png", "*yes", "next.ks",
                 "alreadyreadskip_ex", "20", "100"):
        assert junk not in got, f"{junk} 가 번역 목록에 들어왔습니다"


def test_comments_and_labels_are_skipped():
    got = [t for _p, _k, t in tyrano.iter_texts(SCENE)]
    assert not any("このシーンは導入です" in t for t in got)
    assert "start" not in got


# ------------------------------------------------------------------ 되돌려 넣기

def test_patch_keeps_tags_in_place():
    edits = {}
    for ptr, _kind, text in tyrano.iter_texts(SCENE):
        edits[ptr] = {"おはよう。": "좋은 아침.",
                      "今日はいい天気だね。": "오늘 날씨 좋다.",
                      "はい": "예", "いいえ": "아니오",
                      "第一章": "제1장", "ユリ": "유리"}.get(text, text)
    out = tyrano.patch(SCENE, edits)

    assert "좋은 아침.[l][r]오늘 날씨 좋다.[p]" in out
    assert '[glink text="예" target="*yes" size=20]' in out
    assert '[glink text="아니오" target="*no"]' in out
    assert '[ptext text="제1장" x=100 y=50]' in out
    assert "#유리" in out
    assert '[chara_new name="유리" id="yuri" storage="yuri.png"]' in out
    # 손대지 않은 줄은 글자 하나 안 바뀝니다
    assert ";このシーンは導入です" in out
    assert '@jump storage="next.ks"' in out
    assert "[plugin name=alreadyreadskip_ex]" in out
    assert '[bg storage="room.jpg" time=1000]' in out


def test_patch_without_edits_is_byte_identical():
    assert tyrano.patch(SCENE, {}) == SCENE


def test_unquoted_attribute_gets_quoted_safely():
    line = "[ptext text=はい x=10]"
    ptr = next(p for p, _k, t in tyrano.iter_texts(line) if t == "はい")
    assert tyrano.patch(line, {ptr: "예"}) == '[ptext text="예" x=10]'


def test_quote_in_translation_is_escaped():
    line = '[glink text="はい"]'
    ptr = next(p for p, _k, _t in tyrano.iter_texts(line))
    out = tyrano.patch(line, {ptr: '그는 "예" 라고 했다'})
    assert out == '[glink text="그는 &quot;예&quot; 라고 했다"]'


# ------------------------------------------------------------------ 전체 흐름

def test_roundtrip(tmp_path):
    root = make_game(tmp_path)
    proj = extract_mod.extract(root)
    assert proj.engine == "tyrano"

    texts = {e.text for e in proj.entries}
    assert "おはよう。" in texts
    assert not any("プラグイン" in t for t in texts), "설명서가 섞였습니다"

    for e in proj.entries:
        e.translations["ko"] = "《한》" + e.text
    rep = apply_mod.apply(proj, "ko")
    assert not rep.failures
    assert rep.files_written == 1

    ks = (root / "data" / "scenario" / "first.ks").read_text("utf-8")
    assert "《한》おはよう。[l][r]《한》今日はいい天気だね。[p]" in ks
    assert 'target="*yes"' in ks
    assert (root / "data" / "others" / "plugin" / "alreadyreadskip_ex"
            / "readme.txt").read_text("utf-8").startswith("【ティラノ")

    apply_mod.restore(root)
    assert (root / "data" / "scenario" / "first.ks").read_text("utf-8") == SCENE


def test_same_line_twice_both_get_translated(tmp_path):
    """같은 문장이 한 줄에 두 번 나와도 각 자리를 따로 채웁니다."""
    root = make_game(tmp_path)
    ks = root / "data" / "scenario" / "first.ks"
    ks.write_text("うん。[l]うん。[p]\n", "utf-8")

    proj = extract_mod.extract(root)
    for e in proj.entries:
        e.translations["ko"] = "응."
    apply_mod.apply(proj, "ko")
    assert ks.read_text("utf-8") == "응.[l]응.[p]\n"


# ------------------------------------------------------------------ Electron 안

def test_inside_electron(tmp_path):
    """내용물이 resources/app/ 에 있어도 판별·적용·복구가 다 돌아가야 합니다."""
    outer = tmp_path / "YuriAlice"
    app = outer / "resources" / "app"
    app.mkdir(parents=True)
    inner = make_game(tmp_path / "tmpvn")
    for item in inner.iterdir():
        item.rename(app / item.name)
    (app / "package.json").write_text('{"main":"index.html"}', "utf-8")
    (outer / "LICENSES.chromium.html").write_text("<html></html>", "utf-8")

    info = detect(outer)
    assert info.engine == "tyrano"
    assert info.electron_app == app
    assert "Electron 안" in info.summary()

    proj = extract_mod.extract(outer)
    for e in proj.entries:
        e.translations["ko"] = "《한》" + e.text
    apply_mod.apply(proj, "ko")

    ks = app / "data" / "scenario" / "first.ks"
    assert "《한》おはよう。" in ks.read_text("utf-8")

    # 사용자는 바깥 폴더를 넣습니다 — 백업은 안쪽에 있는데도 찾아야 합니다
    assert apply_mod.restore(outer) == 1
    assert ks.read_text("utf-8") == SCENE


# ------------------------------------------------------------------
# .ks 안에 든 코드와 HTML — 타이틀 화면 메뉴가 대개 여기 있습니다
# ------------------------------------------------------------------
CODE_SCENE = '''\
*title
[iscript]
tf.menu = ["開始", "再開", "設定", "終了"];
tf.desc = "新しく物語を始める。";
[endscript]
[html]
<img src="logo.png" alt="ロゴ">
<div class="menu">開始</div>
[endhtml]
これは普通の台詞です。[p]
'''


def test_code_and_html_blocks_are_skipped():
    got = [t for _p, _k, t in tyrano.iter_texts(CODE_SCENE)]
    assert got == ["これは普通の台詞です。"]
    for danger in ("開始", "再開", "設定", "終了", "ロゴ",
                   "新しく物語を始める。"):
        assert danger not in got, f"{danger} 는 코드/HTML 안입니다"


def test_code_block_lines_are_never_rewritten():
    edits = {f"{ln}.0": "번역" for ln in range(len(CODE_SCENE.split("\n")))}
    out = tyrano.patch(CODE_SCENE, edits)
    for line in ('tf.menu = ["開始", "再開", "設定", "終了"];',
                 '<img src="logo.png" alt="ロゴ">',
                 '<div class="menu">開始</div>'):
        assert line in out, f"코드 줄이 바뀌었습니다: {line}"


def test_bracket_inside_attribute_does_not_split_the_tag():
    line = '[glink text="はい[ハート]" target="*yes"]'
    got = [(p, t) for p, _k, t in tyrano.iter_texts(line)]
    assert got == [("0.0@text", "はい[ハート]")]

    out = tyrano.patch(line, {"0.0@text": "예"})
    assert out == '[glink text="예" target="*yes"]'


def test_brackets_in_translation_are_escaped():
    """번역문에 든 [ 는 태그로 읽히면 안 됩니다."""
    line = "こんにちは。[p]"
    ptr = next(p for p, _k, _t in tyrano.iter_texts(line))
    out = tyrano.patch(line, {ptr: "안녕하세요 [주인공]님."})
    assert out == "안녕하세요 [[주인공]님.[p]"
    # [[ 는 글자로 보여줄 대괄호지 태그가 아닙니다
    assert tyrano.TAG.findall(out.replace("[[", "")) == ["[p]"]


def test_line_whose_shape_would_change_is_left_alone():
    """뼈대가 달라지면 그 줄은 아예 안 바꿉니다."""
    line = "おはよう。[l]またね。[p]"
    ptrs = [p for p, _k, _t in tyrano.iter_texts(line)]
    # 번역기가 태그를 삼켜버린 상황을 흉내냅니다
    broken = tyrano.patch(line, {ptrs[0]: "좋은 아침.[l]"})
    assert broken == "좋은 아침.[[l][l]またね。[p]" or broken == line
    assert tyrano.TAG.findall(broken).count("[l]") <= 2
