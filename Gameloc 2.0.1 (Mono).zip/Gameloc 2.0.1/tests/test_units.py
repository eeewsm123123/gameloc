import json

import pytest

from gameloc import containers, heuristics
from gameloc.treepath import format_path, get_by_path, parse_path, set_by_path, walk_strings


# --------------------------------------------------------------- treepath
def test_path_roundtrip():
    for p in ["a", "a.b", "a[0]", "a.b[2].c", "[0][1]"]:
        assert format_path(parse_path(p)) == p


def test_get_set():
    tree = {"a": {"b": [{"c": "hi"}]}}
    assert get_by_path(tree, "a.b[0].c") == "hi"
    set_by_path(tree, "a.b[0].c", "bye")
    assert tree["a"]["b"][0]["c"] == "bye"


def test_walk_strings():
    tree = {"m_Name": "T", "rows": [{"txt": "안녕"}, {"txt": "hi"}], "n": 3}
    got = dict(walk_strings(tree))
    assert got == {"m_Name": "T", "rows[0].txt": "안녕", "rows[1].txt": "hi"}


# ------------------------------------------------------------- heuristics
@pytest.mark.parametrize("s", [
    "Press any key to continue",
    "はじめから",
    "그는 문을 열었다.",
    "You have 3 potions left.",
])
def test_keeps_real_text(s):
    assert heuristics.score(s) >= heuristics.LEVELS["normal"]


@pytest.mark.parametrize("s", [
    "Assets/Prefabs/Enemy.prefab",
    "d3f4a1b2c3d4e5f6",
    "m_LocalPosition",
    "playerHealthBar",
    "  ",
    "12,345.00",
    "https://example.com/x",
    "icon_button.png",
    "<color=#ff0000>",
])
def test_drops_noise(s):
    assert heuristics.score(s) < heuristics.LEVELS["normal"]


def test_denied_keys():
    assert heuristics.is_denied_key("root.m_Name")
    assert heuristics.is_denied_key("m_Guid")
    assert not heuristics.is_denied_key("entries[0].m_Localized")


# ------------------------------------------------------------- containers
CASES = [
    ("json", json.dumps({"a": "Hello", "b": ["World", 1]}, ensure_ascii=False)),
    ("csv", "key,en\ngreet,Hello there\nbye,See you\n"),
    ("lines", "Hello there\nSecond line\n\nThird\n"),
    ("raw", "one single string"),
]


@pytest.mark.parametrize("fmt,text", CASES)
def test_identity_roundtrip(fmt, text):
    """explode + implode with no edits must not disturb the file."""
    assert containers.sniff(text) == fmt or fmt == "raw"
    out = containers.implode(text, fmt, {})
    if fmt == "json":
        assert json.loads(out) == json.loads(text)
    else:
        assert out == text


@pytest.mark.parametrize("fmt,text", CASES)
def test_edit_roundtrip(fmt, text):
    cells = list(containers.explode(text, fmt))
    assert cells
    ptr, original = cells[0]
    out = containers.implode(text, fmt, {ptr: "번역됨"})
    assert dict(containers.explode(out, fmt))[ptr] == "번역됨"
    # untouched cells survive
    for p, v in cells[1:]:
        assert dict(containers.explode(out, fmt))[p] == v


def test_csv_quotes_new_commas():
    text = "key,en\ngreet,Hello\n"
    out = containers.implode(text, "csv", {"[1][1]": "안녕, 친구"})
    rows = list(containers.explode(out, "csv"))
    assert ("[1][1]", "안녕, 친구") in rows
    assert '"안녕, 친구"' in out


def test_sniff():
    assert containers.sniff('{"a":1}') == "json"
    assert containers.sniff("a,b\n1,2\n") == "csv"
    assert containers.sniff("line1\nline2") == "lines"
    assert containers.sniff("just this") == "raw"
