"""유니티: 망가진 파일을 게임 폴더에 덮어쓰지 않는지.

유니티 에셋은 다시 쓰는 과정에서 조용히 깨질 수 있습니다. 깨진 파일이 게임
폴더에 들어가면 그때부터 게임이 안 켜지고, 사용자는 왜인지 모릅니다.
그래서 쓰기 **전에** 새로 만든 바이트를 다시 읽어 확인하고, 안 맞으면
원본을 그대로 둡니다.
"""

from __future__ import annotations

import json
from pathlib import Path

from gameloc.apply import apply as apply_translations
from gameloc.extract import extract

from test_e2e import FakeEnv, fake_unity, game  # noqa: F401 - fixture 재사용


class _LyingFile:
    """저장은 되는데 내용이 안 들어간 척 하는 파일."""

    def __init__(self, env, mangle):
        self.env, self.mangle = env, mangle

    def save(self, packer=None):  # noqa: ARG002
        doc = json.loads(json.dumps(self.env.doc))
        self.mangle(doc)
        return json.dumps(doc, ensure_ascii=False).encode("utf-8")


def _env_factory(mangle):
    def load(source, **_k):
        env = FakeEnv(source)
        if not hasattr(source, "read"):        # 원본을 열 때만 거짓말을 시킵니다
            env.file = _LyingFile(env, mangle)
        return env
    return load


def _translated(game_root: Path):
    proj = extract(game_root)
    for e in proj.entries:
        e.translations["ko"] = "번역: " + e.text
    return proj


def test_lost_typetree_edit_aborts_the_write(game, monkeypatch):  # noqa: F811
    """타입트리 값이 저장 후 사라지면 파일을 안 씁니다."""
    import UnityPy

    def drop_entries(doc):
        for o in doc["objects"]:
            if o["path_id"] == 12:
                o["tree"]["entries"] = [{"key": "hp_label", "value": "Health Points"},
                                        {"key": "mp_label", "value": "Magic Points"}]

    monkeypatch.setattr(UnityPy, "load", _env_factory(drop_entries))
    target = game / "MyGame_Data" / "resources.assets"
    before = target.read_bytes()

    rep = apply_translations(_translated(game), "ko")

    assert target.read_bytes() == before          # 원본 그대로
    assert any("저장되지 않았습니다" in f for f in rep.failures)
    assert not (game / "__gameloc_backup__" / "MyGame_Data"
                / "resources.assets").exists()


def test_lost_textasset_edit_aborts_the_write(game, monkeypatch):  # noqa: F811
    """TextAsset 본문에 번역문이 없으면 파일을 안 씁니다."""
    import UnityPy

    def drop_script(doc):
        for o in doc["objects"]:
            if o["path_id"] == 11:
                o["tree"]["m_Script"] = "id,name\n1,Healing Potion\n"

    monkeypatch.setattr(UnityPy, "load", _env_factory(drop_script))
    target = game / "MyGame_Data" / "resources.assets"
    before = target.read_bytes()

    rep = apply_translations(_translated(game), "ko")
    assert target.read_bytes() == before
    assert rep.failures


def test_object_vanishing_aborts_the_write(game, monkeypatch):  # noqa: F811
    import UnityPy

    def drop_object(doc):
        doc["objects"] = [o for o in doc["objects"] if o["path_id"] != 12]

    monkeypatch.setattr(UnityPy, "load", _env_factory(drop_object))
    target = game / "MyGame_Data" / "resources.assets"
    before = target.read_bytes()

    rep = apply_translations(_translated(game), "ko")
    assert target.read_bytes() == before
    assert any("사라졌습니다" in f for f in rep.failures)


def test_loose_files_still_applied_when_asset_fails(game, monkeypatch):  # noqa: F811
    """에셋 하나가 실패해도 나머지는 정상 적용됩니다."""
    import UnityPy

    monkeypatch.setattr(UnityPy, "load",
                        _env_factory(lambda doc: doc["objects"].clear()))
    rep = apply_translations(_translated(game), "ko")

    ui = json.loads((game / "MyGame_Data" / "StreamingAssets" / "loc"
                     / "ui.json").read_text("utf-8"))
    assert ui["start"].startswith("번역:")
    assert rep.files_written >= 1
    assert rep.failures


def test_good_write_passes_verification(game, fake_unity):  # noqa: F811
    """정상일 때는 아무것도 막지 않습니다."""
    rep = apply_translations(_translated(game), "ko")
    assert not rep.failures
    assert rep.strings_written > 0
    doc = json.loads((game / "MyGame_Data" / "resources.assets").read_text("utf-8"))
    values = [e["value"] for o in doc["objects"] if o["path_id"] == 12
              for e in o["tree"]["entries"]]
    assert all(v.startswith("번역:") for v in values)


# --------------------------------------------------------------------- IL2CPP

def test_il2cpp_gets_a_plain_warning(tmp_path, monkeypatch):
    """타입트리가 없는 빌드는 왜 텍스트가 안 나오는지 말해줘야 합니다."""
    import UnityPy

    root = tmp_path / "G"
    data = root / "G_Data"
    (data / "il2cpp_data").mkdir(parents=True)
    (data / "globalgamemanagers").write_bytes(b"x 2022.3.1f1 x" + b"\0" * 64)
    (data / "resources.assets").write_text(json.dumps({"objects": [
        {"path_id": 1, "type": "MonoBehaviour", "tree": {"m_Name": "X"}},
    ]}), "utf-8")

    class NoTypetree(FakeEnv):
        def __init__(self, source, **kw):
            super().__init__(source, **kw)
            for o in self.objects:
                o.read_typetree = _raise

    def _raise(*_a, **_k):
        raise RuntimeError("no typetree")

    monkeypatch.setattr(UnityPy, "load", NoTypetree)

    lines = []
    proj = extract(root, progress=lines.append)
    assert proj.stats["scripting_backend"] == "IL2CPP"
    assert any("IL2CPP" in ln for ln in lines)
    assert any("읽을 수 없" in ln for ln in lines)


def test_missing_unitypy_is_explained(game, monkeypatch):  # noqa: F811
    """UnityPy 가 없을 때 파이썬 오류를 그대로 던지지 않습니다."""
    import builtins

    real_import = builtins.__import__

    def fake_import(name, *a, **k):
        if name == "UnityPy":
            raise ImportError("No module named 'UnityPy'")
        return real_import(name, *a, **k)

    monkeypatch.setattr(builtins, "__import__", fake_import)
    lines = []
    proj = extract(game, progress=lines.append)

    # 유니티 에셋은 못 읽어도 StreamingAssets 는 나와야 합니다
    assert any(e.text == "Start Game" for e in proj.entries)
    assert any("UnityPy" in ln for ln in lines)


# --------------------------------------------------------------------- 씬 파일

def test_scene_skip_is_announced(game, fake_unity, monkeypatch):  # noqa: F811
    """씬을 안 읽었으면 그 사실을 말해줘야 합니다.

    작은 게임은 씬이 하나뿐이고 대사가 전부 거기 있습니다. 아무 말 없이
    43개만 뽑아 놓으면 '번역했는데 게임은 그대로' 가 됩니다.
    """
    data = game / "MyGame_Data"
    (data / "level0").write_text(json.dumps({"objects": [
        {"path_id": 21, "type": "MonoBehaviour",
         "tree": {"m_Name": "Dialogue",
                  "lines": ["こんにちは、世界。", "またね。"]}},
    ]}, ensure_ascii=False), "utf-8")

    # 기본은 **읽는 것** 입니다. 대사가 씬에 있는 게임이 압도적으로 많은데,
    # 건너뛰면 그럴듯한 숫자만 찍히고 대사는 통째로 빠집니다.
    lines2 = []
    proj2 = extract(game, progress=lines2.append)
    assert proj2.stats["scenes_skipped"] == 0
    assert any(e.text == "こんにちは、世界。" for e in proj2.entries)
    assert not any("읽지 않았" in ln for ln in lines2)

    # 일부러 끈 사람에게는 무엇이 빠졌는지 분명히 알려 줍니다.
    lines = []
    proj = extract(game, include_scenes=False, progress=lines.append)
    assert proj.stats["scenes_skipped"] == 1
    assert any("씬 파일" in ln for ln in lines)
    assert any("읽지 않았" in ln for ln in lines)
    assert not any(e.text == "こんにちは、世界。" for e in proj.entries)


def test_per_file_counts_are_reported(game, fake_unity):  # noqa: F811
    """어느 파일에서 몇 개가 나왔는지 보여야 어디를 봐야 할지 압니다."""
    proj = extract(game)
    per = proj.stats["per_file"]
    assert per["resources.assets"] > 0


def test_blob_files_are_not_opened(game, fake_unity):  # noqa: F811
    """.resource 는 소리·그림 덩어리라 열어봐야 시간만 낭비입니다."""
    from gameloc.detect import detect as detect_game

    data = game / "MyGame_Data"
    (data / "resources.resource").write_bytes(b"\x00" * 4096)
    names = [p.name for p in detect_game(game).asset_files]
    assert "resources.resource" not in names
    assert "resources.assets" in names


# ------------------------------------------------- 짝이 되는 파일 찾기

def test_unity_is_always_opened_with_its_folder(game, monkeypatch):  # noqa: F811
    """유니티 파일은 서로를 참조합니다.

    ``resources.assets`` 안의 스크립트가 어떤 클래스인지 알려면
    ``globalgamemanagers.assets`` 를 같이 봐야 합니다. UnityPy 는 그 짝을
    '환경의 path' 에서 찾는데, 폴더를 안 알려주면 **번역기가 설치된 폴더**를
    뒤지다 실패합니다:

        FileNotFoundError: File globalgamemanagers.assets not found in ...\\gameloc

    그래서 열 때마다 폴더를 반드시 넘겨야 합니다.
    """
    import UnityPy

    seen: list[str | None] = []

    def spy(source, **kw):
        seen.append(kw.get("path"))
        return FakeEnv(source)

    monkeypatch.setattr(UnityPy, "load", spy)

    proj = extract(game)
    for e in proj.entries:
        e.translations["ko"] = "번역: " + e.text
    apply_translations(proj, "ko")

    assert seen, "유니티 파일을 하나도 안 열었습니다"
    assert all(p for p in seen), f"폴더 없이 연 곳이 있습니다: {seen}"
    data = str(game / "MyGame_Data")
    assert all(str(p) == data for p in seen), seen


def test_peek_also_passes_the_folder(game, monkeypatch):  # noqa: F811
    import UnityPy

    from gameloc import peek

    seen: list[str | None] = []

    def spy(source, **kw):
        seen.append(kw.get("path"))
        return FakeEnv(source)

    monkeypatch.setattr(UnityPy, "load", spy)
    peek.report(game)
    assert seen and all(p for p in seen), seen


def test_scenes_are_read_by_default(game, fake_unity):  # noqa: F811
    """대사가 씬에만 있는 게임에서, 아무 설정 없이도 나와야 합니다.

    실제 신고에서 나온 시험입니다. 楽園の日々 는 대사가 level1/level3/level4
    안에만 있었는데, 씬을 건너뛰는 게 기본이라 82개만 뽑히고 대사는 한 줄도
    안 나왔습니다. 그런데 화면에는 '82개 뽑음' 이라고 찍혀서, 사용자는
    무엇이 빠졌는지 알 길이 없었습니다.
    """
    data = game / "MyGame_Data"
    (data / "level3").write_text(json.dumps({"objects": [
        {"path_id": 77, "type": "MonoBehaviour",
         "tree": {"m_Name": "DialogueText",
                  "line": "遠慮しなくていいよ。"}},
    ]}, ensure_ascii=False), "utf-8")

    proj = extract(game)
    assert any(e.text == "遠慮しなくていいよ。" for e in proj.entries)
