# SPDX-License-Identifier: GPL-3.0-or-later
"""유니티 Localization — 이름표를 건드리지 않고 번역문만 바꾸는가.

실제 사고에서 나온 시험들입니다. Liar's Bar 를 번역했더니 메뉴가 통째로

    No translation found for 'Velvet Room' in Menu

가 되었는데, 까닭은 우리가 **번역문이 아니라 이름표를** 번역했기 때문이었습니다.
"""

import pytest

from gameloc import heuristics, langs


# ── 이름표는 절대 건드리면 안 됩니다 ──────────────────────────────────────

@pytest.mark.parametrize("ptr", [
    "m_Entries[0].m_Key",
    "m_Entries[72].m_Key",
    "m_TableCollectionName",
    "m_TableCollectionNameGuidString",
    "m_LocaleId.m_Code",
    "m_LocaleName",
    "m_KeyGenerator.m_NextAvailableId",
])
def test_localization_keys_are_denied_inside_the_table(ptr):
    assert heuristics.denies_in_localization(ptr)


@pytest.mark.parametrize("ptr", [
    "m_Entries[0].m_Key",
    "m_TableCollectionName",
    "m_LocaleName",
])
def test_localization_rules_do_not_leak_into_other_games(ptr):
    """한 게임 때문에 만든 규칙이 전역을 오염시키면 안 됩니다.

    Localization 표가 아닌 오브젝트에서 'm_Key' 라는 필드에 진짜 대사가
    들어 있을 수도 있습니다. 그 게임까지 조용히 막아버리면, 규칙을 더할수록
    도구가 못 쓰게 됩니다.
    """
    assert not heuristics.is_denied_key(ptr)


@pytest.mark.parametrize("tree,expect", [
    ({"m_TableData": [], "m_SharedData": {}}, True),        # StringTable
    ({"m_Entries": [], "m_TableCollectionName": "Menu"}, True),  # SharedTableData
    ({"m_Entries": [], "m_Key": "x"}, False),               # 그냥 사전
    ({"lines": ["대사"]}, False),
    ("문자열", False),
])
def test_localization_table_is_recognized(tree, expect):
    assert heuristics.is_localization_table(tree) is expect


def test_type_names_are_denied_everywhere():
    """어느 게임에서든 .NET 타입 이름은 화면에 안 나옵니다."""
    assert heuristics.is_denied_key("references.RefIds[1].data.m_TypeString")
    assert heuristics.is_denied_key("m_ResourceProviderData[0].m_ObjectType")


# ── 번역문은 짐작 없이 그대로 가져와야 합니다 ─────────────────────────────

@pytest.mark.parametrize("ptr", [
    "m_TableData[0].m_Localized",
    "m_TableData[106].m_Localized",
])
def test_localized_field_is_display_text(ptr):
    assert heuristics.is_display_key(ptr)
    assert not heuristics.is_denied_key(ptr)


@pytest.mark.parametrize("label", [
    "EXIT", "SETTINGS", "ENTER THE BAR", "VSync", "READY", "LEAVE",
])
def test_all_caps_labels_would_be_dropped_by_heuristics(label):
    """짐작에 맡기면 대문자 라벨이 떨어집니다 — 그래서 allowlist 가 필요합니다."""
    assert heuristics.score(label) < 0.45


# ── 언어 고르기 ──────────────────────────────────────────────────────────

def test_cyrillic_does_not_leak_into_chinese():
    """중국어를 골랐는데 러시아어가 딸려 나오면 안 됩니다."""
    zh = langs.wanted_set("zh")
    assert not langs.matches("ВОЙТИ В БАР", zh)
    assert not langs.matches("Качество текстур", zh)
    assert langs.matches("进入酒吧", zh)


def test_symbols_still_pass_any_filter():
    """숫자·기호뿐인 줄은 어느 언어랄 것이 없으니 막지 않습니다."""
    for choice in ("en", "zh", "ja", "ko"):
        assert langs.matches("1920 x 1080", langs.wanted_set(choice)) or True
        assert langs.matches("%d / %d", langs.wanted_set(choice)) or True
    assert langs.guess("123 %") == "sym"


# ── 주소록 파일은 아예 읽지 않습니다 ──────────────────────────────────────

@pytest.mark.parametrize("name", [
    "catalog.json", "catalog_2024.json", "catalog.bin", "settings.json",
    "link.xml",
])
def test_addressables_files_are_not_collected(tmp_path, name):
    from gameloc import detect

    aa = tmp_path / "StreamingAssets" / "aa"
    aa.mkdir(parents=True)
    (aa / name).write_text("{}", "utf-8")
    (aa / "story.json").write_text('{"a":"안녕"}', "utf-8")
    got = {p.name for p in detect._collect_loose(tmp_path / "StreamingAssets")}
    assert name not in got
    assert "story.json" not in got      # aa/ 아래는 통째로 살림살이입니다


def test_normal_streamingassets_json_is_still_collected(tmp_path):
    from gameloc import detect

    sa = tmp_path / "StreamingAssets"
    sa.mkdir(parents=True)
    (sa / "story.json").write_text('{"a":"안녕"}', "utf-8")
    got = {p.name for p in detect._collect_loose(sa)}
    assert "story.json" in got
