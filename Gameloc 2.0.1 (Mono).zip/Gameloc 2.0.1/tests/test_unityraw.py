"""타입 정보를 못 읽는 오브젝트를 바이트 단위로 번역하기.

Naninovel 의 ``Script`` 가 정확히 이 경우입니다. 게임 DLL 로도 구조를 못
되살리는데, 대사는 전부 거기 들어 있습니다.
"""

from __future__ import annotations

import json
import types

import pytest

from gameloc import unityraw
from gameloc.apply import apply as apply_translations
from gameloc.apply import restore
from gameloc.extract import extract

from test_e2e import FakeEnv, game  # noqa: F401


def us(s: str) -> bytes:
    """유니티가 문자열을 저장하는 방식."""
    b = s.encode("utf-8")
    return len(b).to_bytes(4, "little") + b + b"\x00" * (-len(b) % 4)


LINES = ["パパ、ただいまぁ。お部屋入るねぇ。",
         "ママの声……？　ママ、旅行から帰ってきたのかなぁ。",
         "どうしたのパパ？　すごく焦った顔してるよぉ？"]


def make_blob() -> bytes:
    """대사와 식별자가 섞인, 실제와 비슷한 오브젝트 본문."""
    return (b"\x05\x00\x00\x00" + us("Entry") + b"\x03\x00\x00\x00"
            + us(LINES[0]) + us("Naninovel.Commands.PrintText")
            + us(LINES[1]) + us("bg/room_01")
            + us(LINES[2]) + b"\x00\x01\x02\x03")


# ------------------------------------------------------------------ 훑기

def test_scan_finds_strings_with_offsets():
    blob = make_blob()
    got = dict((s, off) for off, s in unityraw.scan(blob))
    for line in LINES:
        assert line in got
    assert "Entry" in got
    for off, text in unityraw.scan(blob):
        size = int.from_bytes(blob[off:off + 4], "little")
        assert blob[off + 4:off + 4 + size].decode("utf-8") == text


def test_only_japanese_is_offered_for_translation():
    """영어는 대개 에셋 경로·명령 이름입니다. 바꾸면 게임이 못 찾습니다."""
    got = [s for _off, s in unityraw.translatable(make_blob())]
    assert got == LINES
    assert "Entry" not in got
    assert "Naninovel.Commands.PrintText" not in got
    assert "bg/room_01" not in got


def test_binary_noise_is_not_mistaken_for_text():
    assert unityraw.scan(bytes(range(256)) * 4) == [] or all(
        unityraw.plausible(s) for _o, s in unityraw.scan(bytes(range(256)) * 4))


# ------------------------------------------------------------------ 갈아끼우기

def test_patch_replaces_only_the_targeted_strings():
    blob = make_blob()
    edits = {off: "아빠, 다녀왔어요."
             for off, s in unityraw.translatable(blob) if s == LINES[0]}
    out = unityraw.patch(blob, edits)
    got = [s for _o, s in unityraw.scan(out)]

    assert "아빠, 다녀왔어요." in got
    assert LINES[0] not in got
    assert LINES[1] in got and LINES[2] in got     # 나머지는 그대로
    assert "Entry" in got and "bg/room_01" in got  # 식별자도 그대로


def test_patch_handles_length_change_in_both_directions():
    blob = make_blob()
    pairs = dict(unityraw.translatable(blob))
    edits = {off: ("짧" if s == LINES[0] else "아주 긴 번역문 " * 8)
             for off, s in pairs.items()}
    out = unityraw.patch(blob, edits)
    got = [s for _o, s in unityraw.scan(out)]
    assert "짧" in got or "짧" in "".join(got)
    assert unityraw.verify(out, edits)
    assert len(out) != len(blob)


def test_patch_keeps_four_byte_alignment():
    blob = make_blob()
    off = next(o for o, s in unityraw.translatable(blob) if s == LINES[0])
    out = unityraw.patch(blob, {off: "가"})
    size = int.from_bytes(out[off:out and off + 4], "little")
    assert (off + 4 + size + (-size % 4)) % 4 == 0
    # 뒤따르는 문자열이 여전히 읽힙니다
    assert LINES[1] in [s for _o, s in unityraw.scan(out)]


def test_patch_with_no_edits_is_byte_identical():
    blob = make_blob()
    assert unityraw.patch(blob, {}) == blob


def test_bad_offset_is_refused():
    with pytest.raises(ValueError):
        unityraw.patch(make_blob(), {999999: "x"})


def test_verify_catches_a_lost_translation():
    blob = make_blob()
    off = next(o for o, s in unityraw.translatable(blob) if s == LINES[0])
    assert unityraw.verify(unityraw.patch(blob, {off: "번역"}), {off: "번역"})
    assert not unityraw.verify(blob, {off: "번역"})


# ------------------------------------------------------------------ 전체 흐름

class RawEnv(FakeEnv):
    """타입 정보를 못 읽는 MonoBehaviour 가 섞인 환경."""

    def __init__(self, source, **kw):
        super().__init__(source, **kw)
        for o in self.objects:
            d = o._d
            if d.get("raw"):
                blob = bytes.fromhex(d["raw"])
                o.read_typetree = _raise
                o.get_raw_data = (lambda b=blob: b)
                o.set_raw_data = _make_setter(o, d)


def _raise(*_a, **_k):
    raise RuntimeError("Failed to generate MonoBehaviour node for Naninovel.Script")


def _make_setter(obj, d):
    def setter(data):
        d["raw"] = data.hex()
        obj.get_raw_data = lambda: data
        obj._env.changed = True
    return setter


@pytest.fixture
def naninovel(game, monkeypatch):  # noqa: F811
    import UnityPy

    data = game / "MyGame_Data"
    doc = json.loads((data / "resources.assets").read_text("utf-8"))
    doc["objects"].append({"path_id": 5504, "type": "MonoBehaviour",
                           "tree": {}, "raw": make_blob().hex()})
    (data / "resources.assets").write_text(
        json.dumps(doc, ensure_ascii=False), "utf-8")
    monkeypatch.setattr(UnityPy, "load", RawEnv)
    return game


def test_extract_falls_back_to_raw_bytes(naninovel):
    proj = extract(naninovel)
    texts = {e.text for e in proj.entries}
    for line in LINES:
        assert line in texts, f"{line} 를 못 찾았습니다"
    assert proj.stats["raw_objects"] == 1

    loc = next(l for e in proj.entries if e.text == LINES[0]
               for l in e.locations)
    assert loc.kind == "unityraw"
    assert loc.path_id == 5504
    assert loc.ptr.isdigit()


def test_full_roundtrip_through_raw_bytes(naninovel):
    proj = extract(naninovel)
    table = {LINES[0]: "아빠, 다녀왔어요. 방에 들어갈게요.",
             LINES[1]: "엄마 목소리……? 엄마, 여행에서 돌아온 걸까.",
             LINES[2]: "왜 그래 아빠? 엄청 당황한 얼굴인데?"}
    for e in proj.entries:
        if e.text in table:
            e.translations["ko"] = table[e.text]

    rep = apply_translations(proj, "ko")
    assert not rep.failures, rep.failures
    assert rep.strings_written >= 3

    doc = json.loads((naninovel / "MyGame_Data" / "resources.assets")
                     .read_text("utf-8"))
    blob = bytes.fromhex(next(o["raw"] for o in doc["objects"]
                              if o["path_id"] == 5504))
    got = [s for _o, s in unityraw.scan(blob)]
    for ko in table.values():
        assert ko in got
    for jp in LINES:
        assert jp not in got
    assert "Entry" in got and "bg/room_01" in got     # 식별자는 그대로


def test_restore_brings_the_bytes_back(naninovel):
    before = (naninovel / "MyGame_Data" / "resources.assets").read_bytes()
    proj = extract(naninovel)
    for e in proj.entries:
        if e.text == LINES[0]:
            e.translations["ko"] = "아빠, 다녀왔어요."
    apply_translations(proj, "ko")
    assert (naninovel / "MyGame_Data" / "resources.assets").read_bytes() != before

    restore(naninovel)
    assert (naninovel / "MyGame_Data" / "resources.assets").read_bytes() == before


# ------------------------------------------------ 쓴 자리를 정확히 확인하기

def test_patch_reports_where_it_wrote():
    blob = make_blob()
    edits = {off: "번역 " * (i + 1)
             for i, (off, _s) in enumerate(unityraw.translatable(blob))}
    out, moved = unityraw.patch_and_map(blob, edits)

    assert set(moved) == set(edits)
    for off, new in edits.items():
        assert unityraw.read_at(out, moved[off]) == new
    assert unityraw.missing(out, edits, moved) == []


def test_missing_names_the_lost_translations():
    blob = make_blob()
    edits = {off: "번역" for off, _s in unityraw.translatable(blob)}
    out, moved = unityraw.patch_and_map(blob, edits)
    broken = dict(moved)
    broken[next(iter(edits))] = 999999          # 엉뚱한 자리를 가리키게
    assert unityraw.missing(out, edits, broken) == ["번역"]


@pytest.mark.parametrize("text", [
    ".",                       # 1바이트 — 훑기로는 못 찾습니다
    "가",                      # 3바이트 한 글자
    "아주 긴 번역문 " * 500,    # 아주 김
    "여러\n줄\n번역",           # 줄바꿈
    "따옴표 \"안\" 과 【기호】",
])
def test_short_and_odd_translations_still_verify(text):
    """훑기로는 놓칠 수 있는 번역도 '쓴 자리'로 보면 확실합니다."""
    blob = make_blob()
    off = next(o for o, s in unityraw.translatable(blob) if s == LINES[0])
    out, moved = unityraw.patch_and_map(blob, {off: text})
    assert unityraw.read_at(out, moved[off]) == text
    assert unityraw.missing(out, {off: text}, moved) == []


def test_one_byte_translation_would_fool_the_old_check():
    """옛 방식(다시 훑기)이 왜 못 미더운지 — 한 글자 번역은 놓칩니다."""
    blob = make_blob()
    off = next(o for o, s in unityraw.translatable(blob) if s == LINES[0])
    out, moved = unityraw.patch_and_map(blob, {off: "."})
    assert unityraw.missing(out, {off: "."}, moved) == []   # 새 방식: 통과
