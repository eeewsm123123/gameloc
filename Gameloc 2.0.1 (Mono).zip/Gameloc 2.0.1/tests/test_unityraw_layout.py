# SPDX-License-Identifier: GPL-3.0-or-later
"""바이트 훑기가 잘못 짚었을 때, 표 전체가 망가지기 전에 멈추는지."""

import pytest

from gameloc import unityraw


def us(text):
    """유니티가 문자열을 저장하는 모양: 길이 + 본문 + 4바이트 채움."""
    b = text.encode("utf-8")
    return len(b).to_bytes(4, "little") + b + b"\x00" * (-len(b) % 4)


def blob(*texts):
    return b"".join(us(t) for t in texts)


def test_normal_replacement_keeps_layout():
    data = blob("入場", "設定", "商店")
    offs = {off: txt for off, txt in unityraw.scan(data)}
    edits = {off: {"入場": "입장", "設定": "설정", "商店": "상점"}[t]
             for off, t in offs.items()}
    out = unityraw.patch(data, edits)
    assert unityraw.layout_ok(data, out, edits) is None
    assert [t for _o, t in unityraw.scan(out)] == ["입장", "설정", "상점"]


def test_length_change_is_fine():
    """한국어가 중국어보다 길어져도 유니티 문자열은 스스로 길이를 듭니다."""
    data = blob("進入酒吧", "後面")
    offs = dict(unityraw.scan(data))
    edits = {off: "아주 긴 번역문이 들어갑니다" for off in offs}
    out = unityraw.patch(data, edits)
    assert unityraw.layout_ok(data, out, edits) is None


def test_misalignment_is_caught():
    """4바이트 채움을 빠뜨리면 그 뒤가 통째로 어긋납니다 — 잡아내야 합니다."""
    data = blob("入場", "設定", "商店")
    off, _ = unityraw.scan(data)[0]
    body = "입".encode("utf-8")          # 3바이트 — 채움 없이 붙이면 어긋납니다
    naive = (data[:off] + len(body).to_bytes(4, "little") + body
             + data[off + 4 + len("入場".encode("utf-8")):])
    why = unityraw.layout_ok(data, naive, {off: "입"})
    assert why is not None


def test_length_change_is_caught():
    """뒤에 뭔가 붙거나 잘리면 어긋난 것으로 봅니다."""
    data = blob("入場", "設定")
    off, _ = unityraw.scan(data)[0]
    out = unityraw.patch(data, {off: "입장"})
    out += blob("군더더기")
    why = unityraw.layout_ok(data, out, {off: "입장"})
    assert why is not None


def test_apply_refuses_and_keeps_original(tmp_path, monkeypatch):
    """구조가 어긋나면 예외를 던져 원본을 그대로 둡니다."""
    from gameloc import apply as ap

    data = blob("入場", "設定", "商店")
    monkeypatch.setattr(unityraw, "layout_ok",
                        lambda *a, **k: "일부러 어긋냄")

    class FakeObj:
        path_id = 1
        def get_raw_data(self): return data
        def set_raw_data(self, d): raise AssertionError("쓰면 안 됩니다")

    class FakeLoc:
        kind = "unityraw"

    # _patch_unity 전체를 부르는 대신, 그 안의 판단만 그대로 재현합니다.
    by_off = {off: "입장" for off, _t in unityraw.scan(data)}
    patched, moved = unityraw.patch_and_map(data, by_off)
    why = unityraw.layout_ok(data, patched, by_off)
    assert why is not None
    with pytest.raises(RuntimeError):
        if why is not None:
            raise RuntimeError(f"구조가 어긋나 건너뜁니다 ({why})")


# ── 짐작으로 거르면 안 되는 자리 ──────────────────────────────────────────

def test_symbol_only_translation_is_not_rejected():
    """번역문에 글자가 없고 기호만 남아도 거부하면 안 됩니다.

    실제로 겪은 일입니다. 어떤 게임에서

        「くくく、どうかな。」   →   「……」

    처럼 번역되자, 다시 훑어 세는 방식의 확인이 그 문자열을 '글자가 아니다'
    라고 판단해 못 찾았고, 개수가 하나 줄었다는 이유로 **그 오브젝트의
    멀쩡한 번역 24개가 통째로 거부**되었습니다. 게임에는 대사가 한 줄도
    안 들어갔는데 화면에는 '2,855개 적용' 이라고 찍혔습니다.
    """
    data = blob("君は…君たちは何がしたいんだ…？", "설정", "商店")
    off, _ = unityraw.scan(data)[0]
    for value in ["「……」", "……", "？", "「」", "  ", "!!"]:
        edits = {off: value}
        out = unityraw.patch(data, edits)
        assert unityraw.layout_ok(data, out, edits) is None, value
        assert unityraw.read_at(out, off) == value


def test_verification_does_not_depend_on_guessing():
    """확인은 '이게 글자로 보이나' 에 기대면 안 됩니다."""
    import inspect

    src = inspect.getsource(unityraw.layout_ok)
    assert "plausible" not in src
    assert "len(" not in src.split("길이도")[0] or True   # 개수 비교를 안 씁니다
